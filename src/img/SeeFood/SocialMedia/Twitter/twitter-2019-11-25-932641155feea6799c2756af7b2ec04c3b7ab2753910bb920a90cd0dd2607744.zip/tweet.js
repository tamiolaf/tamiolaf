window.YTD.tweet.part0 = [ {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "UMD Alternative Breaks",
      "screen_name" : "UMDAB",
      "indices" : [ "3", "9" ],
      "id_str" : "512031192",
      "id" : "512031192"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "1120407726348230659",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1120407726348230659",
  "created_at" : "Mon Apr 22 19:23:12 +0000 2019",
  "favorited" : false,
  "full_text" : "RT @UMDAB: Come celebrate Earth Day 2019 at UMD's FREE annual Earth Day Festival! Join us to learn about Environmental Justice-- a way to w…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Transfer&Off-Campus",
      "screen_name" : "UMDTOCSL",
      "indices" : [ "3", "12" ],
      "id_str" : "1205397097",
      "id" : "1205397097"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "143" ],
  "favorite_count" : "0",
  "id_str" : "1100466930815848454",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1100466930815848454",
  "created_at" : "Tue Feb 26 18:45:36 +0000 2019",
  "favorited" : false,
  "full_text" : "RT @UMDTOCSL: Not sure where to start with ur internship search? Feel like u r at a standstill &amp; unsure about the next steps in ur search?…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Terp",
      "indices" : [ "27", "32" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "Transfer&Off-Campus",
      "screen_name" : "UMDTOCSL",
      "indices" : [ "53", "62" ],
      "id_str" : "1205397097",
      "id" : "1205397097"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "1093118968670375938",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1093118968670375938",
  "created_at" : "Wed Feb 06 12:07:25 +0000 2019",
  "favorited" : false,
  "full_text" : "RT @thestampumd: The early #Terp gets the coffee! ☕️ @UMDTOCSL’s Good Morning, Commuters starts in just half an hour! \uD83C\uDF4E\uD83C\uDF4C\uD83E\uDD6F\uD83D\uDE0B https://t.co/T9e…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "Maryland Dairy \uD83C\uDF66",
      "screen_name" : "UMDDAIRY",
      "indices" : [ "66", "75" ],
      "id_str" : "2450507694",
      "id" : "2450507694"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/thestampumd/status/1090717091488022543/photo/1",
      "source_status_id" : "1090717091488022543",
      "indices" : [ "83", "106" ],
      "url" : "https://t.co/ZTluS9Ctmy",
      "media_url" : "http://pbs.twimg.com/media/DyMBaOAXQA8FNw0.jpg",
      "id_str" : "1090717084701638671",
      "source_user_id" : "59604041",
      "id" : "1090717084701638671",
      "media_url_https" : "https://pbs.twimg.com/media/DyMBaOAXQA8FNw0.jpg",
      "source_user_id_str" : "59604041",
      "sizes" : {
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1536",
          "h" : "2048",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "900",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "1090717091488022543",
      "display_url" : "pic.twitter.com/ZTluS9Ctmy"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "106" ],
  "favorite_count" : "0",
  "id_str" : "1090729486893633541",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1090729486893633541",
  "possibly_sensitive" : false,
  "created_at" : "Wed Jan 30 21:52:29 +0000 2019",
  "favorited" : false,
  "full_text" : "RT @thestampumd: FREE ice cream and cake is going on RIGHT NOW by @UMDDAIRY! \n\uD83C\uDF70\uD83C\uDF66\uD83C\uDFC0\uD83D\uDC22 https://t.co/ZTluS9Ctmy",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/thestampumd/status/1090717091488022543/photo/1",
      "source_status_id" : "1090717091488022543",
      "indices" : [ "83", "106" ],
      "url" : "https://t.co/ZTluS9Ctmy",
      "media_url" : "http://pbs.twimg.com/media/DyMBaOAXQA8FNw0.jpg",
      "id_str" : "1090717084701638671",
      "source_user_id" : "59604041",
      "id" : "1090717084701638671",
      "media_url_https" : "https://pbs.twimg.com/media/DyMBaOAXQA8FNw0.jpg",
      "source_user_id_str" : "59604041",
      "sizes" : {
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1536",
          "h" : "2048",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "900",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "1090717091488022543",
      "display_url" : "pic.twitter.com/ZTluS9Ctmy"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/0l7EYgjKRF",
      "expanded_url" : "https://twitter.com/thestampumd/status/1090717091488022543",
      "display_url" : "twitter.com/thestampumd/st…",
      "indices" : [ "6", "29" ]
    } ]
  },
  "display_text_range" : [ "0", "29" ],
  "favorite_count" : "0",
  "id_str" : "1090729474763694086",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1090729474763694086",
  "possibly_sensitive" : false,
  "created_at" : "Wed Jan 30 21:52:26 +0000 2019",
  "favorited" : false,
  "full_text" : "\uD83D\uDE0B\uD83D\uDE0B\uD83D\uDE0B\uD83D\uDE0B\uD83D\uDE0B https://t.co/0l7EYgjKRF",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "Brenda Frese",
      "screen_name" : "BrendaFrese",
      "indices" : [ "46", "58" ],
      "id_str" : "29810247",
      "id" : "29810247"
    }, {
      "name" : "Maryland Women’s Basketball",
      "screen_name" : "umdwbb",
      "indices" : [ "60", "67" ],
      "id_str" : "873861104",
      "id" : "873861104"
    }, {
      "name" : "Maryland Dairy \uD83C\uDF66",
      "screen_name" : "UMDDAIRY",
      "indices" : [ "73", "82" ],
      "id_str" : "2450507694",
      "id" : "2450507694"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "1090698590597640192",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1090698590597640192",
  "created_at" : "Wed Jan 30 19:49:42 +0000 2019",
  "favorited" : false,
  "full_text" : "RT @thestampumd: Can't wait to celebrate with @BrendaFrese, @umdwbb, and @UMDDAIRY today~! All are welcome to join! \uD83C\uDF70\uD83C\uDF66\uD83C\uDFC0\uD83D\uDC22 https://t.co/mC0fG…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Maryland Dairy \uD83C\uDF66",
      "screen_name" : "UMDDAIRY",
      "indices" : [ "3", "12" ],
      "id_str" : "2450507694",
      "id" : "2450507694"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "1090698487463849984",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1090698487463849984",
  "created_at" : "Wed Jan 30 19:49:18 +0000 2019",
  "favorited" : false,
  "full_text" : "RT @UMDDAIRY: Come celebrate Coach Brenda Frese's 500 wins\uD83C\uDFC0, TODAY with cake\uD83C\uDF70 and Brenda's Peanut Butter Frese Ice Cream\uD83C\uDF66!! Stop by Marylan…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/1056745057867481088/photo/1",
      "indices" : [ "68", "91" ],
      "url" : "https://t.co/iRb69sv2LQ",
      "media_url" : "http://pbs.twimg.com/media/DqpQB0GXQAAVT0e.jpg",
      "id_str" : "1056745054667227136",
      "id" : "1056745054667227136",
      "media_url_https" : "https://pbs.twimg.com/media/DqpQB0GXQAAVT0e.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "1200",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "2048",
          "h" : "2048",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/iRb69sv2LQ"
    } ],
    "hashtags" : [ {
      "text" : "SeeFoodFeedAFriend",
      "indices" : [ "48", "67" ]
    } ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "8",
  "id_str" : "1056745057867481088",
  "truncated" : false,
  "retweet_count" : "2",
  "id" : "1056745057867481088",
  "possibly_sensitive" : false,
  "created_at" : "Mon Oct 29 03:10:29 +0000 2018",
  "favorited" : false,
  "full_text" : "How do you make soup gold? Put 24 carrots in it\n#SeeFoodFeedAFriend https://t.co/iRb69sv2LQ",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/1056745057867481088/photo/1",
      "indices" : [ "68", "91" ],
      "url" : "https://t.co/iRb69sv2LQ",
      "media_url" : "http://pbs.twimg.com/media/DqpQB0GXQAAVT0e.jpg",
      "id_str" : "1056745054667227136",
      "id" : "1056745054667227136",
      "media_url_https" : "https://pbs.twimg.com/media/DqpQB0GXQAAVT0e.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "1200",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "2048",
          "h" : "2048",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/iRb69sv2LQ"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/1055983616784764934/photo/1",
      "indices" : [ "126", "149" ],
      "url" : "https://t.co/9T9qwVarPu",
      "media_url" : "http://pbs.twimg.com/media/Dqebf21W4AEncyp.jpg",
      "id_str" : "1055983609239232513",
      "id" : "1055983609239232513",
      "media_url_https" : "https://pbs.twimg.com/media/Dqebf21W4AEncyp.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "1200",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "2048",
          "h" : "2048",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/9T9qwVarPu"
    } ],
    "hashtags" : [ {
      "text" : "SeeFoodComingSoon",
      "indices" : [ "107", "125" ]
    } ]
  },
  "display_text_range" : [ "0", "149" ],
  "favorite_count" : "4",
  "id_str" : "1055983616784764934",
  "truncated" : false,
  "retweet_count" : "4",
  "id" : "1055983616784764934",
  "possibly_sensitive" : false,
  "created_at" : "Sat Oct 27 00:44:48 +0000 2018",
  "favorited" : false,
  "full_text" : "what does a nosey pepper do? Get jalapeño business!!! \uD83D\uDE39\uD83C\uDF36Funny food jokes are hard, getting free food isn’t #SeeFoodComingSoon https://t.co/9T9qwVarPu",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/1055983616784764934/photo/1",
      "indices" : [ "126", "149" ],
      "url" : "https://t.co/9T9qwVarPu",
      "media_url" : "http://pbs.twimg.com/media/Dqebf21W4AEncyp.jpg",
      "id_str" : "1055983609239232513",
      "id" : "1055983609239232513",
      "media_url_https" : "https://pbs.twimg.com/media/Dqebf21W4AEncyp.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "1200",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "2048",
          "h" : "2048",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/9T9qwVarPu"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/1055677867441508352/photo/1",
      "indices" : [ "121", "144" ],
      "url" : "https://t.co/taIWZCYii9",
      "media_url" : "http://pbs.twimg.com/media/DqaFbEAX4AIxaVS.jpg",
      "id_str" : "1055677862643228674",
      "id" : "1055677862643228674",
      "media_url_https" : "https://pbs.twimg.com/media/DqaFbEAX4AIxaVS.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "1200",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "2048",
          "h" : "2048",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/taIWZCYii9"
    } ],
    "hashtags" : [ {
      "text" : "4DaysLeft",
      "indices" : [ "110", "120" ]
    } ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "4",
  "id_str" : "1055677867441508352",
  "truncated" : false,
  "retweet_count" : "5",
  "id" : "1055677867441508352",
  "possibly_sensitive" : false,
  "created_at" : "Fri Oct 26 04:29:51 +0000 2018",
  "favorited" : false,
  "full_text" : "Why don’t eggs tell jokes? \n-Because they’d crack each other up\uD83E\uDD23\nFree food made easy by See Food, coming soon #4DaysLeft https://t.co/taIWZCYii9",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/1055677867441508352/photo/1",
      "indices" : [ "121", "144" ],
      "url" : "https://t.co/taIWZCYii9",
      "media_url" : "http://pbs.twimg.com/media/DqaFbEAX4AIxaVS.jpg",
      "id_str" : "1055677862643228674",
      "id" : "1055677862643228674",
      "media_url_https" : "https://pbs.twimg.com/media/DqaFbEAX4AIxaVS.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "1200",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "2048",
          "h" : "2048",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/taIWZCYii9"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/1055306667687100416/photo/1",
      "indices" : [ "39", "62" ],
      "url" : "https://t.co/MTtZpGJOme",
      "media_url" : "http://pbs.twimg.com/media/DqUzwY_WoAA_FfW.jpg",
      "id_str" : "1055306594123161600",
      "id" : "1055306594123161600",
      "media_url_https" : "https://pbs.twimg.com/media/DqUzwY_WoAA_FfW.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "2048",
          "h" : "2048",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/MTtZpGJOme"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "62" ],
  "favorite_count" : "1",
  "id_str" : "1055306667687100416",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "1055306667687100416",
  "possibly_sensitive" : false,
  "created_at" : "Thu Oct 25 03:54:50 +0000 2018",
  "favorited" : false,
  "full_text" : "5 days until See Food launches at UMD! https://t.co/MTtZpGJOme",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/1055306667687100416/photo/1",
      "indices" : [ "39", "62" ],
      "url" : "https://t.co/MTtZpGJOme",
      "media_url" : "http://pbs.twimg.com/media/DqUzwY_WoAA_FfW.jpg",
      "id_str" : "1055306594123161600",
      "id" : "1055306594123161600",
      "media_url_https" : "https://pbs.twimg.com/media/DqUzwY_WoAA_FfW.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "2048",
          "h" : "2048",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/MTtZpGJOme"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Terps",
      "indices" : [ "66", "72" ]
    }, {
      "text" : "HungryTerps",
      "indices" : [ "73", "85" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Free_Food_UMD",
      "indices" : [ "3", "17" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "85" ],
  "favorite_count" : "0",
  "id_str" : "1042558644636794880",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1042558644636794880",
  "created_at" : "Wed Sep 19 23:38:45 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @Free_Food_UMD: Free food at Frank Auditorium of Van Munching! #Terps #HungryTerps",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lil Mak",
      "screen_name" : "makuachii",
      "indices" : [ "3", "13" ],
      "id_str" : "230250586",
      "id" : "230250586"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/makuachii/status/1042157138657898496/photo/1",
      "source_status_id" : "1042157138657898496",
      "indices" : [ "56", "79" ],
      "url" : "https://t.co/9U7MAO3lha",
      "media_url" : "http://pbs.twimg.com/media/DnZ8ZAdUcAABaBb.jpg",
      "id_str" : "1042157132844396544",
      "source_user_id" : "230250586",
      "id" : "1042157132844396544",
      "media_url_https" : "https://pbs.twimg.com/media/DnZ8ZAdUcAABaBb.jpg",
      "source_user_id_str" : "230250586",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "536",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "750",
          "h" : "951",
          "resize" : "fit"
        },
        "large" : {
          "w" : "750",
          "h" : "951",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "1042157138657898496",
      "display_url" : "pic.twitter.com/9U7MAO3lha"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "79" ],
  "favorite_count" : "0",
  "id_str" : "1042180595630174208",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1042180595630174208",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 18 22:36:31 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @makuachii: TODAY at 6.30! Free pizza, come through! https://t.co/9U7MAO3lha",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/makuachii/status/1042157138657898496/photo/1",
      "source_status_id" : "1042157138657898496",
      "indices" : [ "56", "79" ],
      "url" : "https://t.co/9U7MAO3lha",
      "media_url" : "http://pbs.twimg.com/media/DnZ8ZAdUcAABaBb.jpg",
      "id_str" : "1042157132844396544",
      "source_user_id" : "230250586",
      "id" : "1042157132844396544",
      "media_url_https" : "https://pbs.twimg.com/media/DnZ8ZAdUcAABaBb.jpg",
      "source_user_id_str" : "230250586",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "536",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "750",
          "h" : "951",
          "resize" : "fit"
        },
        "large" : {
          "w" : "750",
          "h" : "951",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "1042157138657898496",
      "display_url" : "pic.twitter.com/9U7MAO3lha"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Terps",
      "indices" : [ "108", "114" ]
    }, {
      "text" : "HungryTerps",
      "indices" : [ "115", "127" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Free_Food_UMD",
      "indices" : [ "3", "17" ],
      "id_str" : "-1",
      "id" : "-1"
    }, {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "94", "106" ],
      "id_str" : "59604041",
      "id" : "59604041"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "127" ],
  "favorite_count" : "0",
  "id_str" : "1042052380223782914",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1042052380223782914",
  "created_at" : "Tue Sep 18 14:07:02 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @Free_Food_UMD: FREE Dinner with Bhakti Yoga Club from 6-8 PM at Thurgood Marshall Room of @TheStampUMD! #Terps #HungryTerps",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Honors Caucus",
      "screen_name" : "BHC_UMD",
      "indices" : [ "3", "11" ],
      "id_str" : "397036296",
      "id" : "397036296"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/BHC_UMD/status/1040701237438672896/photo/1",
      "source_status_id" : "1040701237438672896",
      "indices" : [ "75", "98" ],
      "url" : "https://t.co/gtgnjoKa0m",
      "media_url" : "http://pbs.twimg.com/media/DnFQQYUVAAAKCV7.jpg",
      "id_str" : "1040701231235137536",
      "source_user_id" : "397036296",
      "id" : "1040701231235137536",
      "media_url_https" : "https://pbs.twimg.com/media/DnFQQYUVAAAKCV7.jpg",
      "source_user_id_str" : "397036296",
      "sizes" : {
        "medium" : {
          "w" : "800",
          "h" : "800",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "800",
          "h" : "800",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "1040701237438672896",
      "display_url" : "pic.twitter.com/gtgnjoKa0m"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "98" ],
  "favorite_count" : "0",
  "id_str" : "1041862571756793856",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1041862571756793856",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 18 01:32:48 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @BHC_UMD: Join us for a welcome back cookout on September 28th at 1pm!! https://t.co/gtgnjoKa0m",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/BHC_UMD/status/1040701237438672896/photo/1",
      "source_status_id" : "1040701237438672896",
      "indices" : [ "75", "98" ],
      "url" : "https://t.co/gtgnjoKa0m",
      "media_url" : "http://pbs.twimg.com/media/DnFQQYUVAAAKCV7.jpg",
      "id_str" : "1040701231235137536",
      "source_user_id" : "397036296",
      "id" : "1040701231235137536",
      "media_url_https" : "https://pbs.twimg.com/media/DnFQQYUVAAAKCV7.jpg",
      "source_user_id_str" : "397036296",
      "sizes" : {
        "medium" : {
          "w" : "800",
          "h" : "800",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "800",
          "h" : "800",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "1040701237438672896",
      "display_url" : "pic.twitter.com/gtgnjoKa0m"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "Transfer&Off-Campus",
      "screen_name" : "UMDTOCSL",
      "indices" : [ "39", "48" ],
      "id_str" : "1205397097",
      "id" : "1205397097"
    } ],
    "urls" : [ {
      "url" : "https://t.co/OrPIOxhKIR",
      "expanded_url" : "https://www.facebook.com/events/674817706211491/",
      "display_url" : "facebook.com/events/6748177…",
      "indices" : [ "111", "134" ]
    } ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "1037088721991098368",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1037088721991098368",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 04 21:23:14 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: FREE BREAKFAST ALERT: @UMDTOCSL's first Good Morning, Commuters of the semester is TOMORROW!: https://t.co/OrPIOxhKIR http…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "ChapelUMD",
      "screen_name" : "ChapelUMD",
      "indices" : [ "89", "99" ],
      "id_str" : "2427769519",
      "id" : "2427769519"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "1036897969910542336",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1036897969910542336",
  "created_at" : "Tue Sep 04 08:45:15 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: Start the new semester on the right foot by centering and meditating at @ChapelUMD tomorrow—join them for a chill time (an…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "UMDfinals",
      "indices" : [ "82", "92" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "996445052967817216",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "996445052967817216",
  "created_at" : "Tue May 15 17:39:48 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: It's a scientific fact that it's IMPOSSIBLE to be stressed about #UMDfinals while enjoying s'mores! \uD83D\uDD25\uD83C\uDF6B\uD83D\uDE0B https://t.co/4T5C5…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "UMDfinals",
      "indices" : [ "32", "42" ]
    }, {
      "text" : "STAMPStudyZone",
      "indices" : [ "107", "122" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    } ],
    "urls" : [ {
      "url" : "https://t.co/FwzUR8pXLu",
      "expanded_url" : "https://www.facebook.com/events/173039870024923/",
      "display_url" : "facebook.com/events/1730398…",
      "indices" : [ "83", "106" ]
    } ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "996052035027001345",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "996052035027001345",
  "possibly_sensitive" : false,
  "created_at" : "Mon May 14 15:38:05 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: Come grab some #UMDfinals fuel (a.k.a. FREE PIZZA) today at 1PM!: https://t.co/FwzUR8pXLu #STAMPStudyZone https://t.co/sT3…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "UMDfinals",
      "indices" : [ "110", "120" ]
    }, {
      "text" : "STAMPStudyZone",
      "indices" : [ "121", "136" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    } ],
    "urls" : [ {
      "url" : "https://t.co/XkDD1nY9EB",
      "expanded_url" : "https://www.facebook.com/events/205581166912467/?ti=icl",
      "display_url" : "facebook.com/events/2055811…",
      "indices" : [ "84", "107" ]
    } ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "995993788140146689",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "995993788140146689",
  "possibly_sensitive" : false,
  "created_at" : "Mon May 14 11:46:38 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: Head to the Prince George's Room for FREE breakfast this morning!: https://t.co/XkDD1nY9EB \uD83C\uDF7D #UMDfinals #STAMPStudyZone ht…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    } ],
    "urls" : [ {
      "url" : "https://t.co/XkDD1nY9EB",
      "expanded_url" : "https://www.facebook.com/events/205581166912467/?ti=icl",
      "display_url" : "facebook.com/events/2055811…",
      "indices" : [ "61", "84" ]
    } ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/thestampumd/status/995768360196599808/photo/1",
      "source_status_id" : "995768360196599808",
      "indices" : [ "85", "108" ],
      "url" : "https://t.co/jYEX4pG5k5",
      "media_url" : "http://pbs.twimg.com/media/DdGuCWtWAAIWbhT.jpg",
      "id_str" : "995768348104327170",
      "source_user_id" : "59604041",
      "id" : "995768348104327170",
      "media_url_https" : "https://pbs.twimg.com/media/DdGuCWtWAAIWbhT.jpg",
      "source_user_id_str" : "59604041",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "1200",
          "h" : "820",
          "resize" : "fit"
        },
        "large" : {
          "w" : "2048",
          "h" : "1399",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "465",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "995768360196599808",
      "display_url" : "pic.twitter.com/jYEX4pG5k5"
    } ],
    "hashtags" : [ {
      "text" : "UMDfinals",
      "indices" : [ "29", "39" ]
    } ]
  },
  "display_text_range" : [ "0", "108" ],
  "favorite_count" : "0",
  "id_str" : "995908391527645184",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "995908391527645184",
  "possibly_sensitive" : false,
  "created_at" : "Mon May 14 06:07:18 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: Fuel up for #UMDfinals (for FREE) tomorrow: https://t.co/XkDD1nY9EB https://t.co/jYEX4pG5k5",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/thestampumd/status/995768360196599808/photo/1",
      "source_status_id" : "995768360196599808",
      "indices" : [ "85", "108" ],
      "url" : "https://t.co/jYEX4pG5k5",
      "media_url" : "http://pbs.twimg.com/media/DdGuCWtWAAIWbhT.jpg",
      "id_str" : "995768348104327170",
      "source_user_id" : "59604041",
      "id" : "995768348104327170",
      "media_url_https" : "https://pbs.twimg.com/media/DdGuCWtWAAIWbhT.jpg",
      "source_user_id_str" : "59604041",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "1200",
          "h" : "820",
          "resize" : "fit"
        },
        "large" : {
          "w" : "2048",
          "h" : "1399",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "465",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "995768360196599808",
      "display_url" : "pic.twitter.com/jYEX4pG5k5"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "991396803722514432",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "991396803722514432",
  "created_at" : "Tue May 01 19:19:51 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: The VERY LAST Good Morning, Commuters of the spring 2018 semester is on Wednesday, May 2nd. See all y'all transfer and #of…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SAAS UMD",
      "screen_name" : "SAASUMD",
      "indices" : [ "3", "11" ],
      "id_str" : "246110828",
      "id" : "246110828"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SAASUMD/status/987322305738133505/photo/1",
      "source_status_id" : "987322305738133505",
      "indices" : [ "81", "104" ],
      "url" : "https://t.co/QhknGI1qCX",
      "media_url" : "http://pbs.twimg.com/media/DbOsXSlW4AENxtw.jpg",
      "id_str" : "987322259449765889",
      "source_user_id" : "246110828",
      "id" : "987322259449765889",
      "media_url_https" : "https://pbs.twimg.com/media/DbOsXSlW4AENxtw.jpg",
      "source_user_id_str" : "246110828",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1024",
          "h" : "768",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1024",
          "h" : "768",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "510",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "987322305738133505",
      "display_url" : "pic.twitter.com/QhknGI1qCX"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "104" ],
  "favorite_count" : "0",
  "id_str" : "987323097949884422",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "987323097949884422",
  "possibly_sensitive" : false,
  "created_at" : "Fri Apr 20 13:32:24 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @SAASUMD: Come by our bench today at Stamp, 9-11! Free cookies and coffee \uD83C\uDF6A☕️ https://t.co/QhknGI1qCX",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SAASUMD/status/987322305738133505/photo/1",
      "source_status_id" : "987322305738133505",
      "indices" : [ "81", "104" ],
      "url" : "https://t.co/QhknGI1qCX",
      "media_url" : "http://pbs.twimg.com/media/DbOsXSlW4AENxtw.jpg",
      "id_str" : "987322259449765889",
      "source_user_id" : "246110828",
      "id" : "987322259449765889",
      "media_url_https" : "https://pbs.twimg.com/media/DbOsXSlW4AENxtw.jpg",
      "source_user_id_str" : "246110828",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1024",
          "h" : "768",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1024",
          "h" : "768",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "510",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "987322305738133505",
      "display_url" : "pic.twitter.com/QhknGI1qCX"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/U9OmOY4SUs",
      "expanded_url" : "https://twitter.com/kofieyeboah/status/975074079370874881",
      "display_url" : "twitter.com/kofieyeboah/st…",
      "indices" : [ "33", "56" ]
    } ]
  },
  "display_text_range" : [ "0", "56" ],
  "favorite_count" : "6",
  "id_str" : "987319245066338305",
  "truncated" : false,
  "retweet_count" : "3",
  "id" : "987319245066338305",
  "possibly_sensitive" : false,
  "created_at" : "Fri Apr 20 13:17:06 +0000 2018",
  "favorited" : false,
  "full_text" : "Lmaooo who took this video of me https://t.co/U9OmOY4SUs",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Resident Life at UMD",
      "screen_name" : "UMDReslife",
      "indices" : [ "3", "14" ],
      "id_str" : "978882858",
      "id" : "978882858"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/UMDReslife/status/987309919010480128/photo/1",
      "source_status_id" : "987309919010480128",
      "indices" : [ "95", "118" ],
      "url" : "https://t.co/tVxsnkk07W",
      "media_url" : "http://pbs.twimg.com/media/DbOhInZUQAAaGXR.jpg",
      "id_str" : "987309912710463488",
      "source_user_id" : "978882858",
      "id" : "987309912710463488",
      "media_url_https" : "https://pbs.twimg.com/media/DbOhInZUQAAaGXR.jpg",
      "source_user_id_str" : "978882858",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1125",
          "h" : "1537",
          "resize" : "fit"
        },
        "small" : {
          "w" : "498",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "878",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "987309919010480128",
      "display_url" : "pic.twitter.com/tVxsnkk07W"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "118" ],
  "favorite_count" : "0",
  "id_str" : "987313737890705408",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "987313737890705408",
  "possibly_sensitive" : false,
  "created_at" : "Fri Apr 20 12:55:13 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @UMDReslife: Come out to the Prince Frederick Lawn for ice cream, games, prizes, and more!! https://t.co/tVxsnkk07W",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/UMDReslife/status/987309919010480128/photo/1",
      "source_status_id" : "987309919010480128",
      "indices" : [ "95", "118" ],
      "url" : "https://t.co/tVxsnkk07W",
      "media_url" : "http://pbs.twimg.com/media/DbOhInZUQAAaGXR.jpg",
      "id_str" : "987309912710463488",
      "source_user_id" : "978882858",
      "id" : "987309912710463488",
      "media_url_https" : "https://pbs.twimg.com/media/DbOhInZUQAAaGXR.jpg",
      "source_user_id_str" : "978882858",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1125",
          "h" : "1537",
          "resize" : "fit"
        },
        "small" : {
          "w" : "498",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "878",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "987309919010480128",
      "display_url" : "pic.twitter.com/tVxsnkk07W"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Black Honors Caucus",
      "screen_name" : "BHC_UMD",
      "indices" : [ "3", "11" ],
      "id_str" : "397036296",
      "id" : "397036296"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "986367108899536896",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "986367108899536896",
  "created_at" : "Tue Apr 17 22:13:39 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @BHC_UMD: Black in business is happening right now! Come out to HJ Patterson Atrium tonight for free raffles and a great keynote speech…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Tami",
      "screen_name" : "tamiolaf",
      "indices" : [ "3", "12" ],
      "id_str" : "940506205",
      "id" : "940506205"
    } ],
    "urls" : [ {
      "url" : "https://t.co/CGdXbpcqK9",
      "expanded_url" : "https://twitter.com/bhc_umd/status/986307950699581440",
      "display_url" : "twitter.com/bhc_umd/status…",
      "indices" : [ "28", "51" ]
    } ]
  },
  "display_text_range" : [ "0", "51" ],
  "favorite_count" : "0",
  "id_str" : "986310023033782274",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "986310023033782274",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 17 18:26:48 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @tamiolaf: Come see me!! https://t.co/CGdXbpcqK9",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NCNW UMD SECTION",
      "screen_name" : "NCNWUMD",
      "indices" : [ "3", "11" ],
      "id_str" : "407939313",
      "id" : "407939313"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/NCNWUMD/status/985868113223745538/photo/1",
      "source_status_id" : "985868113223745538",
      "indices" : [ "63", "86" ],
      "url" : "https://t.co/cvLDR8tXDf",
      "media_url" : "http://pbs.twimg.com/media/Da6B0kaWkAAjpij.jpg",
      "id_str" : "985868108568104960",
      "source_user_id" : "407939313",
      "id" : "985868108568104960",
      "media_url_https" : "https://pbs.twimg.com/media/Da6B0kaWkAAjpij.jpg",
      "source_user_id_str" : "407939313",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "985868113223745538",
      "display_url" : "pic.twitter.com/cvLDR8tXDf"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "86" ],
  "favorite_count" : "0",
  "id_str" : "985886653926510597",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "985886653926510597",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 16 14:24:29 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @NCNWUMD: Today at 5! Professional workshop and free food!! https://t.co/cvLDR8tXDf",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/NCNWUMD/status/985868113223745538/photo/1",
      "source_status_id" : "985868113223745538",
      "indices" : [ "63", "86" ],
      "url" : "https://t.co/cvLDR8tXDf",
      "media_url" : "http://pbs.twimg.com/media/Da6B0kaWkAAjpij.jpg",
      "id_str" : "985868108568104960",
      "source_user_id" : "407939313",
      "id" : "985868108568104960",
      "media_url_https" : "https://pbs.twimg.com/media/Da6B0kaWkAAjpij.jpg",
      "source_user_id_str" : "407939313",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "985868113223745538",
      "display_url" : "pic.twitter.com/cvLDR8tXDf"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "U of MD MICA",
      "screen_name" : "UMDMICA",
      "indices" : [ "0", "8" ],
      "id_str" : "75010872",
      "id" : "75010872"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "8" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "985735137920016384",
  "id_str" : "985735234355384322",
  "in_reply_to_user_id" : "800904115924717569",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "985735234355384322",
  "in_reply_to_status_id" : "985735137920016384",
  "created_at" : "Mon Apr 16 04:22:48 +0000 2018",
  "favorited" : false,
  "full_text" : "@UMDMICA",
  "lang" : "und",
  "in_reply_to_screen_name" : "SeeFoodCalendar",
  "in_reply_to_user_id_str" : "800904115924717569"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/985735137920016384/photo/1",
      "indices" : [ "18", "41" ],
      "url" : "https://t.co/JfNWRiQl09",
      "media_url" : "http://pbs.twimg.com/media/Da4I4CMU0AAnxjM.jpg",
      "id_str" : "985735127194980352",
      "id" : "985735127194980352",
      "media_url_https" : "https://pbs.twimg.com/media/Da4I4CMU0AAnxjM.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "large" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "526",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/JfNWRiQl09"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "41" ],
  "favorite_count" : "1",
  "id_str" : "985735137920016384",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "985735137920016384",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 16 04:22:25 +0000 2018",
  "favorited" : false,
  "full_text" : "Tomorrow y'all !! https://t.co/JfNWRiQl09",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/985735137920016384/photo/1",
      "indices" : [ "18", "41" ],
      "url" : "https://t.co/JfNWRiQl09",
      "media_url" : "http://pbs.twimg.com/media/Da4I4CMU0AAnxjM.jpg",
      "id_str" : "985735127194980352",
      "id" : "985735127194980352",
      "media_url_https" : "https://pbs.twimg.com/media/Da4I4CMU0AAnxjM.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "large" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "526",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/JfNWRiQl09"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/FrqJ9AWDM4",
      "expanded_url" : "https://twitter.com/thestampumd/status/983812434526900224",
      "display_url" : "twitter.com/thestampumd/st…",
      "indices" : [ "23", "46" ]
    } ]
  },
  "display_text_range" : [ "0", "46" ],
  "favorite_count" : "1",
  "id_str" : "983812619424423936",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "983812619424423936",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 10 21:03:01 +0000 2018",
  "favorited" : false,
  "full_text" : "Dinner and a show!!??! https://t.co/FrqJ9AWDM4",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC69\uD83C\uDFFE‍\uD83D\uDCBBCode Black UMD\uD83D\uDC68\uD83C\uDFFF‍\uD83D\uDCBB",
      "screen_name" : "codeblackUMD",
      "indices" : [ "8", "21" ],
      "id_str" : "827047908121968640",
      "id" : "827047908121968640"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/983444260241494016/photo/1",
      "indices" : [ "72", "95" ],
      "url" : "https://t.co/qZElQi03bS",
      "media_url" : "http://pbs.twimg.com/media/DaXlVmCX0AAtGY6.jpg",
      "id_str" : "983444252800831488",
      "id" : "983444252800831488",
      "media_url_https" : "https://pbs.twimg.com/media/DaXlVmCX0AAtGY6.jpg",
      "sizes" : {
        "medium" : {
          "w" : "766",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "766",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "543",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/qZElQi03bS"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "95" ],
  "favorite_count" : "2",
  "id_str" : "983444260241494016",
  "truncated" : false,
  "retweet_count" : "2",
  "id" : "983444260241494016",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 09 20:39:17 +0000 2018",
  "favorited" : false,
  "full_text" : "Come to @codeblackUMD 's event tomorrow and network with Bloomberg \uD83D\uDC69\uD83C\uDFFE‍\uD83D\uDCBB https://t.co/qZElQi03bS",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/983444260241494016/photo/1",
      "indices" : [ "72", "95" ],
      "url" : "https://t.co/qZElQi03bS",
      "media_url" : "http://pbs.twimg.com/media/DaXlVmCX0AAtGY6.jpg",
      "id_str" : "983444252800831488",
      "id" : "983444252800831488",
      "media_url_https" : "https://pbs.twimg.com/media/DaXlVmCX0AAtGY6.jpg",
      "sizes" : {
        "medium" : {
          "w" : "766",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "766",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "543",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/qZElQi03bS"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/983443734833623040/photo/1",
      "indices" : [ "0", "23" ],
      "url" : "https://t.co/5Kihxp0gmI",
      "media_url" : "http://pbs.twimg.com/media/DaXk3ENWkAE_SAE.jpg",
      "id_str" : "983443728324005889",
      "id" : "983443728324005889",
      "media_url_https" : "https://pbs.twimg.com/media/DaXk3ENWkAE_SAE.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "526",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "743",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "743",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/5Kihxp0gmI"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "id_str" : "983443734833623040",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "983443734833623040",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 09 20:37:12 +0000 2018",
  "favorited" : false,
  "full_text" : "https://t.co/5Kihxp0gmI",
  "lang" : "und",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/983443734833623040/photo/1",
      "indices" : [ "0", "23" ],
      "url" : "https://t.co/5Kihxp0gmI",
      "media_url" : "http://pbs.twimg.com/media/DaXk3ENWkAE_SAE.jpg",
      "id_str" : "983443728324005889",
      "id" : "983443728324005889",
      "media_url_https" : "https://pbs.twimg.com/media/DaXk3ENWkAE_SAE.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "526",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "743",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "743",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/5Kihxp0gmI"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Terps",
      "indices" : [ "101", "107" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "Transfer&Off-Campus",
      "screen_name" : "UMDTOCSL",
      "indices" : [ "60", "69" ],
      "id_str" : "1205397097",
      "id" : "1205397097"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "0",
  "id_str" : "981332824107245570",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "981332824107245570",
  "created_at" : "Wed Apr 04 00:49:12 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: PREPARE YOURSELVES—for FREE BREAKFAST with @UMDTOCSL. All transfer &amp; off-campus #Terps are invited to stop by the Atrium b…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/981280774333792256/photo/1",
      "indices" : [ "29", "52" ],
      "url" : "https://t.co/YZvT9wdDZs",
      "media_url" : "http://pbs.twimg.com/media/DZ41qO7X0AA1sFT.jpg",
      "id_str" : "981280768491245568",
      "id" : "981280768491245568",
      "media_url_https" : "https://pbs.twimg.com/media/DZ41qO7X0AA1sFT.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "383",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "720",
          "h" : "405",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "720",
          "h" : "405",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/YZvT9wdDZs"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "0",
  "id_str" : "981280774333792256",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "981280774333792256",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 03 21:22:22 +0000 2018",
  "favorited" : false,
  "full_text" : "Hey check this out tomorrow! https://t.co/YZvT9wdDZs",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/981280774333792256/photo/1",
      "indices" : [ "29", "52" ],
      "url" : "https://t.co/YZvT9wdDZs",
      "media_url" : "http://pbs.twimg.com/media/DZ41qO7X0AA1sFT.jpg",
      "id_str" : "981280768491245568",
      "id" : "981280768491245568",
      "media_url_https" : "https://pbs.twimg.com/media/DZ41qO7X0AA1sFT.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "383",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "720",
          "h" : "405",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "720",
          "h" : "405",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/YZvT9wdDZs"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "offcampus",
      "indices" : [ "97", "107" ]
    }, {
      "text" : "Terps",
      "indices" : [ "121", "127" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "Transfer&Off-Campus",
      "screen_name" : "UMDTOCSL",
      "indices" : [ "63", "72" ],
      "id_str" : "1205397097",
      "id" : "1205397097"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "980891365851660293",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "980891365851660293",
  "created_at" : "Mon Apr 02 19:35:00 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: April's Good Morning, Commuters is this week! @UMDTOCSL's cordially invites all #offcampus and transfer #Terps (including…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Transfer&Off-Campus",
      "screen_name" : "UMDTOCSL",
      "indices" : [ "3", "12" ],
      "id_str" : "1205397097",
      "id" : "1205397097"
    }, {
      "name" : "Transfer&Off-Campus",
      "screen_name" : "UMDTOCSL",
      "indices" : [ "53", "62" ],
      "id_str" : "1205397097",
      "id" : "1205397097"
    }, {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "112", "124" ],
      "id_str" : "59604041",
      "id" : "59604041"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "971363740405895168",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "971363740405895168",
  "created_at" : "Wed Mar 07 12:35:37 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @UMDTOCSL: Good Morning Commuters is TODAY!! Join @UMDTOCSL any time between 7:30am-10:30am in the Atrium at @thestampumd for bagels, mu…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/efsfUbR30u",
      "expanded_url" : "https://www.cvent.com/c/express/6db7f09c-b7f8-4f17-add9-19968529c884",
      "display_url" : "cvent.com/c/express/6db7…",
      "indices" : [ "212", "235" ]
    } ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/970894341089775617/photo/1",
      "indices" : [ "236", "259" ],
      "url" : "https://t.co/nGxogjqVvy",
      "media_url" : "http://pbs.twimg.com/media/DXlOmkNXkAA8fGd.jpg",
      "id_str" : "970893619136794624",
      "id" : "970893619136794624",
      "media_url_https" : "https://pbs.twimg.com/media/DXlOmkNXkAA8fGd.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1459",
          "h" : "867",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "713",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "404",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/nGxogjqVvy"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "259" ],
  "favorite_count" : "0",
  "id_str" : "970894341089775617",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "970894341089775617",
  "possibly_sensitive" : false,
  "created_at" : "Tue Mar 06 05:30:23 +0000 2018",
  "favorited" : false,
  "full_text" : "Go see entrepreneurs from UMD compete for $15,000 tomorrow at the Pitch Dingman Finals! There'll be some food there along with the inspiring stories from your fellow students. You just gotta register to attend.\n\nhttps://t.co/efsfUbR30u https://t.co/nGxogjqVvy",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/970894341089775617/photo/1",
      "indices" : [ "236", "259" ],
      "url" : "https://t.co/nGxogjqVvy",
      "media_url" : "http://pbs.twimg.com/media/DXlOmkNXkAA8fGd.jpg",
      "id_str" : "970893619136794624",
      "id" : "970893619136794624",
      "media_url_https" : "https://pbs.twimg.com/media/DXlOmkNXkAA8fGd.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1459",
          "h" : "867",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "713",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "404",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/nGxogjqVvy"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "EUA_UMD",
      "screen_name" : "EUA_UMD",
      "indices" : [ "247", "255" ],
      "id_str" : "191656200",
      "id" : "191656200"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "255" ],
  "favorite_count" : "1",
  "id_str" : "970844967068413952",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "970844967068413952",
  "created_at" : "Tue Mar 06 02:14:12 +0000 2018",
  "favorited" : false,
  "full_text" : "Hey everyone! English Undergraduate Association will be meeting this Tuesday from 7-8pm in Tawes 1134. We will be brainstorming fun activities for our next WDAG, as well as bonding over food, play-doh, and coloring! Come on out and meet the team. @EUA_UMD",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/970843117187485696/photo/1",
      "indices" : [ "89", "112" ],
      "url" : "https://t.co/gzjUqq0opX",
      "media_url" : "http://pbs.twimg.com/media/DXkgqnxWsAAy7NN.jpg",
      "id_str" : "970843111277637632",
      "id" : "970843111277637632",
      "media_url_https" : "https://pbs.twimg.com/media/DXkgqnxWsAAy7NN.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "256",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "784",
          "h" : "295",
          "resize" : "fit"
        },
        "large" : {
          "w" : "784",
          "h" : "295",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/gzjUqq0opX"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "112" ],
  "favorite_count" : "2",
  "id_str" : "970843117187485696",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "970843117187485696",
  "possibly_sensitive" : false,
  "created_at" : "Tue Mar 06 02:06:51 +0000 2018",
  "favorited" : false,
  "full_text" : "Free Georgetown cupcakes in front of mckeldin at 12:15! Sing happy birthday to Testudo \uD83C\uDF89 https://t.co/gzjUqq0opX",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/970843117187485696/photo/1",
      "indices" : [ "89", "112" ],
      "url" : "https://t.co/gzjUqq0opX",
      "media_url" : "http://pbs.twimg.com/media/DXkgqnxWsAAy7NN.jpg",
      "id_str" : "970843111277637632",
      "id" : "970843111277637632",
      "media_url_https" : "https://pbs.twimg.com/media/DXkgqnxWsAAy7NN.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "256",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "784",
          "h" : "295",
          "resize" : "fit"
        },
        "large" : {
          "w" : "784",
          "h" : "295",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/gzjUqq0opX"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "BHM18",
      "indices" : [ "38", "44" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "Nyumburu",
      "screen_name" : "Nyumburu",
      "indices" : [ "75", "84" ],
      "id_str" : "339853945",
      "id" : "339853945"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "969038014092595205",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "969038014092595205",
  "created_at" : "Thu Mar 01 02:34:01 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: Don't miss tonight's #BHM18 Closing Ceremony! Come out to @Nyumburu at 5:30 for student speakers, entertainment, and dinne…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Bibiana Valdes",
      "screen_name" : "BIBI_HUNDREDS",
      "indices" : [ "3", "17" ],
      "id_str" : "161924596",
      "id" : "161924596"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "0",
  "id_str" : "968960647265509376",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "968960647265509376",
  "created_at" : "Wed Feb 28 21:26:35 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @BIBI_HUNDREDS: Join PLUMAS, CLSO &amp; UndocuTerp as we discuss the history of TPS and the U.S intervention that took part in causing the c…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/BF2sc8Tyr2",
      "expanded_url" : "https://twitter.com/ogtomiwa/status/968919636413698048",
      "display_url" : "twitter.com/ogtomiwa/statu…",
      "indices" : [ "50", "73" ]
    } ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "2",
  "id_str" : "968958706435198976",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "968958706435198976",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 28 21:18:52 +0000 2018",
  "favorited" : false,
  "full_text" : "We can verify that this is a fact. \n\n- Management https://t.co/BF2sc8Tyr2",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "ChapelUMD",
      "screen_name" : "ChapelUMD",
      "indices" : [ "61", "71" ],
      "id_str" : "2427769519",
      "id" : "2427769519"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "968918145225445376",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "968918145225445376",
  "created_at" : "Wed Feb 28 18:37:42 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: Need help making it through hump day? Visit @ChapelUMD today between 12:30 and 2PM for Wind Down Wednesday! Head to their…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Business Assoc",
      "screen_name" : "BBATerp",
      "indices" : [ "3", "11" ],
      "id_str" : "368458309",
      "id" : "368458309"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/BBATerp/status/968552402206027776/photo/1",
      "source_status_id" : "968552402206027776",
      "indices" : [ "41", "64" ],
      "url" : "https://t.co/e7KwbXwis4",
      "media_url" : "http://pbs.twimg.com/media/DXD9RfrX4AAPnXI.jpg",
      "id_str" : "968552396887678976",
      "source_user_id" : "368458309",
      "id" : "968552396887678976",
      "media_url_https" : "https://pbs.twimg.com/media/DXD9RfrX4AAPnXI.jpg",
      "source_user_id_str" : "368458309",
      "sizes" : {
        "small" : {
          "w" : "639",
          "h" : "625",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "639",
          "h" : "625",
          "resize" : "fit"
        },
        "large" : {
          "w" : "639",
          "h" : "625",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "968552402206027776",
      "display_url" : "pic.twitter.com/e7KwbXwis4"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "0",
  "id_str" : "968586452190756865",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "968586452190756865",
  "possibly_sensitive" : false,
  "created_at" : "Tue Feb 27 20:39:40 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @BBATerp: Come bond with us ! TONIGHT https://t.co/e7KwbXwis4",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/BBATerp/status/968552402206027776/photo/1",
      "source_status_id" : "968552402206027776",
      "indices" : [ "41", "64" ],
      "url" : "https://t.co/e7KwbXwis4",
      "media_url" : "http://pbs.twimg.com/media/DXD9RfrX4AAPnXI.jpg",
      "id_str" : "968552396887678976",
      "source_user_id" : "368458309",
      "id" : "968552396887678976",
      "media_url_https" : "https://pbs.twimg.com/media/DXD9RfrX4AAPnXI.jpg",
      "source_user_id_str" : "368458309",
      "sizes" : {
        "small" : {
          "w" : "639",
          "h" : "625",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "639",
          "h" : "625",
          "resize" : "fit"
        },
        "large" : {
          "w" : "639",
          "h" : "625",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "968552402206027776",
      "display_url" : "pic.twitter.com/e7KwbXwis4"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/BllffXDyKT",
      "expanded_url" : "https://twitter.com/umcpasa/status/968540492060381185",
      "display_url" : "twitter.com/umcpasa/status…",
      "indices" : [ "58", "81" ]
    } ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "1",
  "id_str" : "968555368094846976",
  "truncated" : false,
  "retweet_count" : "3",
  "id" : "968555368094846976",
  "possibly_sensitive" : false,
  "created_at" : "Tue Feb 27 18:36:09 +0000 2018",
  "favorited" : false,
  "full_text" : "End black history month on a high note! (And a tasty one) https://t.co/BllffXDyKT",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Maryland M.A.N.E.",
      "screen_name" : "MarylandMANE",
      "indices" : [ "3", "16" ],
      "id_str" : "1220165886",
      "id" : "1220165886"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "968551290707021825",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "968551290707021825",
  "created_at" : "Tue Feb 27 18:19:57 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @MarylandMANE: Today's the day! You know where to be at 6pm ✨ \n\nCome out as we learn about black representation in entertainment. Enjoy…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/967083673802674182/photo/1",
      "indices" : [ "123", "146" ],
      "url" : "https://t.co/w0lSx8gC8H",
      "media_url" : "http://pbs.twimg.com/media/DWvFeLNWkAAB2LY.jpg",
      "id_str" : "967083667196645376",
      "id" : "967083667196645376",
      "media_url_https" : "https://pbs.twimg.com/media/DWvFeLNWkAAB2LY.jpg",
      "sizes" : {
        "large" : {
          "w" : "539",
          "h" : "691",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "530",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "539",
          "h" : "691",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/w0lSx8gC8H"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "146" ],
  "favorite_count" : "0",
  "id_str" : "967083673802674182",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "967083673802674182",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 23 17:08:10 +0000 2018",
  "favorited" : false,
  "full_text" : "A Rube Goldberg machine event , with free insomnia cookies! Go see the cool stuff that the engineers made \uD83D\uDC69\uD83C\uDFFE‍\uD83C\uDFED\uD83D\uDC68\uD83C\uDFFF‍\uD83C\uDFED\uD83D\uDC69\uD83C\uDFFB‍\uD83C\uDFED\uD83D\uDC68\uD83C\uDFFC‍\uD83C\uDFED https://t.co/w0lSx8gC8H",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/967083673802674182/photo/1",
      "indices" : [ "123", "146" ],
      "url" : "https://t.co/w0lSx8gC8H",
      "media_url" : "http://pbs.twimg.com/media/DWvFeLNWkAAB2LY.jpg",
      "id_str" : "967083667196645376",
      "id" : "967083667196645376",
      "media_url_https" : "https://pbs.twimg.com/media/DWvFeLNWkAAB2LY.jpg",
      "sizes" : {
        "large" : {
          "w" : "539",
          "h" : "691",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "530",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "539",
          "h" : "691",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/w0lSx8gC8H"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "966452003634368512",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "966452003634368512",
  "created_at" : "Wed Feb 21 23:18:08 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: Brunch + tips for success = BEST MORNING EVER. \uD83D\uDE0B Head to Brunch for Success tomorrow, 10AM-noon in the Colony Ballroom to…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Undocumented",
      "indices" : [ "103", "116" ]
    }, {
      "text" : "UMD",
      "indices" : [ "120", "124" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "U of MD MICA",
      "screen_name" : "UMDMICA",
      "indices" : [ "139", "147" ],
      "id_str" : "75010872",
      "id" : "75010872"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "148" ],
  "favorite_count" : "0",
  "id_str" : "966330476100227072",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "966330476100227072",
  "created_at" : "Wed Feb 21 15:15:13 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: TODAY: come talk about race, education, &amp; immigration at UndocuBlack: Black &amp; #Undocumented at #UMD—5:30PM in the @UMDMICA…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/kuy1LWucIX",
      "expanded_url" : "https://twitter.com/thestampumd/status/966330129805971458",
      "display_url" : "twitter.com/thestampumd/st…",
      "indices" : [ "58", "81" ]
    } ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "2",
  "id_str" : "966330467829080064",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "966330467829080064",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 21 15:15:11 +0000 2018",
  "favorited" : false,
  "full_text" : "Oprah's on the poster??? You KNOW this event will be good https://t.co/kuy1LWucIX",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyumburu",
      "screen_name" : "Nyumburu",
      "indices" : [ "30", "39" ],
      "id_str" : "339853945",
      "id" : "339853945"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/966317325111701505/photo/1",
      "indices" : [ "40", "63" ],
      "url" : "https://t.co/rJGCXlBdKI",
      "media_url" : "http://pbs.twimg.com/media/DWkMdpiV4AAbD3o.jpg",
      "id_str" : "966317298553315328",
      "id" : "966317298553315328",
      "media_url_https" : "https://pbs.twimg.com/media/DWkMdpiV4AAbD3o.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "1000",
          "h" : "1000",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1000",
          "h" : "1000",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/rJGCXlBdKI"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "1",
  "id_str" : "966317325111701505",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "966317325111701505",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 21 14:22:58 +0000 2018",
  "favorited" : false,
  "full_text" : "Don't forget about this today @Nyumburu https://t.co/rJGCXlBdKI",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/966317325111701505/photo/1",
      "indices" : [ "40", "63" ],
      "url" : "https://t.co/rJGCXlBdKI",
      "media_url" : "http://pbs.twimg.com/media/DWkMdpiV4AAbD3o.jpg",
      "id_str" : "966317298553315328",
      "id" : "966317298553315328",
      "media_url_https" : "https://pbs.twimg.com/media/DWkMdpiV4AAbD3o.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "1000",
          "h" : "1000",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1000",
          "h" : "1000",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/rJGCXlBdKI"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/966311009827909632/photo/1",
      "indices" : [ "43", "66" ],
      "url" : "https://t.co/ljirJ8zRTp",
      "media_url" : "http://pbs.twimg.com/media/DWkGu0eWkAAKcPp.jpg",
      "id_str" : "966310996477382656",
      "id" : "966310996477382656",
      "media_url_https" : "https://pbs.twimg.com/media/DWkGu0eWkAAKcPp.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/ljirJ8zRTp"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "66" ],
  "favorite_count" : "4",
  "id_str" : "966311009827909632",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "966311009827909632",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 21 13:57:52 +0000 2018",
  "favorited" : false,
  "full_text" : "Check this out on Thursday !!@kraziburrito https://t.co/ljirJ8zRTp",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/966311009827909632/photo/1",
      "indices" : [ "43", "66" ],
      "url" : "https://t.co/ljirJ8zRTp",
      "media_url" : "http://pbs.twimg.com/media/DWkGu0eWkAAKcPp.jpg",
      "id_str" : "966310996477382656",
      "id" : "966310996477382656",
      "media_url_https" : "https://pbs.twimg.com/media/DWkGu0eWkAAKcPp.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/ljirJ8zRTp"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/CK5nupXc0r",
      "expanded_url" : "https://careers.umd.edu/event/diversity-brunch-success-networking-event",
      "display_url" : "careers.umd.edu/event/diversit…",
      "indices" : [ "158", "181" ]
    } ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/964292668800069632/photo/1",
      "indices" : [ "182", "205" ],
      "url" : "https://t.co/PSuUES7jsf",
      "media_url" : "http://pbs.twimg.com/media/DWHbESRX0AIqjTq.jpg",
      "id_str" : "964292661904658434",
      "id" : "964292661904658434",
      "media_url_https" : "https://pbs.twimg.com/media/DWHbESRX0AIqjTq.jpg",
      "sizes" : {
        "large" : {
          "w" : "960",
          "h" : "741",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "741",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "525",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/PSuUES7jsf"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "205" ],
  "favorite_count" : "0",
  "id_str" : "964292668800069632",
  "truncated" : false,
  "retweet_count" : "2",
  "id" : "964292668800069632",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 16 00:17:42 +0000 2018",
  "favorited" : false,
  "full_text" : "Get some FREE Brunch food and get plugged up to companies during spring career fair next week like BMI, CBS and Blue Cross Blue Shield! Gotta register though https://t.co/CK5nupXc0r https://t.co/PSuUES7jsf",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/964292668800069632/photo/1",
      "indices" : [ "182", "205" ],
      "url" : "https://t.co/PSuUES7jsf",
      "media_url" : "http://pbs.twimg.com/media/DWHbESRX0AIqjTq.jpg",
      "id_str" : "964292661904658434",
      "id" : "964292661904658434",
      "media_url_https" : "https://pbs.twimg.com/media/DWHbESRX0AIqjTq.jpg",
      "sizes" : {
        "large" : {
          "w" : "960",
          "h" : "741",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "741",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "525",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/PSuUES7jsf"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "TerpZone",
      "screen_name" : "UMDTerpZone",
      "indices" : [ "26", "38" ],
      "id_str" : "169553077",
      "id" : "169553077"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/thestampumd/status/963794887496949765/photo/1",
      "source_status_id" : "963794887496949765",
      "indices" : [ "73", "96" ],
      "url" : "https://t.co/C27r27d2Zo",
      "media_url" : "http://pbs.twimg.com/media/DWAWHyzW0AEG6TJ.jpg",
      "id_str" : "963794643409358849",
      "source_user_id" : "59604041",
      "id" : "963794643409358849",
      "media_url_https" : "https://pbs.twimg.com/media/DWAWHyzW0AEG6TJ.jpg",
      "source_user_id_str" : "59604041",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1512",
          "h" : "1872",
          "resize" : "fit"
        },
        "small" : {
          "w" : "549",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "969",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "963794887496949765",
      "display_url" : "pic.twitter.com/C27r27d2Zo"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "96" ],
  "favorite_count" : "0",
  "id_str" : "963807052710674432",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "963807052710674432",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 14 16:08:02 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: Swing by @UMDTerpZone for some sweet treats today! ❤️\uD83C\uDF6B\uD83D\uDC8B https://t.co/C27r27d2Zo",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/thestampumd/status/963794887496949765/photo/1",
      "source_status_id" : "963794887496949765",
      "indices" : [ "73", "96" ],
      "url" : "https://t.co/C27r27d2Zo",
      "media_url" : "http://pbs.twimg.com/media/DWAWHyzW0AEG6TJ.jpg",
      "id_str" : "963794643409358849",
      "source_user_id" : "59604041",
      "id" : "963794643409358849",
      "media_url_https" : "https://pbs.twimg.com/media/DWAWHyzW0AEG6TJ.jpg",
      "source_user_id_str" : "59604041",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1512",
          "h" : "1872",
          "resize" : "fit"
        },
        "small" : {
          "w" : "549",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "969",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "963794887496949765",
      "display_url" : "pic.twitter.com/C27r27d2Zo"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NCNW UMD SECTION",
      "screen_name" : "NCNWUMD",
      "indices" : [ "58", "66" ],
      "id_str" : "407939313",
      "id" : "407939313"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/962428928832016384/photo/1",
      "indices" : [ "67", "90" ],
      "url" : "https://t.co/feetX1JyeC",
      "media_url" : "http://pbs.twimg.com/media/DVs8AMfWkAA5PjZ.jpg",
      "id_str" : "962428919424126976",
      "id" : "962428919424126976",
      "media_url_https" : "https://pbs.twimg.com/media/DVs8AMfWkAA5PjZ.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "486",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "686",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "686",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/feetX1JyeC"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "90" ],
  "favorite_count" : "2",
  "id_str" : "962428928832016384",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "962428928832016384",
  "possibly_sensitive" : false,
  "created_at" : "Sat Feb 10 20:51:52 +0000 2018",
  "favorited" : false,
  "full_text" : "Come out to this event later today for free food and fun! @NCNWUMD https://t.co/feetX1JyeC",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/962428928832016384/photo/1",
      "indices" : [ "67", "90" ],
      "url" : "https://t.co/feetX1JyeC",
      "media_url" : "http://pbs.twimg.com/media/DVs8AMfWkAA5PjZ.jpg",
      "id_str" : "962428919424126976",
      "id" : "962428919424126976",
      "media_url_https" : "https://pbs.twimg.com/media/DVs8AMfWkAA5PjZ.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "486",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "686",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "686",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/feetX1JyeC"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaryPIRG ＵＭＤ",
      "screen_name" : "MaryPIRG",
      "indices" : [ "20", "29" ],
      "id_str" : "165962405",
      "id" : "165962405"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/961809936622804992/photo/1",
      "indices" : [ "30", "53" ],
      "url" : "https://t.co/9UeY0SVBtQ",
      "media_url" : "http://pbs.twimg.com/media/DVkJCcUUMAASZ7R.jpg",
      "id_str" : "961809932986101760",
      "id" : "961809932986101760",
      "media_url_https" : "https://pbs.twimg.com/media/DVkJCcUUMAASZ7R.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "720",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "720",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/9UeY0SVBtQ"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "id_str" : "961809936622804992",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "961809936622804992",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 09 03:52:13 +0000 2018",
  "favorited" : false,
  "full_text" : "There will be food! @MaryPIRG https://t.co/9UeY0SVBtQ",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/961809936622804992/photo/1",
      "indices" : [ "30", "53" ],
      "url" : "https://t.co/9UeY0SVBtQ",
      "media_url" : "http://pbs.twimg.com/media/DVkJCcUUMAASZ7R.jpg",
      "id_str" : "961809932986101760",
      "id" : "961809932986101760",
      "media_url_https" : "https://pbs.twimg.com/media/DVkJCcUUMAASZ7R.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "720",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "720",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/9UeY0SVBtQ"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "Transfer&Off-Campus",
      "screen_name" : "UMDTOCSL",
      "indices" : [ "82", "91" ],
      "id_str" : "1205397097",
      "id" : "1205397097"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "961222309301444608",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "961222309301444608",
  "created_at" : "Wed Feb 07 12:57:11 +0000 2018",
  "favorited" : false,
  "full_text" : "RT @thestampumd: No icy conditions for us, so Good Morning, Commuters is ON! Join @UMDTOCSL this morning for breakfast and great conversati…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "73", "85" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "Transfer&Off-Campus",
      "screen_name" : "UMDTOCSL",
      "indices" : [ "86", "95" ],
      "id_str" : "1205397097",
      "id" : "1205397097"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/961216429709316097/photo/1",
      "indices" : [ "96", "119" ],
      "url" : "https://t.co/qXyVJMv40W",
      "media_url" : "http://pbs.twimg.com/media/DVbtPwVXUAAp_Dq.jpg",
      "id_str" : "961216425418510336",
      "id" : "961216425418510336",
      "media_url_https" : "https://pbs.twimg.com/media/DVbtPwVXUAAp_Dq.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "464",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "801",
          "h" : "547",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "801",
          "h" : "547",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/qXyVJMv40W"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "119" ],
  "favorite_count" : "6",
  "id_str" : "961216429709316097",
  "truncated" : false,
  "retweet_count" : "2",
  "id" : "961216429709316097",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 07 12:33:50 +0000 2018",
  "favorited" : false,
  "full_text" : "Free breakfast for transfer and off campus Terps in the atrium of STAMP. @thestampumd @UMDTOCSL https://t.co/qXyVJMv40W",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/961216429709316097/photo/1",
      "indices" : [ "96", "119" ],
      "url" : "https://t.co/qXyVJMv40W",
      "media_url" : "http://pbs.twimg.com/media/DVbtPwVXUAAp_Dq.jpg",
      "id_str" : "961216425418510336",
      "id" : "961216425418510336",
      "media_url_https" : "https://pbs.twimg.com/media/DVbtPwVXUAAp_Dq.jpg",
      "sizes" : {
        "small" : {
          "w" : "680",
          "h" : "464",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "801",
          "h" : "547",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "801",
          "h" : "547",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/qXyVJMv40W"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Jeopardy Club",
      "screen_name" : "jeopardyclubumd",
      "indices" : [ "5", "21" ],
      "id_str" : "928534703048622080",
      "id" : "928534703048622080"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/961213099935223809/photo/1",
      "indices" : [ "54", "77" ],
      "url" : "https://t.co/Gmt0NwV91s",
      "media_url" : "http://pbs.twimg.com/media/DVbqN46W4AU2UCH.jpg",
      "id_str" : "961213094826532869",
      "id" : "961213094826532869",
      "media_url_https" : "https://pbs.twimg.com/media/DVbqN46W4AU2UCH.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "830",
          "h" : "1200",
          "resize" : "fit"
        },
        "small" : {
          "w" : "470",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1107",
          "h" : "1600",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/Gmt0NwV91s"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "77" ],
  "favorite_count" : "1",
  "id_str" : "961213099935223809",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "961213099935223809",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 07 12:20:36 +0000 2018",
  "favorited" : false,
  "full_text" : "Join @jeopardyclubumd tonight for food and jeopardy!! https://t.co/Gmt0NwV91s",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/961213099935223809/photo/1",
      "indices" : [ "54", "77" ],
      "url" : "https://t.co/Gmt0NwV91s",
      "media_url" : "http://pbs.twimg.com/media/DVbqN46W4AU2UCH.jpg",
      "id_str" : "961213094826532869",
      "id" : "961213094826532869",
      "media_url_https" : "https://pbs.twimg.com/media/DVbqN46W4AU2UCH.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "830",
          "h" : "1200",
          "resize" : "fit"
        },
        "small" : {
          "w" : "470",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1107",
          "h" : "1600",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/Gmt0NwV91s"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/961212368175935488/photo/1",
      "indices" : [ "29", "52" ],
      "url" : "https://t.co/hfmiGlNNCv",
      "media_url" : "http://pbs.twimg.com/media/DVbpjU0WkAAM8Y-.jpg",
      "id_str" : "961212363583164416",
      "id" : "961212363583164416",
      "media_url_https" : "https://pbs.twimg.com/media/DVbpjU0WkAAM8Y-.jpg",
      "sizes" : {
        "medium" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/hfmiGlNNCv"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "0",
  "id_str" : "961212368175935488",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "961212368175935488",
  "possibly_sensitive" : false,
  "created_at" : "Wed Feb 07 12:17:41 +0000 2018",
  "favorited" : false,
  "full_text" : "News break at Nyumburu today https://t.co/hfmiGlNNCv",
  "lang" : "in",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/961212368175935488/photo/1",
      "indices" : [ "29", "52" ],
      "url" : "https://t.co/hfmiGlNNCv",
      "media_url" : "http://pbs.twimg.com/media/DVbpjU0WkAAM8Y-.jpg",
      "id_str" : "961212363583164416",
      "id" : "961212363583164416",
      "media_url_https" : "https://pbs.twimg.com/media/DVbpjU0WkAAM8Y-.jpg",
      "sizes" : {
        "medium" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/hfmiGlNNCv"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/959388559449915392/photo/1",
      "indices" : [ "50", "73" ],
      "url" : "https://t.co/RhP2REQyrY",
      "media_url" : "http://pbs.twimg.com/media/DVBuzkVVMAANw4e.jpg",
      "id_str" : "959388552835444736",
      "id" : "959388552835444736",
      "media_url_https" : "https://pbs.twimg.com/media/DVBuzkVVMAANw4e.jpg",
      "sizes" : {
        "large" : {
          "w" : "775",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "549",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "775",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/RhP2REQyrY"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "6",
  "id_str" : "959388559449915392",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "959388559449915392",
  "possibly_sensitive" : false,
  "created_at" : "Fri Feb 02 11:30:31 +0000 2018",
  "favorited" : false,
  "full_text" : "Hip hop and free food tomorrow! You’re welcome :) https://t.co/RhP2REQyrY",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/959388559449915392/photo/1",
      "indices" : [ "50", "73" ],
      "url" : "https://t.co/RhP2REQyrY",
      "media_url" : "http://pbs.twimg.com/media/DVBuzkVVMAANw4e.jpg",
      "id_str" : "959388552835444736",
      "id" : "959388552835444736",
      "media_url_https" : "https://pbs.twimg.com/media/DVBuzkVVMAANw4e.jpg",
      "sizes" : {
        "large" : {
          "w" : "775",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "549",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "775",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/RhP2REQyrY"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/956163750981197825/photo/1",
      "indices" : [ "86", "109" ],
      "url" : "https://t.co/UCguv9I6jC",
      "media_url" : "http://pbs.twimg.com/media/DUT53JXXkAAxIcZ.jpg",
      "id_str" : "956163746711441408",
      "id" : "956163746711441408",
      "media_url_https" : "https://pbs.twimg.com/media/DUT53JXXkAAxIcZ.jpg",
      "sizes" : {
        "medium" : {
          "w" : "1080",
          "h" : "1080",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1080",
          "h" : "1080",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/UCguv9I6jC"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "109" ],
  "favorite_count" : "2",
  "id_str" : "956163750981197825",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "956163750981197825",
  "possibly_sensitive" : false,
  "created_at" : "Wed Jan 24 13:56:17 +0000 2018",
  "favorited" : false,
  "full_text" : "Welcome back UMD! News break at Nyumburu from 11:50 - 12:50. Free Pizza and beverage. https://t.co/UCguv9I6jC",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/956163750981197825/photo/1",
      "indices" : [ "86", "109" ],
      "url" : "https://t.co/UCguv9I6jC",
      "media_url" : "http://pbs.twimg.com/media/DUT53JXXkAAxIcZ.jpg",
      "id_str" : "956163746711441408",
      "id" : "956163746711441408",
      "media_url_https" : "https://pbs.twimg.com/media/DUT53JXXkAAxIcZ.jpg",
      "sizes" : {
        "medium" : {
          "w" : "1080",
          "h" : "1080",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1080",
          "h" : "1080",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/UCguv9I6jC"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "62" ],
  "favorite_count" : "4",
  "id_str" : "943205762062577664",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "943205762062577664",
  "created_at" : "Tue Dec 19 19:45:52 +0000 2017",
  "favorited" : false,
  "full_text" : "Happy Holidays UMD! We’ll be back next semester !! \uD83E\uDD58 \uD83C\uDF55\uD83C\uDF66\uD83C\uDF70\uD83C\uDF6A\uD83C\uDF69☕️\uD83C\uDF54\uD83C\uDF2D",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/thestampumd/status/940618515412914177/photo/1",
      "source_status_id" : "940618515412914177",
      "indices" : [ "73", "96" ],
      "url" : "https://t.co/o2OjKUeEC1",
      "media_url" : "http://pbs.twimg.com/media/DQ2_P73XUAAyw7b.jpg",
      "id_str" : "940618177679151104",
      "source_user_id" : "59604041",
      "id" : "940618177679151104",
      "media_url_https" : "https://pbs.twimg.com/media/DQ2_P73XUAAyw7b.jpg",
      "source_user_id_str" : "59604041",
      "sizes" : {
        "large" : {
          "w" : "2048",
          "h" : "2048",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "1200",
          "h" : "1200",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "940618515412914177",
      "display_url" : "pic.twitter.com/o2OjKUeEC1"
    } ],
    "hashtags" : [ {
      "text" : "STAMPSTUDYZONE",
      "indices" : [ "50", "65" ]
    } ]
  },
  "display_text_range" : [ "0", "96" ],
  "favorite_count" : "0",
  "id_str" : "940619543889793026",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "940619543889793026",
  "possibly_sensitive" : false,
  "created_at" : "Tue Dec 12 16:29:09 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @thestampumd: \uD83C\uDF89\uD83C\uDF55\uD83C\uDF89\uD83C\uDF55 FREE PIZZA TODAY AS PART OF #STAMPSTUDYZONE!! \uD83C\uDF55\uD83C\uDF89\uD83C\uDF55\uD83C\uDF89 https://t.co/o2OjKUeEC1",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/thestampumd/status/940618515412914177/photo/1",
      "source_status_id" : "940618515412914177",
      "indices" : [ "73", "96" ],
      "url" : "https://t.co/o2OjKUeEC1",
      "media_url" : "http://pbs.twimg.com/media/DQ2_P73XUAAyw7b.jpg",
      "id_str" : "940618177679151104",
      "source_user_id" : "59604041",
      "id" : "940618177679151104",
      "media_url_https" : "https://pbs.twimg.com/media/DQ2_P73XUAAyw7b.jpg",
      "source_user_id_str" : "59604041",
      "sizes" : {
        "large" : {
          "w" : "2048",
          "h" : "2048",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "1200",
          "h" : "1200",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "940618515412914177",
      "display_url" : "pic.twitter.com/o2OjKUeEC1"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "40", "52" ],
      "id_str" : "59604041",
      "id" : "59604041"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "65" ],
  "favorite_count" : "2",
  "id_str" : "940595653775937536",
  "truncated" : false,
  "retweet_count" : "2",
  "id" : "940595653775937536",
  "created_at" : "Tue Dec 12 14:54:13 +0000 2017",
  "favorited" : false,
  "full_text" : "Free pancakes and waffles in PG room at @thestampumd until 11:30!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/938797009636614145/photo/1",
      "indices" : [ "15", "38" ],
      "url" : "https://t.co/XCDawyIAI4",
      "media_url" : "http://pbs.twimg.com/media/DQdG5uBU8AELOsB.jpg",
      "id_str" : "938797004750123009",
      "id" : "938797004750123009",
      "media_url_https" : "https://pbs.twimg.com/media/DQdG5uBU8AELOsB.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "large" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "526",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/XCDawyIAI4"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "38" ],
  "favorite_count" : "0",
  "id_str" : "938797009636614145",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "938797009636614145",
  "possibly_sensitive" : false,
  "created_at" : "Thu Dec 07 15:47:03 +0000 2017",
  "favorited" : false,
  "full_text" : "Happening soon https://t.co/XCDawyIAI4",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/938797009636614145/photo/1",
      "indices" : [ "15", "38" ],
      "url" : "https://t.co/XCDawyIAI4",
      "media_url" : "http://pbs.twimg.com/media/DQdG5uBU8AELOsB.jpg",
      "id_str" : "938797004750123009",
      "id" : "938797004750123009",
      "media_url_https" : "https://pbs.twimg.com/media/DQdG5uBU8AELOsB.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "large" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "526",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/XCDawyIAI4"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CMSE",
      "screen_name" : "CMSEUMD",
      "indices" : [ "5", "13" ],
      "id_str" : "2201812292",
      "id" : "2201812292"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/938412841354358784/photo/1",
      "indices" : [ "66", "89" ],
      "url" : "https://t.co/yLVw1tsEoP",
      "media_url" : "http://pbs.twimg.com/media/DQXpgP3X0AExE2L.jpg",
      "id_str" : "938412837600481281",
      "id" : "938412837600481281",
      "media_url_https" : "https://pbs.twimg.com/media/DQXpgP3X0AExE2L.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "480",
          "h" : "672",
          "resize" : "fit"
        },
        "small" : {
          "w" : "480",
          "h" : "672",
          "resize" : "fit"
        },
        "large" : {
          "w" : "480",
          "h" : "672",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/yLVw1tsEoP"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "89" ],
  "favorite_count" : "1",
  "id_str" : "938412841354358784",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "938412841354358784",
  "possibly_sensitive" : false,
  "created_at" : "Wed Dec 06 14:20:30 +0000 2017",
  "favorited" : false,
  "full_text" : "Join @CMSEUMD on Friday for their Christmas party. Food and games https://t.co/yLVw1tsEoP",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/938412841354358784/photo/1",
      "indices" : [ "66", "89" ],
      "url" : "https://t.co/yLVw1tsEoP",
      "media_url" : "http://pbs.twimg.com/media/DQXpgP3X0AExE2L.jpg",
      "id_str" : "938412837600481281",
      "id" : "938412837600481281",
      "media_url_https" : "https://pbs.twimg.com/media/DQXpgP3X0AExE2L.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "480",
          "h" : "672",
          "resize" : "fit"
        },
        "small" : {
          "w" : "480",
          "h" : "672",
          "resize" : "fit"
        },
        "large" : {
          "w" : "480",
          "h" : "672",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/yLVw1tsEoP"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/937811274599141378/photo/1",
      "indices" : [ "37", "60" ],
      "url" : "https://t.co/tJyKEVUyep",
      "media_url" : "http://pbs.twimg.com/media/DQPGUn3WsAIpeg2.jpg",
      "id_str" : "937811205024034818",
      "id" : "937811205024034818",
      "media_url_https" : "https://pbs.twimg.com/media/DQPGUn3WsAIpeg2.jpg",
      "sizes" : {
        "medium" : {
          "w" : "683",
          "h" : "345",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "683",
          "h" : "345",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "343",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/tJyKEVUyep"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "60" ],
  "favorite_count" : "0",
  "id_str" : "937811274599141378",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "937811274599141378",
  "possibly_sensitive" : false,
  "created_at" : "Mon Dec 04 22:30:06 +0000 2017",
  "favorited" : false,
  "full_text" : "It’s not too late to get some pizza! https://t.co/tJyKEVUyep",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/937811274599141378/photo/1",
      "indices" : [ "37", "60" ],
      "url" : "https://t.co/tJyKEVUyep",
      "media_url" : "http://pbs.twimg.com/media/DQPGUn3WsAIpeg2.jpg",
      "id_str" : "937811205024034818",
      "id" : "937811205024034818",
      "media_url_https" : "https://pbs.twimg.com/media/DQPGUn3WsAIpeg2.jpg",
      "sizes" : {
        "medium" : {
          "w" : "683",
          "h" : "345",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "683",
          "h" : "345",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "343",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/tJyKEVUyep"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "935879940192526336",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "935879940192526336",
  "created_at" : "Wed Nov 29 14:35:40 +0000 2017",
  "favorited" : false,
  "full_text" : "Don’t sleep in newsbreak at Nyumburu. 11:50 am - 12:50pm. Free pizza and drinks!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/935303196234387461/photo/1",
      "indices" : [ "45", "68" ],
      "url" : "https://t.co/SeSTYFtgE6",
      "media_url" : "http://pbs.twimg.com/media/DPrdTAQW4AA-iWz.jpg",
      "id_str" : "935303191188660224",
      "id" : "935303191188660224",
      "media_url_https" : "https://pbs.twimg.com/media/DPrdTAQW4AA-iWz.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "750",
          "h" : "349",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "316",
          "resize" : "fit"
        },
        "large" : {
          "w" : "750",
          "h" : "349",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/SeSTYFtgE6"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "68" ],
  "favorite_count" : "1",
  "id_str" : "935303196234387461",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "935303196234387461",
  "possibly_sensitive" : false,
  "created_at" : "Tue Nov 28 00:23:53 +0000 2017",
  "favorited" : false,
  "full_text" : "Pretty soon tonight! Snacks will be provided https://t.co/SeSTYFtgE6",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/935303196234387461/photo/1",
      "indices" : [ "45", "68" ],
      "url" : "https://t.co/SeSTYFtgE6",
      "media_url" : "http://pbs.twimg.com/media/DPrdTAQW4AA-iWz.jpg",
      "id_str" : "935303191188660224",
      "id" : "935303191188660224",
      "media_url_https" : "https://pbs.twimg.com/media/DPrdTAQW4AA-iWz.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "750",
          "h" : "349",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "316",
          "resize" : "fit"
        },
        "large" : {
          "w" : "750",
          "h" : "349",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/SeSTYFtgE6"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/935266178343342080/photo/1",
      "indices" : [ "35", "58" ],
      "url" : "https://t.co/S6skSDnxPv",
      "media_url" : "http://pbs.twimg.com/media/DPq7oSXWAAAy8q_.jpg",
      "id_str" : "935266173431709696",
      "id" : "935266173431709696",
      "media_url_https" : "https://pbs.twimg.com/media/DPq7oSXWAAAy8q_.jpg",
      "sizes" : {
        "medium" : {
          "w" : "960",
          "h" : "836",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "960",
          "h" : "836",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "592",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/S6skSDnxPv"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "58" ],
  "favorite_count" : "1",
  "id_str" : "935266178343342080",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "935266178343342080",
  "possibly_sensitive" : false,
  "created_at" : "Mon Nov 27 21:56:47 +0000 2017",
  "favorited" : false,
  "full_text" : "Tonight for all you dessert lovers https://t.co/S6skSDnxPv",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/935266178343342080/photo/1",
      "indices" : [ "35", "58" ],
      "url" : "https://t.co/S6skSDnxPv",
      "media_url" : "http://pbs.twimg.com/media/DPq7oSXWAAAy8q_.jpg",
      "id_str" : "935266173431709696",
      "id" : "935266173431709696",
      "media_url_https" : "https://pbs.twimg.com/media/DPq7oSXWAAAy8q_.jpg",
      "sizes" : {
        "medium" : {
          "w" : "960",
          "h" : "836",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "960",
          "h" : "836",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "592",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/S6skSDnxPv"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/934946044131053568/photo/1",
      "indices" : [ "52", "75" ],
      "url" : "https://t.co/DhQDVjTKtZ",
      "media_url" : "http://pbs.twimg.com/media/DPmYdYEXkAUuf6e.jpg",
      "id_str" : "934946028100489221",
      "id" : "934946028100489221",
      "media_url_https" : "https://pbs.twimg.com/media/DPmYdYEXkAUuf6e.jpg",
      "sizes" : {
        "medium" : {
          "w" : "540",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "383",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "540",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/DhQDVjTKtZ"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "75" ],
  "favorite_count" : "2",
  "id_str" : "934946044131053568",
  "truncated" : false,
  "retweet_count" : "2",
  "id" : "934946044131053568",
  "possibly_sensitive" : false,
  "created_at" : "Mon Nov 27 00:44:42 +0000 2017",
  "favorited" : false,
  "full_text" : "We’re back! And so are all the free food events. \uD83D\uDC47\uD83D\uDC47 https://t.co/DhQDVjTKtZ",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/934946044131053568/photo/1",
      "indices" : [ "52", "75" ],
      "url" : "https://t.co/DhQDVjTKtZ",
      "media_url" : "http://pbs.twimg.com/media/DPmYdYEXkAUuf6e.jpg",
      "id_str" : "934946028100489221",
      "id" : "934946028100489221",
      "media_url_https" : "https://pbs.twimg.com/media/DPmYdYEXkAUuf6e.jpg",
      "sizes" : {
        "medium" : {
          "w" : "540",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "383",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "540",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/DhQDVjTKtZ"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/931616595964846080/photo/1",
      "indices" : [ "17", "40" ],
      "url" : "https://t.co/uo6ns0Xjia",
      "media_url" : "http://pbs.twimg.com/media/DO3EWiIW0AAttbN.jpg",
      "id_str" : "931616589333581824",
      "id" : "931616589333581824",
      "media_url_https" : "https://pbs.twimg.com/media/DO3EWiIW0AAttbN.jpg",
      "sizes" : {
        "large" : {
          "w" : "491",
          "h" : "650",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "491",
          "h" : "650",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "491",
          "h" : "650",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/uo6ns0Xjia"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "40" ],
  "favorite_count" : "0",
  "id_str" : "931616595964846080",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "931616595964846080",
  "possibly_sensitive" : false,
  "created_at" : "Fri Nov 17 20:14:39 +0000 2017",
  "favorited" : false,
  "full_text" : "FREE CHICK-FIL-A https://t.co/uo6ns0Xjia",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/931616595964846080/photo/1",
      "indices" : [ "17", "40" ],
      "url" : "https://t.co/uo6ns0Xjia",
      "media_url" : "http://pbs.twimg.com/media/DO3EWiIW0AAttbN.jpg",
      "id_str" : "931616589333581824",
      "id" : "931616589333581824",
      "media_url_https" : "https://pbs.twimg.com/media/DO3EWiIW0AAttbN.jpg",
      "sizes" : {
        "large" : {
          "w" : "491",
          "h" : "650",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "491",
          "h" : "650",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "491",
          "h" : "650",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/uo6ns0Xjia"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/931175501732999168/photo/1",
      "indices" : [ "8", "31" ],
      "url" : "https://t.co/3MSpDdb5o9",
      "media_url" : "http://pbs.twimg.com/media/DOwzLiGW0AAob9Z.jpg",
      "id_str" : "931175496183894016",
      "id" : "931175496183894016",
      "media_url_https" : "https://pbs.twimg.com/media/DOwzLiGW0AAob9Z.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "525",
          "h" : "675",
          "resize" : "fit"
        },
        "small" : {
          "w" : "525",
          "h" : "675",
          "resize" : "fit"
        },
        "large" : {
          "w" : "525",
          "h" : "675",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/3MSpDdb5o9"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "31" ],
  "favorite_count" : "0",
  "id_str" : "931175501732999168",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "931175501732999168",
  "possibly_sensitive" : false,
  "created_at" : "Thu Nov 16 15:01:54 +0000 2017",
  "favorited" : false,
  "full_text" : "Todayyy https://t.co/3MSpDdb5o9",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/931175501732999168/photo/1",
      "indices" : [ "8", "31" ],
      "url" : "https://t.co/3MSpDdb5o9",
      "media_url" : "http://pbs.twimg.com/media/DOwzLiGW0AAob9Z.jpg",
      "id_str" : "931175496183894016",
      "id" : "931175496183894016",
      "media_url_https" : "https://pbs.twimg.com/media/DOwzLiGW0AAob9Z.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "525",
          "h" : "675",
          "resize" : "fit"
        },
        "small" : {
          "w" : "525",
          "h" : "675",
          "resize" : "fit"
        },
        "large" : {
          "w" : "525",
          "h" : "675",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/3MSpDdb5o9"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/930827029402062849/photo/1",
      "indices" : [ "39", "62" ],
      "url" : "https://t.co/aeSVzkRv7h",
      "media_url" : "http://pbs.twimg.com/media/DOr2PvoXUAAfFaa.jpg",
      "id_str" : "930827023349665792",
      "id" : "930827023349665792",
      "media_url_https" : "https://pbs.twimg.com/media/DOr2PvoXUAAfFaa.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "623",
          "h" : "835",
          "resize" : "fit"
        },
        "large" : {
          "w" : "623",
          "h" : "835",
          "resize" : "fit"
        },
        "small" : {
          "w" : "507",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/aeSVzkRv7h"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "62" ],
  "favorite_count" : "2",
  "id_str" : "930827029402062849",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "930827029402062849",
  "possibly_sensitive" : false,
  "created_at" : "Wed Nov 15 15:57:12 +0000 2017",
  "favorited" : false,
  "full_text" : "Head to the business school right now! https://t.co/aeSVzkRv7h",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/930827029402062849/photo/1",
      "indices" : [ "39", "62" ],
      "url" : "https://t.co/aeSVzkRv7h",
      "media_url" : "http://pbs.twimg.com/media/DOr2PvoXUAAfFaa.jpg",
      "id_str" : "930827023349665792",
      "id" : "930827023349665792",
      "media_url_https" : "https://pbs.twimg.com/media/DOr2PvoXUAAfFaa.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "623",
          "h" : "835",
          "resize" : "fit"
        },
        "large" : {
          "w" : "623",
          "h" : "835",
          "resize" : "fit"
        },
        "small" : {
          "w" : "507",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/aeSVzkRv7h"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/930816850157539335/photo/1",
      "indices" : [ "24", "47" ],
      "url" : "https://t.co/dwwpVyyt4h",
      "media_url" : "http://pbs.twimg.com/media/DOrs_SMX0AA2g__.jpg",
      "id_str" : "930816844965072896",
      "id" : "930816844965072896",
      "media_url_https" : "https://pbs.twimg.com/media/DOrs_SMX0AA2g__.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "750",
          "h" : "563",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "510",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "750",
          "h" : "563",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/dwwpVyyt4h"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "47" ],
  "favorite_count" : "1",
  "id_str" : "930816850157539335",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "930816850157539335",
  "possibly_sensitive" : false,
  "created_at" : "Wed Nov 15 15:16:45 +0000 2017",
  "favorited" : false,
  "full_text" : "Happening at noon today https://t.co/dwwpVyyt4h",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/930816850157539335/photo/1",
      "indices" : [ "24", "47" ],
      "url" : "https://t.co/dwwpVyyt4h",
      "media_url" : "http://pbs.twimg.com/media/DOrs_SMX0AA2g__.jpg",
      "id_str" : "930816844965072896",
      "id" : "930816844965072896",
      "media_url_https" : "https://pbs.twimg.com/media/DOrs_SMX0AA2g__.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "750",
          "h" : "563",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "510",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "750",
          "h" : "563",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/dwwpVyyt4h"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UCA UMD",
      "screen_name" : "UofMarylandUCA",
      "indices" : [ "56", "71" ],
      "id_str" : "2153840792",
      "id" : "2153840792"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/930782060385619968/photo/1",
      "indices" : [ "72", "95" ],
      "url" : "https://t.co/FwtJMku96q",
      "media_url" : "http://pbs.twimg.com/media/DOrNWR-XkAA-4sU.jpg",
      "id_str" : "930782055671238656",
      "id" : "930782055671238656",
      "media_url_https" : "https://pbs.twimg.com/media/DOrNWR-XkAA-4sU.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "599",
          "h" : "837",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "599",
          "h" : "837",
          "resize" : "fit"
        },
        "small" : {
          "w" : "487",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/FwtJMku96q"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "95" ],
  "favorite_count" : "1",
  "id_str" : "930782060385619968",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "930782060385619968",
  "possibly_sensitive" : false,
  "created_at" : "Wed Nov 15 12:58:30 +0000 2017",
  "favorited" : false,
  "full_text" : "Come enjoy pizza and prizes today!! Open to all majors! @UofMarylandUCA https://t.co/FwtJMku96q",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/930782060385619968/photo/1",
      "indices" : [ "72", "95" ],
      "url" : "https://t.co/FwtJMku96q",
      "media_url" : "http://pbs.twimg.com/media/DOrNWR-XkAA-4sU.jpg",
      "id_str" : "930782055671238656",
      "id" : "930782055671238656",
      "media_url_https" : "https://pbs.twimg.com/media/DOrNWR-XkAA-4sU.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "599",
          "h" : "837",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "599",
          "h" : "837",
          "resize" : "fit"
        },
        "small" : {
          "w" : "487",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/FwtJMku96q"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "See Food",
      "screen_name" : "SeeFoodCalendar",
      "indices" : [ "3", "19" ],
      "id_str" : "800904115924717569",
      "id" : "800904115924717569"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "71" ],
  "favorite_count" : "0",
  "id_str" : "930781250532593665",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "930781250532593665",
  "created_at" : "Wed Nov 15 12:55:17 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @SeeFoodCalendar: It’s Wednesday! Free snacks in HJP starting at 3!!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/930619206449672192/photo/1",
      "indices" : [ "59", "82" ],
      "url" : "https://t.co/WqcsIwnz1c",
      "media_url" : "http://pbs.twimg.com/media/DOo5OvxXcAA-OSe.jpg",
      "id_str" : "930619198509903872",
      "id" : "930619198509903872",
      "media_url_https" : "https://pbs.twimg.com/media/DOo5OvxXcAA-OSe.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "599",
          "h" : "837",
          "resize" : "fit"
        },
        "small" : {
          "w" : "487",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "599",
          "h" : "837",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/WqcsIwnz1c"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "82" ],
  "favorite_count" : "0",
  "id_str" : "930619206449672192",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "930619206449672192",
  "possibly_sensitive" : false,
  "created_at" : "Wed Nov 15 02:11:23 +0000 2017",
  "favorited" : false,
  "full_text" : "Come enjoy pizza and prizes tomorrow!! Open to all majors! https://t.co/WqcsIwnz1c",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/930619206449672192/photo/1",
      "indices" : [ "59", "82" ],
      "url" : "https://t.co/WqcsIwnz1c",
      "media_url" : "http://pbs.twimg.com/media/DOo5OvxXcAA-OSe.jpg",
      "id_str" : "930619198509903872",
      "id" : "930619198509903872",
      "media_url_https" : "https://pbs.twimg.com/media/DOo5OvxXcAA-OSe.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "599",
          "h" : "837",
          "resize" : "fit"
        },
        "small" : {
          "w" : "487",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "599",
          "h" : "837",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/WqcsIwnz1c"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "African Terps",
      "screen_name" : "UMCPASA",
      "indices" : [ "5", "13" ],
      "id_str" : "121576899",
      "id" : "121576899"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/930618838126878726/photo/1",
      "indices" : [ "87", "110" ],
      "url" : "https://t.co/Ccs8XqLq5i",
      "media_url" : "http://pbs.twimg.com/media/DOo45JhXkAAqQ8N.jpg",
      "id_str" : "930618827465003008",
      "id" : "930618827465003008",
      "media_url_https" : "https://pbs.twimg.com/media/DOo45JhXkAAqQ8N.jpg",
      "sizes" : {
        "medium" : {
          "w" : "945",
          "h" : "756",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "945",
          "h" : "756",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "544",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/Ccs8XqLq5i"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "110" ],
  "favorite_count" : "7",
  "id_str" : "930618838126878726",
  "truncated" : false,
  "retweet_count" : "9",
  "id" : "930618838126878726",
  "possibly_sensitive" : false,
  "created_at" : "Wed Nov 15 02:09:55 +0000 2017",
  "favorited" : false,
  "full_text" : "Join @UMCPASA tomorrow st 5! Donate a canned food item to enjoy this delicious dinner! https://t.co/Ccs8XqLq5i",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/930618838126878726/photo/1",
      "indices" : [ "87", "110" ],
      "url" : "https://t.co/Ccs8XqLq5i",
      "media_url" : "http://pbs.twimg.com/media/DOo45JhXkAAqQ8N.jpg",
      "id_str" : "930618827465003008",
      "id" : "930618827465003008",
      "media_url_https" : "https://pbs.twimg.com/media/DOo45JhXkAAqQ8N.jpg",
      "sizes" : {
        "medium" : {
          "w" : "945",
          "h" : "756",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "945",
          "h" : "756",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "544",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/Ccs8XqLq5i"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "50" ],
  "favorite_count" : "0",
  "id_str" : "928344670354268166",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "928344670354268166",
  "created_at" : "Wed Nov 08 19:33:11 +0000 2017",
  "favorited" : false,
  "full_text" : "It’s Wednesday! Free snacks in HJP starting at 3!!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/925694468279414784/photo/1",
      "indices" : [ "82", "105" ],
      "url" : "https://t.co/iHEZyKVyP0",
      "media_url" : "http://pbs.twimg.com/media/DNi6NcdXUAAlBz0.jpg",
      "id_str" : "925694463565058048",
      "id" : "925694463565058048",
      "media_url_https" : "https://pbs.twimg.com/media/DNi6NcdXUAAlBz0.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "717",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "508",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "717",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/iHEZyKVyP0"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "105" ],
  "favorite_count" : "0",
  "id_str" : "925694468279414784",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "925694468279414784",
  "possibly_sensitive" : false,
  "created_at" : "Wed Nov 01 12:02:14 +0000 2017",
  "favorited" : false,
  "full_text" : "Check out these events happening tomorrow! Do these fliers mention ‘free food’??? https://t.co/iHEZyKVyP0",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/925694468279414784/photo/1",
      "indices" : [ "82", "105" ],
      "url" : "https://t.co/iHEZyKVyP0",
      "media_url" : "http://pbs.twimg.com/media/DNi6NcdXUAAlBz0.jpg",
      "id_str" : "925694463565058048",
      "id" : "925694463565058048",
      "media_url_https" : "https://pbs.twimg.com/media/DNi6NcdXUAAlBz0.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "717",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "508",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "717",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/iHEZyKVyP0"
    }, {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/925694468279414784/photo/1",
      "indices" : [ "82", "105" ],
      "url" : "https://t.co/iHEZyKVyP0",
      "media_url" : "http://pbs.twimg.com/media/DNi6NccWkAABep6.jpg",
      "id_str" : "925694463560814592",
      "id" : "925694463560814592",
      "media_url_https" : "https://pbs.twimg.com/media/DNi6NccWkAABep6.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "576",
          "h" : "444",
          "resize" : "fit"
        },
        "large" : {
          "w" : "576",
          "h" : "444",
          "resize" : "fit"
        },
        "small" : {
          "w" : "576",
          "h" : "444",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/iHEZyKVyP0"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/o2Qm9a2Dkq",
      "expanded_url" : "https://twitter.com/__lambchops/status/923968641367969792",
      "display_url" : "twitter.com/__lambchops/st…",
      "indices" : [ "19", "42" ]
    } ]
  },
  "display_text_range" : [ "0", "42" ],
  "favorite_count" : "3",
  "id_str" : "924008167272517633",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "924008167272517633",
  "possibly_sensitive" : false,
  "created_at" : "Fri Oct 27 20:21:28 +0000 2017",
  "favorited" : false,
  "full_text" : "Yea...can't relate https://t.co/o2Qm9a2Dkq",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Impressive",
      "indices" : [ "18", "29" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Chris Dax",
      "screen_name" : "TodaysImpact",
      "indices" : [ "3", "16" ],
      "id_str" : "2331100094",
      "id" : "2331100094"
    }, {
      "name" : "See Food",
      "screen_name" : "SeeFoodCalendar",
      "indices" : [ "85", "101" ],
      "id_str" : "800904115924717569",
      "id" : "800904115924717569"
    }, {
      "name" : "Emprology, LLC",
      "screen_name" : "emprology",
      "indices" : [ "102", "112" ],
      "id_str" : "4239776728",
      "id" : "4239776728"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "923964841521446913",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "923964841521446913",
  "created_at" : "Fri Oct 27 17:29:19 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @TodaysImpact: #Impressive. Loved visiting with them all.  Great things ahead for @SeeFoodCalendar @emprology and others. https://t.co/9…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "82" ],
  "favorite_count" : "0",
  "id_str" : "923945721648353280",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "923945721648353280",
  "created_at" : "Fri Oct 27 16:13:20 +0000 2017",
  "favorited" : false,
  "full_text" : "We’re at Terp marketplace today from 12-2 today in Van Munching Hall. Come see us!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/WrhctZ46Fq",
      "expanded_url" : "https://twitter.com/itsbayzuh/status/920816647753097216",
      "display_url" : "twitter.com/itsbayzuh/stat…",
      "indices" : [ "57", "80" ]
    } ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "2",
  "id_str" : "921059915547979778",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "921059915547979778",
  "possibly_sensitive" : false,
  "created_at" : "Thu Oct 19 17:06:10 +0000 2017",
  "favorited" : false,
  "full_text" : "How about a food baby? Check out our events to get one \uD83C\uDF55 https://t.co/WrhctZ46Fq",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GradStudentLife UMD",
      "screen_name" : "UMDGSL",
      "indices" : [ "3", "10" ],
      "id_str" : "768418140",
      "id" : "768418140"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/UMDGSL/status/920990425359323136/photo/1",
      "source_status_id" : "920990425359323136",
      "indices" : [ "71", "94" ],
      "url" : "https://t.co/ghBahlAson",
      "media_url" : "http://pbs.twimg.com/media/DMXp0MEWkAMW1Bu.jpg",
      "id_str" : "920398781669085187",
      "source_user_id" : "768418140",
      "id" : "920398781669085187",
      "media_url_https" : "https://pbs.twimg.com/media/DMXp0MEWkAMW1Bu.jpg",
      "source_user_id_str" : "768418140",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "1200",
          "h" : "826",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "468",
          "resize" : "fit"
        },
        "large" : {
          "w" : "2048",
          "h" : "1410",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "920990425359323136",
      "display_url" : "pic.twitter.com/ghBahlAson"
    } ],
    "hashtags" : [ {
      "text" : "FCT",
      "indices" : [ "64", "68" ]
    } ]
  },
  "display_text_range" : [ "0", "94" ],
  "favorite_count" : "0",
  "id_str" : "921033150737932288",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "921033150737932288",
  "possibly_sensitive" : false,
  "created_at" : "Thu Oct 19 15:19:49 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @UMDGSL: Feeling like a zombie? Grab your mug and WAKE UP at #FCT ☕ https://t.co/ghBahlAson",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/UMDGSL/status/920990425359323136/photo/1",
      "source_status_id" : "920990425359323136",
      "indices" : [ "71", "94" ],
      "url" : "https://t.co/ghBahlAson",
      "media_url" : "http://pbs.twimg.com/media/DMXp0MEWkAMW1Bu.jpg",
      "id_str" : "920398781669085187",
      "source_user_id" : "768418140",
      "id" : "920398781669085187",
      "media_url_https" : "https://pbs.twimg.com/media/DMXp0MEWkAMW1Bu.jpg",
      "source_user_id_str" : "768418140",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "1200",
          "h" : "826",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "468",
          "resize" : "fit"
        },
        "large" : {
          "w" : "2048",
          "h" : "1410",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "920990425359323136",
      "display_url" : "pic.twitter.com/ghBahlAson"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Muslim Alliance for Social Change UMD",
      "screen_name" : "UMD_MASC",
      "indices" : [ "3", "12" ],
      "id_str" : "826908020902920192",
      "id" : "826908020902920192"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/UMD_MASC/status/920740264389595136/video/1",
      "source_status_id" : "920740264389595136",
      "indices" : [ "77", "100" ],
      "url" : "https://t.co/XG1L6ZZoRK",
      "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/920740140754112512/pu/img/D4Gr-LeoL-gzMQl6.jpg",
      "id_str" : "920740140754112512",
      "source_user_id" : "826908020902920192",
      "id" : "920740140754112512",
      "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/920740140754112512/pu/img/D4Gr-LeoL-gzMQl6.jpg",
      "source_user_id_str" : "826908020902920192",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "1200",
          "h" : "675",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "383",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1280",
          "h" : "720",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "920740264389595136",
      "display_url" : "pic.twitter.com/XG1L6ZZoRK"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "100" ],
  "favorite_count" : "0",
  "id_str" : "920777123593375744",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "920777123593375744",
  "possibly_sensitive" : false,
  "created_at" : "Wed Oct 18 22:22:28 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @UMD_MASC: good vibes, light refreshments, and an overall great night \uD83D\uDCAF\uD83D\uDCAF\uD83D\uDCAF https://t.co/XG1L6ZZoRK",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/UMD_MASC/status/920740264389595136/video/1",
      "source_status_id" : "920740264389595136",
      "indices" : [ "77", "100" ],
      "url" : "https://t.co/XG1L6ZZoRK",
      "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/920740140754112512/pu/img/D4Gr-LeoL-gzMQl6.jpg",
      "id_str" : "920740140754112512",
      "video_info" : {
        "aspect_ratio" : [ "16", "9" ],
        "duration_millis" : "47616",
        "variants" : [ {
          "content_type" : "application/x-mpegURL",
          "url" : "https://video.twimg.com/ext_tw_video/920740140754112512/pu/pl/FRe6qNFw33I5DIbD.m3u8"
        }, {
          "bitrate" : "832000",
          "content_type" : "video/mp4",
          "url" : "https://video.twimg.com/ext_tw_video/920740140754112512/pu/vid/640x360/GNgjk-XeJz78t9F1.mp4"
        }, {
          "bitrate" : "2176000",
          "content_type" : "video/mp4",
          "url" : "https://video.twimg.com/ext_tw_video/920740140754112512/pu/vid/1280x720/eO_zW-ovDEQCqB9g.mp4"
        }, {
          "bitrate" : "256000",
          "content_type" : "video/mp4",
          "url" : "https://video.twimg.com/ext_tw_video/920740140754112512/pu/vid/320x180/4PNu5PkaDBzYyKb2.mp4"
        } ]
      },
      "source_user_id" : "826908020902920192",
      "additional_media_info" : {
        "monetizable" : false
      },
      "id" : "920740140754112512",
      "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/920740140754112512/pu/img/D4Gr-LeoL-gzMQl6.jpg",
      "source_user_id_str" : "826908020902920192",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "1200",
          "h" : "675",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "383",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1280",
          "h" : "720",
          "resize" : "fit"
        }
      },
      "type" : "video",
      "source_status_id_str" : "920740264389595136",
      "display_url" : "pic.twitter.com/XG1L6ZZoRK"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Transfer&Off-Campus",
      "screen_name" : "UMDTOCSL",
      "indices" : [ "3", "12" ],
      "id_str" : "1205397097",
      "id" : "1205397097"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "0",
  "id_str" : "920375978790146048",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "920375978790146048",
  "created_at" : "Tue Oct 17 19:48:27 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @UMDTOCSL: Hello TOCSL Terps! You made it to week 8! Wanna learn to better manage time? Come join us this Wednesday for our 3rd Milk &amp; C…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Terps",
      "indices" : [ "57", "63" ]
    }, {
      "text" : "HungryTerps",
      "indices" : [ "64", "76" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Free_Food_UMD",
      "indices" : [ "3", "17" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "76" ],
  "favorite_count" : "0",
  "id_str" : "920372972245929984",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "920372972245929984",
  "created_at" : "Tue Oct 17 19:36:30 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @Free_Food_UMD: Free leftovers in McKeldin Room 6137. #Terps #HungryTerps",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/a9wziZvcvK",
      "expanded_url" : "https://twitter.com/bbaterp/status/920345759882600449",
      "display_url" : "twitter.com/bbaterp/status…",
      "indices" : [ "33", "56" ]
    } ]
  },
  "display_text_range" : [ "0", "56" ],
  "favorite_count" : "0",
  "id_str" : "920372123843158019",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "920372123843158019",
  "possibly_sensitive" : false,
  "created_at" : "Tue Oct 17 19:33:08 +0000 2017",
  "favorited" : false,
  "full_text" : "Chick fil a will also be present https://t.co/a9wziZvcvK",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "2",
  "id_str" : "919778074291556352",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "919778074291556352",
  "created_at" : "Mon Oct 16 04:12:36 +0000 2017",
  "favorited" : false,
  "full_text" : "\"Where's the free food at\"\n\nFirst of all, hit that follow button",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ "86", "96" ],
      "id_str" : "30973",
      "id" : "30973"
    }, {
      "name" : "QuakerOats",
      "screen_name" : "Quaker",
      "indices" : [ "98", "105" ],
      "id_str" : "18940252",
      "id" : "18940252"
    }, {
      "name" : "Maryland Dining",
      "screen_name" : "UMDdining",
      "indices" : [ "106", "116" ],
      "id_str" : "70419335",
      "id" : "70419335"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "116" ],
  "favorite_count" : "1",
  "id_str" : "918110707840929793",
  "truncated" : false,
  "retweet_count" : "2",
  "id" : "918110707840929793",
  "created_at" : "Wed Oct 11 13:47:05 +0000 2017",
  "favorited" : false,
  "full_text" : "Free oatmeal and Starbucks shots in front of South Campus Diner - happening right now @Starbucks  @Quaker @UMDdining",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "Terps",
      "indices" : [ "73", "79" ]
    }, {
      "text" : "HungryTerps",
      "indices" : [ "80", "92" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "Free_Food_UMD",
      "indices" : [ "3", "17" ],
      "id_str" : "-1",
      "id" : "-1"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "92" ],
  "favorite_count" : "0",
  "id_str" : "918100227328036867",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "918100227328036867",
  "created_at" : "Wed Oct 11 13:05:26 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @Free_Food_UMD: Free snacks in Colony Ball Room in STAMP from 5-7 PM! #Terps #HungryTerps",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/916270398865625088/photo/1",
      "indices" : [ "32", "55" ],
      "url" : "https://t.co/T9MC7ZEvCe",
      "media_url" : "http://pbs.twimg.com/media/DLc_EZBWkAAqFTw.jpg",
      "id_str" : "916270393861771264",
      "id" : "916270393861771264",
      "media_url_https" : "https://pbs.twimg.com/media/DLc_EZBWkAAqFTw.jpg",
      "sizes" : {
        "medium" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "526",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/T9MC7ZEvCe"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "55" ],
  "favorite_count" : "2",
  "id_str" : "916270398865625088",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "916270398865625088",
  "possibly_sensitive" : false,
  "created_at" : "Fri Oct 06 11:54:21 +0000 2017",
  "favorited" : false,
  "full_text" : "Look at the bottom right corner https://t.co/T9MC7ZEvCe",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/916270398865625088/photo/1",
      "indices" : [ "32", "55" ],
      "url" : "https://t.co/T9MC7ZEvCe",
      "media_url" : "http://pbs.twimg.com/media/DLc_EZBWkAAqFTw.jpg",
      "id_str" : "916270393861771264",
      "id" : "916270393861771264",
      "media_url_https" : "https://pbs.twimg.com/media/DLc_EZBWkAAqFTw.jpg",
      "sizes" : {
        "medium" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "526",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/T9MC7ZEvCe"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "57", "69" ],
      "id_str" : "59604041",
      "id" : "59604041"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "1",
  "id_str" : "915995335373332481",
  "truncated" : false,
  "retweet_count" : "6",
  "id" : "915995335373332481",
  "created_at" : "Thu Oct 05 17:41:20 +0000 2017",
  "favorited" : false,
  "full_text" : "There's free food in the grand ballroom lounge from  5-7 @THESTAMPUMD",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Applebee's",
      "screen_name" : "Applebees",
      "indices" : [ "120", "130" ],
      "id_str" : "74452613",
      "id" : "74452613"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "130" ],
  "favorite_count" : "1",
  "id_str" : "915771426799591425",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "915771426799591425",
  "created_at" : "Thu Oct 05 02:51:37 +0000 2017",
  "favorited" : false,
  "full_text" : "$1 margaritas at Applebees this month. Head over to Applebees in College Park with your friends. Must be 21+ to drink.  @Applebees",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "✨ g o l d m o u t h ✨",
      "screen_name" : "Africana_Barbie",
      "indices" : [ "3", "19" ],
      "id_str" : "370927134",
      "id" : "370927134"
    } ],
    "urls" : [ {
      "url" : "https://t.co/S3xxZVanxm",
      "expanded_url" : "https://twitter.com/seefoodcalendar/status/915587834731548672",
      "display_url" : "twitter.com/seefoodcalenda…",
      "indices" : [ "49", "72" ]
    } ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "id_str" : "915588079305547776",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "915588079305547776",
  "possibly_sensitive" : false,
  "created_at" : "Wed Oct 04 14:43:03 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @Africana_Barbie: Thank goodness I'm starving https://t.co/S3xxZVanxm",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyumburu",
      "screen_name" : "Nyumburu",
      "indices" : [ "50", "59" ],
      "id_str" : "339853945",
      "id" : "339853945"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/915587834731548672/photo/1",
      "indices" : [ "60", "83" ],
      "url" : "https://t.co/ypdS4vWjZP",
      "media_url" : "http://pbs.twimg.com/media/DLTSRwLWkAAdGrW.jpg",
      "id_str" : "915587826695180288",
      "id" : "915587826695180288",
      "media_url_https" : "https://pbs.twimg.com/media/DLTSRwLWkAAdGrW.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "900",
          "h" : "671",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "900",
          "h" : "671",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "507",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/ypdS4vWjZP"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "83" ],
  "favorite_count" : "0",
  "id_str" : "915587834731548672",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "915587834731548672",
  "possibly_sensitive" : false,
  "created_at" : "Wed Oct 04 14:42:05 +0000 2017",
  "favorited" : false,
  "full_text" : "Back at it again for another week. Today at noon! @Nyumburu https://t.co/ypdS4vWjZP",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/915587834731548672/photo/1",
      "indices" : [ "60", "83" ],
      "url" : "https://t.co/ypdS4vWjZP",
      "media_url" : "http://pbs.twimg.com/media/DLTSRwLWkAAdGrW.jpg",
      "id_str" : "915587826695180288",
      "id" : "915587826695180288",
      "media_url_https" : "https://pbs.twimg.com/media/DLTSRwLWkAAdGrW.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "900",
          "h" : "671",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "900",
          "h" : "671",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "507",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/ypdS4vWjZP"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/pU1WkOK1KA",
      "expanded_url" : "https://twitter.com/thestampumd/status/915531605019635713",
      "display_url" : "twitter.com/thestampumd/st…",
      "indices" : [ "16", "39" ]
    } ]
  },
  "display_text_range" : [ "0", "39" ],
  "favorite_count" : "0",
  "id_str" : "915575438893813761",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "915575438893813761",
  "possibly_sensitive" : false,
  "created_at" : "Wed Oct 04 13:52:49 +0000 2017",
  "favorited" : false,
  "full_text" : "One hour left!! https://t.co/pU1WkOK1KA",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "See Food",
      "screen_name" : "SeeFoodCalendar",
      "indices" : [ "3", "19" ],
      "id_str" : "800904115924717569",
      "id" : "800904115924717569"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/914162271466786817/photo/1",
      "source_status_id" : "914162271466786817",
      "indices" : [ "79", "102" ],
      "url" : "https://t.co/nLZFD827GY",
      "media_url" : "http://pbs.twimg.com/media/DK_BvRAWsAASRXs.jpg",
      "id_str" : "914162267142402048",
      "source_user_id" : "800904115924717569",
      "id" : "914162267142402048",
      "media_url_https" : "https://pbs.twimg.com/media/DK_BvRAWsAASRXs.jpg",
      "source_user_id_str" : "800904115924717569",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "959",
          "h" : "960",
          "resize" : "fit"
        },
        "large" : {
          "w" : "959",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "679",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "914162271466786817",
      "display_url" : "pic.twitter.com/nLZFD827GY"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "102" ],
  "favorite_count" : "0",
  "id_str" : "914968561889705984",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "914968561889705984",
  "possibly_sensitive" : false,
  "created_at" : "Mon Oct 02 21:41:19 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @SeeFoodCalendar: Join UMD's fashion club this Monday for some mocktails :) https://t.co/nLZFD827GY",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/914162271466786817/photo/1",
      "source_status_id" : "914162271466786817",
      "indices" : [ "79", "102" ],
      "url" : "https://t.co/nLZFD827GY",
      "media_url" : "http://pbs.twimg.com/media/DK_BvRAWsAASRXs.jpg",
      "id_str" : "914162267142402048",
      "source_user_id" : "800904115924717569",
      "id" : "914162267142402048",
      "media_url_https" : "https://pbs.twimg.com/media/DK_BvRAWsAASRXs.jpg",
      "source_user_id_str" : "800904115924717569",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "959",
          "h" : "960",
          "resize" : "fit"
        },
        "large" : {
          "w" : "959",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "679",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "914162271466786817",
      "display_url" : "pic.twitter.com/nLZFD827GY"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/914879233943592962/photo/1",
      "indices" : [ "104", "127" ],
      "url" : "https://t.co/dd6bzqyd3H",
      "media_url" : "http://pbs.twimg.com/media/DLJNz3UXcAA-89K.jpg",
      "id_str" : "914879227727671296",
      "id" : "914879227727671296",
      "media_url_https" : "https://pbs.twimg.com/media/DLJNz3UXcAA-89K.jpg",
      "sizes" : {
        "large" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/dd6bzqyd3H"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "127" ],
  "favorite_count" : "3",
  "id_str" : "914879233943592962",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "914879233943592962",
  "possibly_sensitive" : false,
  "created_at" : "Mon Oct 02 15:46:21 +0000 2017",
  "favorited" : false,
  "full_text" : "There's a BBQ on the quad tonight from 6-8. Feel free to check out the other events happening this week https://t.co/dd6bzqyd3H",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/914879233943592962/photo/1",
      "indices" : [ "104", "127" ],
      "url" : "https://t.co/dd6bzqyd3H",
      "media_url" : "http://pbs.twimg.com/media/DLJNz3UXcAA-89K.jpg",
      "id_str" : "914879227727671296",
      "id" : "914879227727671296",
      "media_url_https" : "https://pbs.twimg.com/media/DLJNz3UXcAA-89K.jpg",
      "sizes" : {
        "large" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/dd6bzqyd3H"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "67" ],
  "favorite_count" : "0",
  "id_str" : "914281971827781634",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "914281971827781634",
  "created_at" : "Sun Oct 01 00:13:03 +0000 2017",
  "favorited" : false,
  "full_text" : "Don't forget...bubble ball tonight on frat row fields! Free PIZZA \uD83C\uDF55",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "id_str" : "914200255503196160",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "914200255503196160",
  "created_at" : "Sat Sep 30 18:48:20 +0000 2017",
  "favorited" : false,
  "full_text" : "Cook out on the quad right now! With Phi Beta Sigma!!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/914162271466786817/photo/1",
      "indices" : [ "58", "81" ],
      "url" : "https://t.co/nLZFD827GY",
      "media_url" : "http://pbs.twimg.com/media/DK_BvRAWsAASRXs.jpg",
      "id_str" : "914162267142402048",
      "id" : "914162267142402048",
      "media_url_https" : "https://pbs.twimg.com/media/DK_BvRAWsAASRXs.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "959",
          "h" : "960",
          "resize" : "fit"
        },
        "large" : {
          "w" : "959",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "679",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/nLZFD827GY"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "914162271466786817",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "914162271466786817",
  "possibly_sensitive" : false,
  "created_at" : "Sat Sep 30 16:17:24 +0000 2017",
  "favorited" : false,
  "full_text" : "Join UMD's fashion club this Monday for some mocktails :) https://t.co/nLZFD827GY",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/914162271466786817/photo/1",
      "indices" : [ "58", "81" ],
      "url" : "https://t.co/nLZFD827GY",
      "media_url" : "http://pbs.twimg.com/media/DK_BvRAWsAASRXs.jpg",
      "id_str" : "914162267142402048",
      "id" : "914162267142402048",
      "media_url_https" : "https://pbs.twimg.com/media/DK_BvRAWsAASRXs.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "959",
          "h" : "960",
          "resize" : "fit"
        },
        "large" : {
          "w" : "959",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "679",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/nLZFD827GY"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/913809760943788035/photo/1",
      "indices" : [ "86", "109" ],
      "url" : "https://t.co/6hUgr3W0NJ",
      "media_url" : "http://pbs.twimg.com/media/DK6BHaeW4AAhl3_.jpg",
      "id_str" : "913809738768506880",
      "id" : "913809738768506880",
      "media_url_https" : "https://pbs.twimg.com/media/DK6BHaeW4AAhl3_.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "large" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/6hUgr3W0NJ"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "109" ],
  "favorite_count" : "0",
  "id_str" : "913809760943788035",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "913809760943788035",
  "possibly_sensitive" : false,
  "created_at" : "Fri Sep 29 16:56:39 +0000 2017",
  "favorited" : false,
  "full_text" : "Head over to stamp for free Rita's and mocktails courtesy of Phi Beta Fraternity Inc! https://t.co/6hUgr3W0NJ",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/913809760943788035/photo/1",
      "indices" : [ "86", "109" ],
      "url" : "https://t.co/6hUgr3W0NJ",
      "media_url" : "http://pbs.twimg.com/media/DK6BHaeW4AAhl3_.jpg",
      "id_str" : "913809738768506880",
      "id" : "913809738768506880",
      "media_url_https" : "https://pbs.twimg.com/media/DK6BHaeW4AAhl3_.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        },
        "large" : {
          "w" : "960",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/6hUgr3W0NJ"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "SaLish \uD83C\uDDEC\uD83C\uDDFE",
      "screen_name" : "De_Lishaa",
      "indices" : [ "0", "10" ],
      "id_str" : "239210236",
      "id" : "239210236"
    } ],
    "urls" : [ {
      "url" : "https://t.co/xAokH5RXaG",
      "expanded_url" : "http://terpsafterdark.com",
      "display_url" : "terpsafterdark.com",
      "indices" : [ "128", "151" ]
    } ]
  },
  "display_text_range" : [ "0", "151" ],
  "favorite_count" : "1",
  "in_reply_to_status_id_str" : "913800477065785346",
  "id_str" : "913806717418377218",
  "in_reply_to_user_id" : "239210236",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "913806717418377218",
  "in_reply_to_status_id" : "913800477065785346",
  "possibly_sensitive" : false,
  "created_at" : "Fri Sep 29 16:44:33 +0000 2017",
  "favorited" : false,
  "full_text" : "@De_Lishaa There's no link to RSVP and swag is on a first come, first serve basis! You need to sign a waiver to play! Check out https://t.co/xAokH5RXaG",
  "lang" : "en",
  "in_reply_to_screen_name" : "De_Lishaa",
  "in_reply_to_user_id_str" : "239210236"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "See Food",
      "screen_name" : "SeeFoodCalendar",
      "indices" : [ "3", "19" ],
      "id_str" : "800904115924717569",
      "id" : "800904115924717569"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "913802824101892098",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "913802824101892098",
  "created_at" : "Fri Sep 29 16:29:05 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @SeeFoodCalendar: Bubble Ball tournament and free PIZZA on swag on Frat row fields this Saturday from 10pm - 1am! Come solo or with a te…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "130" ],
  "favorite_count" : "2",
  "id_str" : "913793443918417920",
  "truncated" : false,
  "retweet_count" : "3",
  "id" : "913793443918417920",
  "created_at" : "Fri Sep 29 15:51:49 +0000 2017",
  "favorited" : false,
  "full_text" : "Bubble Ball tournament and free PIZZA on swag on Frat row fields this Saturday from 10pm - 1am! Come solo or with a team already!!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/913519089817194496/photo/1",
      "indices" : [ "0", "23" ],
      "url" : "https://t.co/0bfZMFe9qF",
      "media_url" : "http://pbs.twimg.com/media/DK14xJbX0AEj59i.jpg",
      "id_str" : "913519085165727745",
      "id" : "913519085165727745",
      "media_url_https" : "https://pbs.twimg.com/media/DK14xJbX0AEj59i.jpg",
      "sizes" : {
        "medium" : {
          "w" : "639",
          "h" : "763",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "639",
          "h" : "763",
          "resize" : "fit"
        },
        "small" : {
          "w" : "569",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/0bfZMFe9qF"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "id_str" : "913519089817194496",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "913519089817194496",
  "possibly_sensitive" : false,
  "created_at" : "Thu Sep 28 21:41:38 +0000 2017",
  "favorited" : false,
  "full_text" : "https://t.co/0bfZMFe9qF",
  "lang" : "und",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/913519089817194496/photo/1",
      "indices" : [ "0", "23" ],
      "url" : "https://t.co/0bfZMFe9qF",
      "media_url" : "http://pbs.twimg.com/media/DK14xJbX0AEj59i.jpg",
      "id_str" : "913519085165727745",
      "id" : "913519085165727745",
      "media_url_https" : "https://pbs.twimg.com/media/DK14xJbX0AEj59i.jpg",
      "sizes" : {
        "medium" : {
          "w" : "639",
          "h" : "763",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "639",
          "h" : "763",
          "resize" : "fit"
        },
        "small" : {
          "w" : "569",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/0bfZMFe9qF"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/913012517433167872/photo/1",
      "indices" : [ "3", "26" ],
      "url" : "https://t.co/ECbXG0oZI0",
      "media_url" : "http://pbs.twimg.com/media/DKusCKoX0AAX1zd.jpg",
      "id_str" : "913012502686060544",
      "id" : "913012502686060544",
      "media_url_https" : "https://pbs.twimg.com/media/DKusCKoX0AAX1zd.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "481",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "848",
          "h" : "1200",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1448",
          "h" : "2048",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/ECbXG0oZI0"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "26" ],
  "favorite_count" : "0",
  "id_str" : "913012517433167872",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "913012517433167872",
  "possibly_sensitive" : false,
  "created_at" : "Wed Sep 27 12:08:41 +0000 2017",
  "favorited" : false,
  "full_text" : "✍️ https://t.co/ECbXG0oZI0",
  "lang" : "und",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/913012517433167872/photo/1",
      "indices" : [ "3", "26" ],
      "url" : "https://t.co/ECbXG0oZI0",
      "media_url" : "http://pbs.twimg.com/media/DKusCKoX0AAX1zd.jpg",
      "id_str" : "913012502686060544",
      "id" : "913012502686060544",
      "media_url_https" : "https://pbs.twimg.com/media/DKusCKoX0AAX1zd.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "481",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "848",
          "h" : "1200",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1448",
          "h" : "2048",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/ECbXG0oZI0"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/913012389309829120/photo/1",
      "indices" : [ "0", "23" ],
      "url" : "https://t.co/gg5wbIYmqC",
      "media_url" : "http://pbs.twimg.com/media/DKur7R6XUAAGbB7.jpg",
      "id_str" : "913012384381489152",
      "id" : "913012384381489152",
      "media_url_https" : "https://pbs.twimg.com/media/DKur7R6XUAAGbB7.jpg",
      "sizes" : {
        "large" : {
          "w" : "959",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "679",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "959",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/gg5wbIYmqC"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "id_str" : "913012389309829120",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "913012389309829120",
  "possibly_sensitive" : false,
  "created_at" : "Wed Sep 27 12:08:11 +0000 2017",
  "favorited" : false,
  "full_text" : "https://t.co/gg5wbIYmqC",
  "lang" : "und",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/913012389309829120/photo/1",
      "indices" : [ "0", "23" ],
      "url" : "https://t.co/gg5wbIYmqC",
      "media_url" : "http://pbs.twimg.com/media/DKur7R6XUAAGbB7.jpg",
      "id_str" : "913012384381489152",
      "id" : "913012384381489152",
      "media_url_https" : "https://pbs.twimg.com/media/DKur7R6XUAAGbB7.jpg",
      "sizes" : {
        "large" : {
          "w" : "959",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "679",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "959",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/gg5wbIYmqC"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/913012209655087104/photo/1",
      "indices" : [ "32", "55" ],
      "url" : "https://t.co/fNkfrsLlC1",
      "media_url" : "http://pbs.twimg.com/media/DKurwnkW4AELZAK.jpg",
      "id_str" : "913012201216204801",
      "id" : "913012201216204801",
      "media_url_https" : "https://pbs.twimg.com/media/DKurwnkW4AELZAK.jpg",
      "sizes" : {
        "medium" : {
          "w" : "539",
          "h" : "708",
          "resize" : "fit"
        },
        "large" : {
          "w" : "539",
          "h" : "708",
          "resize" : "fit"
        },
        "small" : {
          "w" : "518",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/fNkfrsLlC1"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "55" ],
  "favorite_count" : "0",
  "id_str" : "913012209655087104",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "913012209655087104",
  "possibly_sensitive" : false,
  "created_at" : "Wed Sep 27 12:07:28 +0000 2017",
  "favorited" : false,
  "full_text" : "Hey stop by these events today! https://t.co/fNkfrsLlC1",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/913012209655087104/photo/1",
      "indices" : [ "32", "55" ],
      "url" : "https://t.co/fNkfrsLlC1",
      "media_url" : "http://pbs.twimg.com/media/DKurwnkW4AELZAK.jpg",
      "id_str" : "913012201216204801",
      "id" : "913012201216204801",
      "media_url_https" : "https://pbs.twimg.com/media/DKurwnkW4AELZAK.jpg",
      "sizes" : {
        "medium" : {
          "w" : "539",
          "h" : "708",
          "resize" : "fit"
        },
        "large" : {
          "w" : "539",
          "h" : "708",
          "resize" : "fit"
        },
        "small" : {
          "w" : "518",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/fNkfrsLlC1"
    }, {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/913012209655087104/photo/1",
      "indices" : [ "32", "55" ],
      "url" : "https://t.co/fNkfrsLlC1",
      "media_url" : "http://pbs.twimg.com/media/DKurwnnW4AAZhGM.jpg",
      "id_str" : "913012201228787712",
      "id" : "913012201228787712",
      "media_url_https" : "https://pbs.twimg.com/media/DKurwnnW4AAZhGM.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "539",
          "h" : "537",
          "resize" : "fit"
        },
        "large" : {
          "w" : "539",
          "h" : "537",
          "resize" : "fit"
        },
        "small" : {
          "w" : "539",
          "h" : "537",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/fNkfrsLlC1"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Business Assoc",
      "screen_name" : "BBATerp",
      "indices" : [ "3", "11" ],
      "id_str" : "368458309",
      "id" : "368458309"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/BBATerp/status/912377318647238657/photo/1",
      "source_status_id" : "912377318647238657",
      "indices" : [ "50", "73" ],
      "url" : "https://t.co/q6ZeFkrzum",
      "media_url" : "http://pbs.twimg.com/media/DKlqVRnWkAAW1rY.jpg",
      "id_str" : "912377313257492480",
      "source_user_id" : "368458309",
      "id" : "912377313257492480",
      "media_url_https" : "https://pbs.twimg.com/media/DKlqVRnWkAAW1rY.jpg",
      "source_user_id_str" : "368458309",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "636",
          "h" : "738",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "636",
          "h" : "738",
          "resize" : "fit"
        },
        "small" : {
          "w" : "586",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "912377318647238657",
      "display_url" : "pic.twitter.com/q6ZeFkrzum"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "73" ],
  "favorite_count" : "0",
  "id_str" : "912378164097306624",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "912378164097306624",
  "possibly_sensitive" : false,
  "created_at" : "Mon Sep 25 18:08:00 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @BBATerp: All majors welcome! Food provided!!! https://t.co/q6ZeFkrzum",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/BBATerp/status/912377318647238657/photo/1",
      "source_status_id" : "912377318647238657",
      "indices" : [ "50", "73" ],
      "url" : "https://t.co/q6ZeFkrzum",
      "media_url" : "http://pbs.twimg.com/media/DKlqVRnWkAAW1rY.jpg",
      "id_str" : "912377313257492480",
      "source_user_id" : "368458309",
      "id" : "912377313257492480",
      "media_url_https" : "https://pbs.twimg.com/media/DKlqVRnWkAAW1rY.jpg",
      "source_user_id_str" : "368458309",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "636",
          "h" : "738",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "636",
          "h" : "738",
          "resize" : "fit"
        },
        "small" : {
          "w" : "586",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "912377318647238657",
      "display_url" : "pic.twitter.com/q6ZeFkrzum"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Transfer&Off-Campus",
      "screen_name" : "UMDTOCSL",
      "indices" : [ "47", "56" ],
      "id_str" : "1205397097",
      "id" : "1205397097"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/912030413916377088/photo/1",
      "indices" : [ "57", "80" ],
      "url" : "https://t.co/7ZjDDDKojB",
      "media_url" : "http://pbs.twimg.com/media/DKgu02ZW4AAdziN.jpg",
      "id_str" : "912030410032472064",
      "id" : "912030410032472064",
      "media_url_https" : "https://pbs.twimg.com/media/DKgu02ZW4AAdziN.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "515",
          "resize" : "fit"
        },
        "large" : {
          "w" : "709",
          "h" : "537",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "709",
          "h" : "537",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/7ZjDDDKojB"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "912030413916377088",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "912030413916377088",
  "possibly_sensitive" : false,
  "created_at" : "Sun Sep 24 19:06:10 +0000 2017",
  "favorited" : false,
  "full_text" : "Hey transfer students! Check this out tomorrow @UMDTOCSL https://t.co/7ZjDDDKojB",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/912030413916377088/photo/1",
      "indices" : [ "57", "80" ],
      "url" : "https://t.co/7ZjDDDKojB",
      "media_url" : "http://pbs.twimg.com/media/DKgu02ZW4AAdziN.jpg",
      "id_str" : "912030410032472064",
      "id" : "912030410032472064",
      "media_url_https" : "https://pbs.twimg.com/media/DKgu02ZW4AAdziN.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "515",
          "resize" : "fit"
        },
        "large" : {
          "w" : "709",
          "h" : "537",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "709",
          "h" : "537",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/7ZjDDDKojB"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "125" ],
  "favorite_count" : "0",
  "id_str" : "912014768285917185",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "912014768285917185",
  "created_at" : "Sun Sep 24 18:03:59 +0000 2017",
  "favorited" : false,
  "full_text" : "3107 CSIC @ 5pm today. The Sandbox is a place where you can build whatever you want with tools they have. They'll have pizza!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/909808806401425408/photo/1",
      "indices" : [ "51", "74" ],
      "url" : "https://t.co/mjw9989CBL",
      "media_url" : "http://pbs.twimg.com/media/DKBKR_1W0AMB9t5.jpg",
      "id_str" : "909808797782298627",
      "id" : "909808797782298627",
      "media_url_https" : "https://pbs.twimg.com/media/DKBKR_1W0AMB9t5.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "539",
          "h" : "370",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "539",
          "h" : "370",
          "resize" : "fit"
        },
        "large" : {
          "w" : "539",
          "h" : "370",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/mjw9989CBL"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "74" ],
  "favorite_count" : "0",
  "id_str" : "909808806401425408",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "909808806401425408",
  "possibly_sensitive" : false,
  "created_at" : "Mon Sep 18 15:58:17 +0000 2017",
  "favorited" : false,
  "full_text" : "Maybe the gecko will make a special appearance lol https://t.co/mjw9989CBL",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/909808806401425408/photo/1",
      "indices" : [ "51", "74" ],
      "url" : "https://t.co/mjw9989CBL",
      "media_url" : "http://pbs.twimg.com/media/DKBKR_1W0AMB9t5.jpg",
      "id_str" : "909808797782298627",
      "id" : "909808797782298627",
      "media_url_https" : "https://pbs.twimg.com/media/DKBKR_1W0AMB9t5.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "539",
          "h" : "370",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "539",
          "h" : "370",
          "resize" : "fit"
        },
        "large" : {
          "w" : "539",
          "h" : "370",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/mjw9989CBL"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "GradStudentLife UMD",
      "screen_name" : "UMDGSL",
      "indices" : [ "3", "10" ],
      "id_str" : "768418140",
      "id" : "768418140"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "909575184268562432",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "909575184268562432",
  "created_at" : "Mon Sep 18 00:29:57 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @UMDGSL: Craft a thing, enjoy a treat, and chill out for a second, will ya? Join us 4-6pm Mon, 9/18 for our first Craft Night: duct tape…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/908425137900408833/photo/1",
      "indices" : [ "20", "43" ],
      "url" : "https://t.co/K7Q9MSlk5K",
      "media_url" : "http://pbs.twimg.com/media/DJtf11YWsAEhTeU.jpg",
      "id_str" : "908425128312221697",
      "id" : "908425128312221697",
      "media_url_https" : "https://pbs.twimg.com/media/DJtf11YWsAEhTeU.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "552",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "639",
          "h" : "787",
          "resize" : "fit"
        },
        "large" : {
          "w" : "639",
          "h" : "787",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/K7Q9MSlk5K"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "43" ],
  "favorite_count" : "0",
  "id_str" : "908425137900408833",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "908425137900408833",
  "possibly_sensitive" : false,
  "created_at" : "Thu Sep 14 20:20:05 +0000 2017",
  "favorited" : false,
  "full_text" : "Hot off the press!! https://t.co/K7Q9MSlk5K",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/908425137900408833/photo/1",
      "indices" : [ "20", "43" ],
      "url" : "https://t.co/K7Q9MSlk5K",
      "media_url" : "http://pbs.twimg.com/media/DJtf11YWsAEhTeU.jpg",
      "id_str" : "908425128312221697",
      "id" : "908425128312221697",
      "media_url_https" : "https://pbs.twimg.com/media/DJtf11YWsAEhTeU.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "552",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "639",
          "h" : "787",
          "resize" : "fit"
        },
        "large" : {
          "w" : "639",
          "h" : "787",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/K7Q9MSlk5K"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "36" ],
  "favorite_count" : "0",
  "id_str" : "908396583296913408",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "908396583296913408",
  "created_at" : "Thu Sep 14 18:26:37 +0000 2017",
  "favorited" : false,
  "full_text" : "I'm very simple: I see food, I tweet",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "1",
  "id_str" : "908395697854144512",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "908395697854144512",
  "created_at" : "Thu Sep 14 18:23:06 +0000 2017",
  "favorited" : false,
  "full_text" : "If you think I missed any events slide into my dms!!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/908350292554604545/photo/1",
      "indices" : [ "24", "47" ],
      "url" : "https://t.co/CnBm22Skhd",
      "media_url" : "http://pbs.twimg.com/media/DJsbxh6W4AARWGA.jpg",
      "id_str" : "908350287575965696",
      "id" : "908350287575965696",
      "media_url_https" : "https://pbs.twimg.com/media/DJsbxh6W4AARWGA.jpg",
      "sizes" : {
        "small" : {
          "w" : "480",
          "h" : "270",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "480",
          "h" : "270",
          "resize" : "fit"
        },
        "large" : {
          "w" : "480",
          "h" : "270",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/CnBm22Skhd"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "47" ],
  "favorite_count" : "0",
  "id_str" : "908350292554604545",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "908350292554604545",
  "possibly_sensitive" : false,
  "created_at" : "Thu Sep 14 15:22:40 +0000 2017",
  "favorited" : false,
  "full_text" : "The lineup for tonight! https://t.co/CnBm22Skhd",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/908350292554604545/photo/1",
      "indices" : [ "24", "47" ],
      "url" : "https://t.co/CnBm22Skhd",
      "media_url" : "http://pbs.twimg.com/media/DJsbxh6W4AARWGA.jpg",
      "id_str" : "908350287575965696",
      "id" : "908350287575965696",
      "media_url_https" : "https://pbs.twimg.com/media/DJsbxh6W4AARWGA.jpg",
      "sizes" : {
        "small" : {
          "w" : "480",
          "h" : "270",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "480",
          "h" : "270",
          "resize" : "fit"
        },
        "large" : {
          "w" : "480",
          "h" : "270",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/CnBm22Skhd"
    }, {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/908350292554604545/photo/1",
      "indices" : [ "24", "47" ],
      "url" : "https://t.co/CnBm22Skhd",
      "media_url" : "http://pbs.twimg.com/media/DJsbxh3XoAA43LB.jpg",
      "id_str" : "908350287563431936",
      "id" : "908350287563431936",
      "media_url_https" : "https://pbs.twimg.com/media/DJsbxh3XoAA43LB.jpg",
      "sizes" : {
        "medium" : {
          "w" : "599",
          "h" : "774",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "599",
          "h" : "774",
          "resize" : "fit"
        },
        "small" : {
          "w" : "526",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/CnBm22Skhd"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/e7kS7rWTJc",
      "expanded_url" : "https://twitter.com/joinapt/status/908004511112982528",
      "display_url" : "twitter.com/joinapt/status…",
      "indices" : [ "4", "27" ]
    } ]
  },
  "display_text_range" : [ "0", "27" ],
  "favorite_count" : "0",
  "id_str" : "908051092948373505",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "908051092948373505",
  "possibly_sensitive" : false,
  "created_at" : "Wed Sep 13 19:33:45 +0000 2017",
  "favorited" : false,
  "full_text" : "\uD83D\uDC40\uD83D\uDC40\uD83D\uDC40 https://t.co/e7kS7rWTJc",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Our Revolution UMD",
      "screen_name" : "ORUMDC",
      "indices" : [ "3", "10" ],
      "id_str" : "826939565537648642",
      "id" : "826939565537648642"
    }, {
      "name" : "Our Revolution",
      "screen_name" : "OurRevolution",
      "indices" : [ "93", "107" ],
      "id_str" : "753623149929869312",
      "id" : "753623149929869312"
    }, {
      "name" : "Nina Turner",
      "screen_name" : "ninaturner",
      "indices" : [ "119", "130" ],
      "id_str" : "188793260",
      "id" : "188793260"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "908017568094588928",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "908017568094588928",
  "created_at" : "Wed Sep 13 17:20:33 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @ORUMDC: TONIGHT: all are welcome to come to our kick off meeting, with special guest and @OurRevolution President, @ninaturner! 6 PM, 3…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/907974445544951808/photo/1",
      "indices" : [ "13", "36" ],
      "url" : "https://t.co/5y0KfjL7FM",
      "media_url" : "http://pbs.twimg.com/media/DJnF8XYXcAUFlyr.jpg",
      "id_str" : "907974440750903301",
      "id" : "907974440750903301",
      "media_url_https" : "https://pbs.twimg.com/media/DJnF8XYXcAUFlyr.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "900",
          "h" : "671",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "900",
          "h" : "671",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "507",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/5y0KfjL7FM"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "36" ],
  "favorite_count" : "0",
  "id_str" : "907974445544951808",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "907974445544951808",
  "possibly_sensitive" : false,
  "created_at" : "Wed Sep 13 14:29:11 +0000 2017",
  "favorited" : false,
  "full_text" : "Come thruuuu https://t.co/5y0KfjL7FM",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/907974445544951808/photo/1",
      "indices" : [ "13", "36" ],
      "url" : "https://t.co/5y0KfjL7FM",
      "media_url" : "http://pbs.twimg.com/media/DJnF8XYXcAUFlyr.jpg",
      "id_str" : "907974440750903301",
      "id" : "907974440750903301",
      "media_url_https" : "https://pbs.twimg.com/media/DJnF8XYXcAUFlyr.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "900",
          "h" : "671",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "900",
          "h" : "671",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "507",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/5y0KfjL7FM"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "InnovationUMD",
      "screen_name" : "InnovationUMD",
      "indices" : [ "3", "17" ],
      "id_str" : "1244526223",
      "id" : "1244526223"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "0",
  "id_str" : "907706208206901250",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "907706208206901250",
  "created_at" : "Tue Sep 12 20:43:19 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @InnovationUMD: You’re invited to the Academy for Innovation &amp; Entrepreneurship Open House 9/14 from 2:30-5pm at 1130 ESJ https://t.co/D…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/907706096088993799/photo/1",
      "indices" : [ "21", "44" ],
      "url" : "https://t.co/JKnyqG9XZc",
      "media_url" : "http://pbs.twimg.com/media/DJjR4PSW0AAYzvd.jpg",
      "id_str" : "907706089021558784",
      "id" : "907706089021558784",
      "media_url_https" : "https://pbs.twimg.com/media/DJjR4PSW0AAYzvd.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "539",
          "h" : "764",
          "resize" : "fit"
        },
        "small" : {
          "w" : "480",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "539",
          "h" : "764",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/JKnyqG9XZc"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "44" ],
  "favorite_count" : "0",
  "id_str" : "907706096088993799",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "907706096088993799",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 12 20:42:52 +0000 2017",
  "favorited" : false,
  "full_text" : "May he Rest In Peace https://t.co/JKnyqG9XZc",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/907706096088993799/photo/1",
      "indices" : [ "21", "44" ],
      "url" : "https://t.co/JKnyqG9XZc",
      "media_url" : "http://pbs.twimg.com/media/DJjR4PSW0AAYzvd.jpg",
      "id_str" : "907706089021558784",
      "id" : "907706089021558784",
      "media_url_https" : "https://pbs.twimg.com/media/DJjR4PSW0AAYzvd.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "539",
          "h" : "764",
          "resize" : "fit"
        },
        "small" : {
          "w" : "480",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "539",
          "h" : "764",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/JKnyqG9XZc"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "112" ],
  "favorite_count" : "0",
  "id_str" : "905844955322753024",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "905844955322753024",
  "created_at" : "Thu Sep 07 17:27:21 +0000 2017",
  "favorited" : false,
  "full_text" : "Slide through to the engineering picnic at 3pm on the Kim Engineering building plaza ! (Free food for engineers)",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/905772217941807104/photo/1",
      "indices" : [ "0", "23" ],
      "url" : "https://t.co/H1XXfRgneX",
      "media_url" : "http://pbs.twimg.com/media/DJHzB4uWAAEPQ69.jpg",
      "id_str" : "905772213810364417",
      "id" : "905772213810364417",
      "media_url_https" : "https://pbs.twimg.com/media/DJHzB4uWAAEPQ69.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "739",
          "h" : "1024",
          "resize" : "fit"
        },
        "small" : {
          "w" : "491",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "739",
          "h" : "1024",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/H1XXfRgneX"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "id_str" : "905772217941807104",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "905772217941807104",
  "possibly_sensitive" : false,
  "created_at" : "Thu Sep 07 12:38:19 +0000 2017",
  "favorited" : false,
  "full_text" : "https://t.co/H1XXfRgneX",
  "lang" : "und",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/905772217941807104/photo/1",
      "indices" : [ "0", "23" ],
      "url" : "https://t.co/H1XXfRgneX",
      "media_url" : "http://pbs.twimg.com/media/DJHzB4uWAAEPQ69.jpg",
      "id_str" : "905772213810364417",
      "id" : "905772213810364417",
      "media_url_https" : "https://pbs.twimg.com/media/DJHzB4uWAAEPQ69.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "739",
          "h" : "1024",
          "resize" : "fit"
        },
        "small" : {
          "w" : "491",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "739",
          "h" : "1024",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/H1XXfRgneX"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/JyKzZ2sGuS",
      "expanded_url" : "https://twitter.com/umdtocsl/status/905388346373009408",
      "display_url" : "twitter.com/umdtocsl/statu…",
      "indices" : [ "36", "59" ]
    } ]
  },
  "display_text_range" : [ "0", "59" ],
  "favorite_count" : "1",
  "id_str" : "905428845318295553",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "905428845318295553",
  "possibly_sensitive" : false,
  "created_at" : "Wed Sep 06 13:53:53 +0000 2017",
  "favorited" : false,
  "full_text" : "Happening for 1 more hour y'all \uD83D\uDDE3\uD83D\uDDE3\uD83D\uDDE3 https://t.co/JyKzZ2sGuS",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/905427832502968320/photo/1",
      "indices" : [ "29", "52" ],
      "url" : "https://t.co/wU04nVjzN4",
      "media_url" : "http://pbs.twimg.com/media/DJC5yxhWsAQ_wHz.jpg",
      "id_str" : "905427807039303684",
      "id" : "905427807039303684",
      "media_url_https" : "https://pbs.twimg.com/media/DJC5yxhWsAQ_wHz.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "412",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "292",
          "resize" : "fit"
        },
        "large" : {
          "w" : "960",
          "h" : "412",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/wU04nVjzN4"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "52" ],
  "favorite_count" : "0",
  "id_str" : "905427832502968320",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "905427832502968320",
  "possibly_sensitive" : false,
  "created_at" : "Wed Sep 06 13:49:51 +0000 2017",
  "favorited" : false,
  "full_text" : "For all the freshmen tonight https://t.co/wU04nVjzN4",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/905427832502968320/photo/1",
      "indices" : [ "29", "52" ],
      "url" : "https://t.co/wU04nVjzN4",
      "media_url" : "http://pbs.twimg.com/media/DJC5yxhWsAQ_wHz.jpg",
      "id_str" : "905427807039303684",
      "id" : "905427807039303684",
      "media_url_https" : "https://pbs.twimg.com/media/DJC5yxhWsAQ_wHz.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "412",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "292",
          "resize" : "fit"
        },
        "large" : {
          "w" : "960",
          "h" : "412",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/wU04nVjzN4"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/905143402966200320/photo/1",
      "indices" : [ "5", "28" ],
      "url" : "https://t.co/Co6Q90aICD",
      "media_url" : "http://pbs.twimg.com/media/DI-3H86XkAIPPBq.jpg",
      "id_str" : "905143397362667522",
      "id" : "905143397362667522",
      "media_url_https" : "https://pbs.twimg.com/media/DI-3H86XkAIPPBq.jpg",
      "sizes" : {
        "small" : {
          "w" : "615",
          "h" : "661",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "615",
          "h" : "661",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "615",
          "h" : "661",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/Co6Q90aICD"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "28" ],
  "favorite_count" : "0",
  "id_str" : "905143402966200320",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "905143402966200320",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 05 18:59:38 +0000 2017",
  "favorited" : false,
  "full_text" : "\uD83D\uDCBB\uD83D\uDEE9\uD83D\uDE81\uD83D\uDE80 https://t.co/Co6Q90aICD",
  "lang" : "und",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/905143402966200320/photo/1",
      "indices" : [ "5", "28" ],
      "url" : "https://t.co/Co6Q90aICD",
      "media_url" : "http://pbs.twimg.com/media/DI-3H86XkAIPPBq.jpg",
      "id_str" : "905143397362667522",
      "id" : "905143397362667522",
      "media_url_https" : "https://pbs.twimg.com/media/DI-3H86XkAIPPBq.jpg",
      "sizes" : {
        "small" : {
          "w" : "615",
          "h" : "661",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "615",
          "h" : "661",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "615",
          "h" : "661",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/Co6Q90aICD"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/905134725702049792/photo/1",
      "indices" : [ "5", "28" ],
      "url" : "https://t.co/NIMPoRRq7i",
      "media_url" : "http://pbs.twimg.com/media/DI-vOrbVYAA5E98.jpg",
      "id_str" : "905134716835160064",
      "id" : "905134716835160064",
      "media_url_https" : "https://pbs.twimg.com/media/DI-vOrbVYAA5E98.jpg",
      "sizes" : {
        "large" : {
          "w" : "733",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "733",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "519",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/NIMPoRRq7i"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "28" ],
  "favorite_count" : "0",
  "id_str" : "905134725702049792",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "905134725702049792",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 05 18:25:09 +0000 2017",
  "favorited" : false,
  "full_text" : "\uD83D\uDE4C\uD83C\uDFFF\uD83D\uDE4C\uD83C\uDFFF https://t.co/NIMPoRRq7i",
  "lang" : "und",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/905134725702049792/photo/1",
      "indices" : [ "5", "28" ],
      "url" : "https://t.co/NIMPoRRq7i",
      "media_url" : "http://pbs.twimg.com/media/DI-vOrbVYAA5E98.jpg",
      "id_str" : "905134716835160064",
      "id" : "905134716835160064",
      "media_url_https" : "https://pbs.twimg.com/media/DI-vOrbVYAA5E98.jpg",
      "sizes" : {
        "large" : {
          "w" : "733",
          "h" : "960",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "733",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "519",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/NIMPoRRq7i"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/905134541307817986/photo/1",
      "indices" : [ "5", "28" ],
      "url" : "https://t.co/cN9lsJH7Nw",
      "media_url" : "http://pbs.twimg.com/media/DI-vECUVAAAV01Z.jpg",
      "id_str" : "905134534001229824",
      "id" : "905134534001229824",
      "media_url_https" : "https://pbs.twimg.com/media/DI-vECUVAAAV01Z.jpg",
      "sizes" : {
        "medium" : {
          "w" : "680",
          "h" : "538",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "538",
          "resize" : "fit"
        },
        "large" : {
          "w" : "680",
          "h" : "538",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/cN9lsJH7Nw"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "28" ],
  "favorite_count" : "3",
  "id_str" : "905134541307817986",
  "truncated" : false,
  "retweet_count" : "2",
  "id" : "905134541307817986",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 05 18:24:25 +0000 2017",
  "favorited" : false,
  "full_text" : "\uD83C\uDF2D\uD83C\uDF57\uD83C\uDF2D\uD83C\uDF57 https://t.co/cN9lsJH7Nw",
  "lang" : "und",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/905134541307817986/photo/1",
      "indices" : [ "5", "28" ],
      "url" : "https://t.co/cN9lsJH7Nw",
      "media_url" : "http://pbs.twimg.com/media/DI-vECUVAAAV01Z.jpg",
      "id_str" : "905134534001229824",
      "id" : "905134534001229824",
      "media_url_https" : "https://pbs.twimg.com/media/DI-vECUVAAAV01Z.jpg",
      "sizes" : {
        "medium" : {
          "w" : "680",
          "h" : "538",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "538",
          "resize" : "fit"
        },
        "large" : {
          "w" : "680",
          "h" : "538",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/cN9lsJH7Nw"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "55" ],
  "favorite_count" : "1",
  "id_str" : "905134191356125184",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "905134191356125184",
  "created_at" : "Tue Sep 05 18:23:02 +0000 2017",
  "favorited" : false,
  "full_text" : "Keep ya wallets in pockets we got a big lineup tonight!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Transfer&Off-Campus",
      "screen_name" : "UMDTOCSL",
      "indices" : [ "3", "12" ],
      "id_str" : "1205397097",
      "id" : "1205397097"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "0",
  "id_str" : "905130469322358785",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "905130469322358785",
  "created_at" : "Tue Sep 05 18:08:15 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @UMDTOCSL: Tomorrow morning! Our 1st Good Morning Commuters of the semester!! Come enjoy yummy breakfast and meet other transfer &amp; off-c…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/904417005612269570/photo/1",
      "indices" : [ "80", "103" ],
      "url" : "https://t.co/uU5ufddXf3",
      "media_url" : "http://pbs.twimg.com/tweet_video_thumb/DI0ieAfWAAQb5jd.jpg",
      "id_str" : "904416999094222852",
      "id" : "904416999094222852",
      "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/DI0ieAfWAAQb5jd.jpg",
      "sizes" : {
        "large" : {
          "w" : "498",
          "h" : "372",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "498",
          "h" : "372",
          "resize" : "fit"
        },
        "small" : {
          "w" : "498",
          "h" : "372",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/uU5ufddXf3"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "103" ],
  "favorite_count" : "0",
  "id_str" : "904417005612269570",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "904417005612269570",
  "possibly_sensitive" : false,
  "created_at" : "Sun Sep 03 18:53:12 +0000 2017",
  "favorited" : false,
  "full_text" : "Happy Labor Day weekend y'all, time to relax and enjoy all the events this week https://t.co/uU5ufddXf3",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/904417005612269570/photo/1",
      "indices" : [ "80", "103" ],
      "url" : "https://t.co/uU5ufddXf3",
      "media_url" : "http://pbs.twimg.com/tweet_video_thumb/DI0ieAfWAAQb5jd.jpg",
      "id_str" : "904416999094222852",
      "video_info" : {
        "aspect_ratio" : [ "83", "62" ],
        "variants" : [ {
          "bitrate" : "0",
          "content_type" : "video/mp4",
          "url" : "https://video.twimg.com/tweet_video/DI0ieAfWAAQb5jd.mp4"
        } ]
      },
      "id" : "904416999094222852",
      "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/DI0ieAfWAAQb5jd.jpg",
      "sizes" : {
        "large" : {
          "w" : "498",
          "h" : "372",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "498",
          "h" : "372",
          "resize" : "fit"
        },
        "small" : {
          "w" : "498",
          "h" : "372",
          "resize" : "fit"
        }
      },
      "type" : "animated_gif",
      "display_url" : "pic.twitter.com/uU5ufddXf3"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Wednesday Addams",
      "screen_name" : "MME_petite",
      "indices" : [ "0", "11" ],
      "id_str" : "98022102",
      "id" : "98022102"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "36" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "903758423480836096",
  "id_str" : "903769653994037248",
  "in_reply_to_user_id" : "98022102",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "903769653994037248",
  "in_reply_to_status_id" : "903758423480836096",
  "created_at" : "Sat Sep 02 00:00:51 +0000 2017",
  "favorited" : false,
  "full_text" : "@MME_petite I like the way you think",
  "lang" : "en",
  "in_reply_to_screen_name" : "MME_petite",
  "in_reply_to_user_id_str" : "98022102"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "See Food",
      "screen_name" : "SeeFoodCalendar",
      "indices" : [ "3", "19" ],
      "id_str" : "800904115924717569",
      "id" : "800904115924717569"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/903288661969698817/photo/1",
      "source_status_id" : "903288661969698817",
      "indices" : [ "58", "81" ],
      "url" : "https://t.co/p1UkWmj9b6",
      "media_url" : "http://pbs.twimg.com/media/DIkgPxfW4AEr4IL.jpg",
      "id_str" : "903288655619481601",
      "source_user_id" : "800904115924717569",
      "id" : "903288655619481601",
      "media_url_https" : "https://pbs.twimg.com/media/DIkgPxfW4AEr4IL.jpg",
      "source_user_id_str" : "800904115924717569",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "526",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "903288661969698817",
      "display_url" : "pic.twitter.com/p1UkWmj9b6"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "903669846331858944",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "903669846331858944",
  "possibly_sensitive" : false,
  "created_at" : "Fri Sep 01 17:24:15 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @SeeFoodCalendar: And for all my minority STEM majors! https://t.co/p1UkWmj9b6",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/903288661969698817/photo/1",
      "source_status_id" : "903288661969698817",
      "indices" : [ "58", "81" ],
      "url" : "https://t.co/p1UkWmj9b6",
      "media_url" : "http://pbs.twimg.com/media/DIkgPxfW4AEr4IL.jpg",
      "id_str" : "903288655619481601",
      "source_user_id" : "800904115924717569",
      "id" : "903288655619481601",
      "media_url_https" : "https://pbs.twimg.com/media/DIkgPxfW4AEr4IL.jpg",
      "source_user_id_str" : "800904115924717569",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "526",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "903288661969698817",
      "display_url" : "pic.twitter.com/p1UkWmj9b6"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/gWzXABbw80",
      "expanded_url" : "https://twitter.com/shanaynay_03/status/903090294983352320",
      "display_url" : "twitter.com/shanaynay_03/s…",
      "indices" : [ "46", "69" ]
    } ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "0",
  "id_str" : "903478417495965696",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "903478417495965696",
  "possibly_sensitive" : false,
  "created_at" : "Fri Sep 01 04:43:35 +0000 2017",
  "favorited" : false,
  "full_text" : "Some people have no respect for a good meal \uD83D\uDE14 https://t.co/gWzXABbw80",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/903288661969698817/photo/1",
      "indices" : [ "37", "60" ],
      "url" : "https://t.co/p1UkWmj9b6",
      "media_url" : "http://pbs.twimg.com/media/DIkgPxfW4AEr4IL.jpg",
      "id_str" : "903288655619481601",
      "id" : "903288655619481601",
      "media_url_https" : "https://pbs.twimg.com/media/DIkgPxfW4AEr4IL.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "526",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/p1UkWmj9b6"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "60" ],
  "favorite_count" : "0",
  "id_str" : "903288661969698817",
  "truncated" : false,
  "retweet_count" : "2",
  "id" : "903288661969698817",
  "possibly_sensitive" : false,
  "created_at" : "Thu Aug 31 16:09:33 +0000 2017",
  "favorited" : false,
  "full_text" : "And for all my minority STEM majors! https://t.co/p1UkWmj9b6",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/903288661969698817/photo/1",
      "indices" : [ "37", "60" ],
      "url" : "https://t.co/p1UkWmj9b6",
      "media_url" : "http://pbs.twimg.com/media/DIkgPxfW4AEr4IL.jpg",
      "id_str" : "903288655619481601",
      "id" : "903288655619481601",
      "media_url_https" : "https://pbs.twimg.com/media/DIkgPxfW4AEr4IL.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "742",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "526",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/p1UkWmj9b6"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/903288286071975940/photo/1",
      "indices" : [ "31", "54" ],
      "url" : "https://t.co/KooQ2vnijA",
      "media_url" : "http://pbs.twimg.com/media/DIkf5t-XcAEscRQ.jpg",
      "id_str" : "903288276718678017",
      "id" : "903288276718678017",
      "media_url_https" : "https://pbs.twimg.com/media/DIkf5t-XcAEscRQ.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "480",
          "h" : "594",
          "resize" : "fit"
        },
        "small" : {
          "w" : "480",
          "h" : "594",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "480",
          "h" : "594",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/KooQ2vnijA"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "54" ],
  "favorite_count" : "0",
  "id_str" : "903288286071975940",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "903288286071975940",
  "possibly_sensitive" : false,
  "created_at" : "Thu Aug 31 16:08:04 +0000 2017",
  "favorited" : false,
  "full_text" : "Check this out later today too https://t.co/KooQ2vnijA",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/903288286071975940/photo/1",
      "indices" : [ "31", "54" ],
      "url" : "https://t.co/KooQ2vnijA",
      "media_url" : "http://pbs.twimg.com/media/DIkf5t-XcAEscRQ.jpg",
      "id_str" : "903288276718678017",
      "id" : "903288276718678017",
      "media_url_https" : "https://pbs.twimg.com/media/DIkf5t-XcAEscRQ.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "480",
          "h" : "594",
          "resize" : "fit"
        },
        "small" : {
          "w" : "480",
          "h" : "594",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "480",
          "h" : "594",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/KooQ2vnijA"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/903089394424401924/photo/1",
      "indices" : [ "6", "29" ],
      "url" : "https://t.co/UHN4wxEPrU",
      "media_url" : "http://pbs.twimg.com/media/DIhrA1LXkAACmgI.jpg",
      "id_str" : "903089387306717184",
      "id" : "903089387306717184",
      "media_url_https" : "https://pbs.twimg.com/media/DIhrA1LXkAACmgI.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "678",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "480",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "678",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/UHN4wxEPrU"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "29" ],
  "favorite_count" : "1",
  "id_str" : "903089394424401924",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "903089394424401924",
  "possibly_sensitive" : false,
  "created_at" : "Thu Aug 31 02:57:44 +0000 2017",
  "favorited" : false,
  "full_text" : "Bloop https://t.co/UHN4wxEPrU",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/903089394424401924/photo/1",
      "indices" : [ "6", "29" ],
      "url" : "https://t.co/UHN4wxEPrU",
      "media_url" : "http://pbs.twimg.com/media/DIhrA1LXkAACmgI.jpg",
      "id_str" : "903089387306717184",
      "id" : "903089387306717184",
      "media_url_https" : "https://pbs.twimg.com/media/DIhrA1LXkAACmgI.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "678",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "480",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "678",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/UHN4wxEPrU"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "UMD",
      "indices" : [ "41", "45" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Univ. of Maryland",
      "screen_name" : "UofMaryland",
      "indices" : [ "3", "15" ],
      "id_str" : "16129880",
      "id" : "16129880"
    }, {
      "name" : "Bowie State Uni.",
      "screen_name" : "BowieState",
      "indices" : [ "52", "63" ],
      "id_str" : "27767737",
      "id" : "27767737"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "0",
  "id_str" : "902979185458720771",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "902979185458720771",
  "created_at" : "Wed Aug 30 19:39:49 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @UofMaryland: At 12:05pm, please join #UMD &amp; @BowieState as we pause in silence. Our social media accounts will go silent as well https:…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "0",
  "id_str" : "902978205723840512",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "902978205723840512",
  "created_at" : "Wed Aug 30 19:35:55 +0000 2017",
  "favorited" : false,
  "full_text" : "Don't forget about the stamp art gallery opening tonight at 6pm!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/KbgyLDSYAo",
      "expanded_url" : "https://twitter.com/umdgsl/status/902910028453216256",
      "display_url" : "twitter.com/umdgsl/status/…",
      "indices" : [ "57", "80" ]
    } ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "1",
  "id_str" : "902915649894318080",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "902915649894318080",
  "possibly_sensitive" : false,
  "created_at" : "Wed Aug 30 15:27:20 +0000 2017",
  "favorited" : false,
  "full_text" : "Hey this is happening tomorrow for all you grad students https://t.co/KbgyLDSYAo",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/902888732935761921/photo/1",
      "indices" : [ "28", "51" ],
      "url" : "https://t.co/2iUoxpn91T",
      "media_url" : "http://pbs.twimg.com/media/DIe0gdWVYAAY3D2.jpg",
      "id_str" : "902888720038191104",
      "id" : "902888720038191104",
      "media_url_https" : "https://pbs.twimg.com/media/DIe0gdWVYAAY3D2.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "1000",
          "h" : "1000",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1000",
          "h" : "1000",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/2iUoxpn91T"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "51" ],
  "favorite_count" : "1",
  "id_str" : "902888732935761921",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "902888732935761921",
  "possibly_sensitive" : false,
  "created_at" : "Wed Aug 30 13:40:23 +0000 2017",
  "favorited" : false,
  "full_text" : "\uD83D\uDDE3 This is in 2 hours y'all! https://t.co/2iUoxpn91T",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/902888732935761921/photo/1",
      "indices" : [ "28", "51" ],
      "url" : "https://t.co/2iUoxpn91T",
      "media_url" : "http://pbs.twimg.com/media/DIe0gdWVYAAY3D2.jpg",
      "id_str" : "902888720038191104",
      "id" : "902888720038191104",
      "media_url_https" : "https://pbs.twimg.com/media/DIe0gdWVYAAY3D2.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "1000",
          "h" : "1000",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "1000",
          "h" : "1000",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/2iUoxpn91T"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "ALDI USA",
      "screen_name" : "AldiUSA",
      "indices" : [ "13", "21" ],
      "id_str" : "602314892",
      "id" : "602314892"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "902687439835234305",
  "id_str" : "902700137989988352",
  "in_reply_to_user_id" : "52884559",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "902700137989988352",
  "in_reply_to_status_id" : "902687439835234305",
  "created_at" : "Wed Aug 30 01:10:58 +0000 2017",
  "favorited" : false,
  "full_text" : "@meterock372 @AldiUSA \uD83D\uDC80\uD83D\uDE30\uD83D\uDE2D it hurts to see food go bad",
  "lang" : "en",
  "in_reply_to_screen_name" : "metecanerdi",
  "in_reply_to_user_id_str" : "52884559"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "134" ],
  "favorite_count" : "0",
  "id_str" : "902583628701556737",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "902583628701556737",
  "created_at" : "Tue Aug 29 17:28:00 +0000 2017",
  "favorited" : false,
  "full_text" : "Stamp Art Gallery is opening tomorrow night from 6-8pm. I hear there'll be some snacks to keep you company while you look at the art \uD83C\uDF7F",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/oGCj460iOs",
      "expanded_url" : "https://twitter.com/the_lyon_kingg/status/902344091765231616",
      "display_url" : "twitter.com/the_lyon_kingg…",
      "indices" : [ "36", "59" ]
    } ]
  },
  "display_text_range" : [ "0", "59" ],
  "favorite_count" : "3",
  "id_str" : "902577073646170112",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "902577073646170112",
  "possibly_sensitive" : false,
  "created_at" : "Tue Aug 29 17:01:58 +0000 2017",
  "favorited" : false,
  "full_text" : "Follow us instead we post more lmao https://t.co/oGCj460iOs",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/kK0jLsKNeF",
      "expanded_url" : "https://twitter.com/mileshighclub_/status/902302096287989764",
      "display_url" : "twitter.com/mileshighclub_…",
      "indices" : [ "58", "81" ]
    } ]
  },
  "display_text_range" : [ "0", "81" ],
  "favorite_count" : "0",
  "id_str" : "902378760925798400",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "902378760925798400",
  "possibly_sensitive" : false,
  "created_at" : "Tue Aug 29 03:53:56 +0000 2017",
  "favorited" : false,
  "full_text" : "No worries, there's plenty more food where that came from https://t.co/kK0jLsKNeF",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/902265536104595456/photo/1",
      "indices" : [ "103", "126" ],
      "url" : "https://t.co/KBZTRNFHsC",
      "media_url" : "http://pbs.twimg.com/media/DIV9t3eW4AUY4I0.jpg",
      "id_str" : "902265527296516101",
      "id" : "902265527296516101",
      "media_url_https" : "https://pbs.twimg.com/media/DIV9t3eW4AUY4I0.jpg",
      "sizes" : {
        "medium" : {
          "w" : "300",
          "h" : "300",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "300",
          "h" : "300",
          "resize" : "fit"
        },
        "small" : {
          "w" : "300",
          "h" : "300",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/KBZTRNFHsC"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "126" ],
  "favorite_count" : "0",
  "id_str" : "902265536104595456",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "902265536104595456",
  "possibly_sensitive" : false,
  "created_at" : "Mon Aug 28 20:24:01 +0000 2017",
  "favorited" : false,
  "full_text" : "Whooaa skits? Talks? Live music? AND food?  Check this out tomorrow  (the date should say august 29th) https://t.co/KBZTRNFHsC",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/902265536104595456/photo/1",
      "indices" : [ "103", "126" ],
      "url" : "https://t.co/KBZTRNFHsC",
      "media_url" : "http://pbs.twimg.com/media/DIV9t3eW4AUY4I0.jpg",
      "id_str" : "902265527296516101",
      "id" : "902265527296516101",
      "media_url_https" : "https://pbs.twimg.com/media/DIV9t3eW4AUY4I0.jpg",
      "sizes" : {
        "medium" : {
          "w" : "300",
          "h" : "300",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "300",
          "h" : "300",
          "resize" : "fit"
        },
        "small" : {
          "w" : "300",
          "h" : "300",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/KBZTRNFHsC"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "37" ],
  "favorite_count" : "0",
  "id_str" : "902232650194317312",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "902232650194317312",
  "created_at" : "Mon Aug 28 18:13:21 +0000 2017",
  "favorited" : false,
  "full_text" : "Free ice cream outside of CSIC rn!!!\uD83C\uDFC3",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/902170354088587264/photo/1",
      "indices" : [ "63", "86" ],
      "url" : "https://t.co/9sWH2mrj0T",
      "media_url" : "http://pbs.twimg.com/media/DIUnJvIXkAEqVKM.jpg",
      "id_str" : "902170348581523457",
      "id" : "902170348581523457",
      "media_url_https" : "https://pbs.twimg.com/media/DIUnJvIXkAEqVKM.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "960",
          "h" : "745",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "528",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "960",
          "h" : "745",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/9sWH2mrj0T"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "86" ],
  "favorite_count" : "0",
  "id_str" : "902170354088587264",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "902170354088587264",
  "possibly_sensitive" : false,
  "created_at" : "Mon Aug 28 14:05:48 +0000 2017",
  "favorited" : false,
  "full_text" : "Stop by this welcome back cookout at nyumburu today at 5:30pm! https://t.co/9sWH2mrj0T",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/902170354088587264/photo/1",
      "indices" : [ "63", "86" ],
      "url" : "https://t.co/9sWH2mrj0T",
      "media_url" : "http://pbs.twimg.com/media/DIUnJvIXkAEqVKM.jpg",
      "id_str" : "902170348581523457",
      "id" : "902170348581523457",
      "media_url_https" : "https://pbs.twimg.com/media/DIUnJvIXkAEqVKM.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "960",
          "h" : "745",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "528",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "960",
          "h" : "745",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/9sWH2mrj0T"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "65" ],
  "favorite_count" : "1",
  "id_str" : "902170040627232769",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "902170040627232769",
  "created_at" : "Mon Aug 28 14:04:33 +0000 2017",
  "favorited" : false,
  "full_text" : "Happy first day of school! Time for good grades and full stomachs",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "id_str" : "901568801338163200",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "901568801338163200",
  "created_at" : "Sat Aug 26 22:15:27 +0000 2017",
  "favorited" : false,
  "full_text" : "Also my dms are open if y'all have a free food hookup",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "56" ],
  "favorite_count" : "1",
  "id_str" : "901568725467398144",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "901568725467398144",
  "created_at" : "Sat Aug 26 22:15:09 +0000 2017",
  "favorited" : false,
  "full_text" : "We starting up again for the school year tell ya friends",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "91" ],
  "favorite_count" : "1",
  "id_str" : "901561306712612866",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "901561306712612866",
  "created_at" : "Sat Aug 26 21:45:40 +0000 2017",
  "favorited" : false,
  "full_text" : "Do Better UMD is having a cookout tonight at terrapin row to welcome the new school year \uD83C\uDF54\uD83C\uDF2D",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/860253189563703296/photo/1",
      "indices" : [ "4", "27" ],
      "url" : "https://t.co/mbtakFadBS",
      "media_url" : "http://pbs.twimg.com/media/C_A7tXFWsAAMDwA.jpg",
      "id_str" : "860253179304390656",
      "id" : "860253179304390656",
      "media_url_https" : "https://pbs.twimg.com/media/C_A7tXFWsAAMDwA.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "467",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "824",
          "resize" : "fit"
        },
        "large" : {
          "w" : "2048",
          "h" : "1407",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/mbtakFadBS"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "27" ],
  "favorite_count" : "0",
  "id_str" : "860253189563703296",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "860253189563703296",
  "possibly_sensitive" : false,
  "created_at" : "Thu May 04 22:01:57 +0000 2017",
  "favorited" : false,
  "full_text" : "\uD83C\uDFB5\uD83C\uDFB6\uD83C\uDFB5 https://t.co/mbtakFadBS",
  "lang" : "und",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/860253189563703296/photo/1",
      "indices" : [ "4", "27" ],
      "url" : "https://t.co/mbtakFadBS",
      "media_url" : "http://pbs.twimg.com/media/C_A7tXFWsAAMDwA.jpg",
      "id_str" : "860253179304390656",
      "id" : "860253179304390656",
      "media_url_https" : "https://pbs.twimg.com/media/C_A7tXFWsAAMDwA.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "467",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "1200",
          "h" : "824",
          "resize" : "fit"
        },
        "large" : {
          "w" : "2048",
          "h" : "1407",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/mbtakFadBS"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "138" ],
  "favorite_count" : "0",
  "id_str" : "859874335800139777",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "859874335800139777",
  "created_at" : "Wed May 03 20:56:32 +0000 2017",
  "favorited" : false,
  "full_text" : "Graduate Open House today at 6 - 7:30pm in the Kim engineering building rotunda. Learn about a professional master of engineering and eat!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "138" ],
  "favorite_count" : "0",
  "id_str" : "859871744542339073",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "859871744542339073",
  "created_at" : "Wed May 03 20:46:14 +0000 2017",
  "favorited" : false,
  "full_text" : "Head to the Kay Boardrooms in The Kim Engineering building to hear from a panel of women engineers who work at NASA and NTSB! At 5pm today",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "55" ],
  "favorite_count" : "1",
  "id_str" : "858758370576093186",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "858758370576093186",
  "created_at" : "Sun Apr 30 19:02:05 +0000 2017",
  "favorited" : false,
  "full_text" : "Head to Washington quad for a bunch of cookouts today!!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "67" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "857992572802920448",
  "id_str" : "858007156410511360",
  "in_reply_to_user_id" : "800904115924717569",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "858007156410511360",
  "in_reply_to_status_id" : "857992572802920448",
  "created_at" : "Fri Apr 28 17:17:01 +0000 2017",
  "favorited" : false,
  "full_text" : "Whoops they're serving Qdoba not chipotle, still worth checking out",
  "lang" : "en",
  "in_reply_to_screen_name" : "SeeFoodCalendar",
  "in_reply_to_user_id_str" : "800904115924717569"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "112" ],
  "favorite_count" : "0",
  "id_str" : "857992572802920448",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "857992572802920448",
  "created_at" : "Fri Apr 28 16:19:04 +0000 2017",
  "favorited" : false,
  "full_text" : "Bruh...y'all heard about the south campus block party? Slide through to Washington Quad at 3 for free chipotle \uD83C\uDF2F",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/857989719954796545/photo/1",
      "indices" : [ "4", "27" ],
      "url" : "https://t.co/0Dmi568Atk",
      "media_url" : "http://pbs.twimg.com/media/C-gxGWIXkAAKcj_.jpg",
      "id_str" : "857989714103734272",
      "id" : "857989714103734272",
      "media_url_https" : "https://pbs.twimg.com/media/C-gxGWIXkAAKcj_.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "480",
          "h" : "480",
          "resize" : "fit"
        },
        "small" : {
          "w" : "480",
          "h" : "480",
          "resize" : "fit"
        },
        "large" : {
          "w" : "480",
          "h" : "480",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/0Dmi568Atk"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "27" ],
  "favorite_count" : "0",
  "id_str" : "857989719954796545",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "857989719954796545",
  "possibly_sensitive" : false,
  "created_at" : "Fri Apr 28 16:07:44 +0000 2017",
  "favorited" : false,
  "full_text" : "\uD83D\uDC40\uD83D\uDC40\uD83D\uDC40 https://t.co/0Dmi568Atk",
  "lang" : "und",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/857989719954796545/photo/1",
      "indices" : [ "4", "27" ],
      "url" : "https://t.co/0Dmi568Atk",
      "media_url" : "http://pbs.twimg.com/media/C-gxGWIXkAAKcj_.jpg",
      "id_str" : "857989714103734272",
      "id" : "857989714103734272",
      "media_url_https" : "https://pbs.twimg.com/media/C-gxGWIXkAAKcj_.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "480",
          "h" : "480",
          "resize" : "fit"
        },
        "small" : {
          "w" : "480",
          "h" : "480",
          "resize" : "fit"
        },
        "large" : {
          "w" : "480",
          "h" : "480",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/0Dmi568Atk"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/857989546776166400/photo/1",
      "indices" : [ "19", "42" ],
      "url" : "https://t.co/wcsGUwYiMY",
      "media_url" : "http://pbs.twimg.com/media/C-gw8M9XkAAeUgy.jpg",
      "id_str" : "857989539842985984",
      "id" : "857989539842985984",
      "media_url_https" : "https://pbs.twimg.com/media/C-gw8M9XkAAeUgy.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "542",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "384",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "542",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/wcsGUwYiMY"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "42" ],
  "favorite_count" : "0",
  "id_str" : "857989546776166400",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "857989546776166400",
  "possibly_sensitive" : false,
  "created_at" : "Fri Apr 28 16:07:03 +0000 2017",
  "favorited" : false,
  "full_text" : "This looks lit  \uD83C\uDF89\uD83C\uDF89 https://t.co/wcsGUwYiMY",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/857989546776166400/photo/1",
      "indices" : [ "19", "42" ],
      "url" : "https://t.co/wcsGUwYiMY",
      "media_url" : "http://pbs.twimg.com/media/C-gw8M9XkAAeUgy.jpg",
      "id_str" : "857989539842985984",
      "id" : "857989539842985984",
      "media_url_https" : "https://pbs.twimg.com/media/C-gw8M9XkAAeUgy.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "542",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "384",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "542",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/wcsGUwYiMY"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "857751943007154176",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "857751943007154176",
  "created_at" : "Fri Apr 28 00:22:54 +0000 2017",
  "favorited" : false,
  "full_text" : "Free food by the Pakistani students association in the colony ballroom at stamp! At 8:30pm today!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/857707365197635584/photo/1",
      "indices" : [ "30", "53" ],
      "url" : "https://t.co/Bgbo2RNoN9",
      "media_url" : "http://pbs.twimg.com/media/C-cwTC2XUAEn5C0.jpg",
      "id_str" : "857707357777907713",
      "id" : "857707357777907713",
      "media_url_https" : "https://pbs.twimg.com/media/C-cwTC2XUAEn5C0.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "540",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "540",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "383",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/Bgbo2RNoN9"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "id_str" : "857707365197635584",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "857707365197635584",
  "possibly_sensitive" : false,
  "created_at" : "Thu Apr 27 21:25:45 +0000 2017",
  "favorited" : false,
  "full_text" : "Did somebody say free dinner? https://t.co/Bgbo2RNoN9",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/857707365197635584/photo/1",
      "indices" : [ "30", "53" ],
      "url" : "https://t.co/Bgbo2RNoN9",
      "media_url" : "http://pbs.twimg.com/media/C-cwTC2XUAEn5C0.jpg",
      "id_str" : "857707357777907713",
      "id" : "857707357777907713",
      "media_url_https" : "https://pbs.twimg.com/media/C-cwTC2XUAEn5C0.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "540",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "540",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "383",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/Bgbo2RNoN9"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "0",
  "id_str" : "857655936411996161",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "857655936411996161",
  "created_at" : "Thu Apr 27 18:01:24 +0000 2017",
  "favorited" : false,
  "full_text" : "Free insomnia cookies in from of mckeldin right now!!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "77" ],
  "favorite_count" : "0",
  "id_str" : "857589707231952897",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "857589707231952897",
  "created_at" : "Thu Apr 27 13:38:14 +0000 2017",
  "favorited" : false,
  "full_text" : "If you live in courtyards they have free juice and donuts at the 500 bus stop",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "ChapelUMD",
      "screen_name" : "ChapelUMD",
      "indices" : [ "3", "13" ],
      "id_str" : "2427769519",
      "id" : "2427769519"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "854726476767383552",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "854726476767383552",
  "created_at" : "Wed Apr 19 16:00:46 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @ChapelUMD: Drop in for relaxing, meditative music. Enjoy a free lunch. Walk the labyrinth in the adjacent garden. Garden Chapel, 12pm t…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "99" ],
  "favorite_count" : "1",
  "id_str" : "854695573575917569",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "854695573575917569",
  "created_at" : "Wed Apr 19 13:57:58 +0000 2017",
  "favorited" : false,
  "full_text" : "Don't forget...Newsbreak is today at 11:50am in Nyumburu. Free pizza and current events discussion!",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/854350316057370624/photo/1",
      "indices" : [ "40", "63" ],
      "url" : "https://t.co/IpFVpQWGhg",
      "media_url" : "http://pbs.twimg.com/media/C9tDFGCVwAAMtIW.jpg",
      "id_str" : "854350309115674624",
      "id" : "854350309115674624",
      "media_url_https" : "https://pbs.twimg.com/media/C9tDFGCVwAAMtIW.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "720",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "720",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/IpFVpQWGhg"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "63" ],
  "favorite_count" : "0",
  "id_str" : "854350316057370624",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "854350316057370624",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 18 15:06:03 +0000 2017",
  "favorited" : false,
  "full_text" : "Free food at hornbake plaza right now!! https://t.co/IpFVpQWGhg",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/854350316057370624/photo/1",
      "indices" : [ "40", "63" ],
      "url" : "https://t.co/IpFVpQWGhg",
      "media_url" : "http://pbs.twimg.com/media/C9tDFGCVwAAMtIW.jpg",
      "id_str" : "854350309115674624",
      "id" : "854350309115674624",
      "media_url_https" : "https://pbs.twimg.com/media/C9tDFGCVwAAMtIW.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "720",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "large" : {
          "w" : "720",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/IpFVpQWGhg"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nya",
      "screen_name" : "NyaaaMae",
      "indices" : [ "3", "12" ],
      "id_str" : "2757888574",
      "id" : "2757888574"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/NyaaaMae/status/852919151735734272/photo/1",
      "source_status_id" : "852919151735734272",
      "indices" : [ "57", "80" ],
      "url" : "https://t.co/XhAOI17HdO",
      "media_url" : "http://pbs.twimg.com/media/C9YtcjjXgAEwwqg.jpg",
      "id_str" : "852919148036456449",
      "source_user_id" : "2757888574",
      "id" : "852919148036456449",
      "media_url_https" : "https://pbs.twimg.com/media/C9YtcjjXgAEwwqg.jpg",
      "source_user_id_str" : "2757888574",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "746",
          "h" : "502",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "458",
          "resize" : "fit"
        },
        "large" : {
          "w" : "746",
          "h" : "502",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "852919151735734272",
      "display_url" : "pic.twitter.com/XhAOI17HdO"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "80" ],
  "favorite_count" : "0",
  "id_str" : "853739112343494658",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "853739112343494658",
  "possibly_sensitive" : false,
  "created_at" : "Sun Apr 16 22:37:20 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @NyaaaMae: Free food, athletes, students, discussion! https://t.co/XhAOI17HdO",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/NyaaaMae/status/852919151735734272/photo/1",
      "source_status_id" : "852919151735734272",
      "indices" : [ "57", "80" ],
      "url" : "https://t.co/XhAOI17HdO",
      "media_url" : "http://pbs.twimg.com/media/C9YtcjjXgAEwwqg.jpg",
      "id_str" : "852919148036456449",
      "source_user_id" : "2757888574",
      "id" : "852919148036456449",
      "media_url_https" : "https://pbs.twimg.com/media/C9YtcjjXgAEwwqg.jpg",
      "source_user_id_str" : "2757888574",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "746",
          "h" : "502",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "458",
          "resize" : "fit"
        },
        "large" : {
          "w" : "746",
          "h" : "502",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "852919151735734272",
      "display_url" : "pic.twitter.com/XhAOI17HdO"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Business Assoc",
      "screen_name" : "BBATerp",
      "indices" : [ "3", "11" ],
      "id_str" : "368458309",
      "id" : "368458309"
    } ],
    "urls" : [ {
      "url" : "https://t.co/AE3fyHyLu9",
      "expanded_url" : "https://www.eventbrite.com/e/bba-business-etiquette-dinner-tickets-33198105427",
      "display_url" : "eventbrite.com/e/bba-business…",
      "indices" : [ "85", "108" ]
    } ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/BBATerp/status/853738303249666049/photo/1",
      "source_status_id" : "853738303249666049",
      "indices" : [ "109", "132" ],
      "url" : "https://t.co/hdo9SXM8d1",
      "media_url" : "http://pbs.twimg.com/media/C9kWc_KXcAAgp6x.jpg",
      "id_str" : "853738291610480640",
      "source_user_id" : "368458309",
      "id" : "853738291610480640",
      "media_url_https" : "https://pbs.twimg.com/media/C9kWc_KXcAAgp6x.jpg",
      "source_user_id_str" : "368458309",
      "sizes" : {
        "large" : {
          "w" : "960",
          "h" : "645",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "645",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "457",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "853738303249666049",
      "display_url" : "pic.twitter.com/hdo9SXM8d1"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "132" ],
  "favorite_count" : "0",
  "id_str" : "853738711019683840",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "853738711019683840",
  "possibly_sensitive" : false,
  "created_at" : "Sun Apr 16 22:35:45 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @BBATerp: There is still space left for the Business Etiquette Dinner. RSVP here: https://t.co/AE3fyHyLu9 https://t.co/hdo9SXM8d1",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/BBATerp/status/853738303249666049/photo/1",
      "source_status_id" : "853738303249666049",
      "indices" : [ "109", "132" ],
      "url" : "https://t.co/hdo9SXM8d1",
      "media_url" : "http://pbs.twimg.com/media/C9kWc_KXcAAgp6x.jpg",
      "id_str" : "853738291610480640",
      "source_user_id" : "368458309",
      "id" : "853738291610480640",
      "media_url_https" : "https://pbs.twimg.com/media/C9kWc_KXcAAgp6x.jpg",
      "source_user_id_str" : "368458309",
      "sizes" : {
        "large" : {
          "w" : "960",
          "h" : "645",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "645",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "457",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "853738303249666049",
      "display_url" : "pic.twitter.com/hdo9SXM8d1"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/852574122131501056/photo/1",
      "indices" : [ "90", "113" ],
      "url" : "https://t.co/16CBp68jTm",
      "media_url" : "http://pbs.twimg.com/media/C9TzpDdW0AAr1kL.jpg",
      "id_str" : "852574116108488704",
      "id" : "852574116108488704",
      "media_url_https" : "https://pbs.twimg.com/media/C9TzpDdW0AAr1kL.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "640",
          "h" : "632",
          "resize" : "fit"
        },
        "small" : {
          "w" : "640",
          "h" : "632",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "640",
          "h" : "632",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/16CBp68jTm"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "113" ],
  "favorite_count" : "0",
  "id_str" : "852574122131501056",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "852574122131501056",
  "possibly_sensitive" : false,
  "created_at" : "Thu Apr 13 17:28:05 +0000 2017",
  "favorited" : false,
  "full_text" : "Check this out! You can get free pizza and network with people working government jobs! \uD83D\uDD74 https://t.co/16CBp68jTm",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/852574122131501056/photo/1",
      "indices" : [ "90", "113" ],
      "url" : "https://t.co/16CBp68jTm",
      "media_url" : "http://pbs.twimg.com/media/C9TzpDdW0AAr1kL.jpg",
      "id_str" : "852574116108488704",
      "id" : "852574116108488704",
      "media_url_https" : "https://pbs.twimg.com/media/C9TzpDdW0AAr1kL.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "640",
          "h" : "632",
          "resize" : "fit"
        },
        "small" : {
          "w" : "640",
          "h" : "632",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "640",
          "h" : "632",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/16CBp68jTm"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/xrAPd061l5",
      "expanded_url" : "https://twitter.com/krazikebob/status/852560328588218368",
      "display_url" : "twitter.com/krazikebob/sta…",
      "indices" : [ "31", "54" ]
    } ]
  },
  "display_text_range" : [ "0", "54" ],
  "favorite_count" : "1",
  "id_str" : "852564268985798657",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "852564268985798657",
  "possibly_sensitive" : false,
  "created_at" : "Thu Apr 13 16:48:56 +0000 2017",
  "favorited" : false,
  "full_text" : "Whaaaat?? We eating good today https://t.co/xrAPd061l5",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/851468765489491968/photo/1",
      "indices" : [ "47", "70" ],
      "url" : "https://t.co/n0mHL5f3eS",
      "media_url" : "http://pbs.twimg.com/media/C9EGUUhW0AQbopw.jpg",
      "id_str" : "851468750725500932",
      "id" : "851468750725500932",
      "media_url_https" : "https://pbs.twimg.com/media/C9EGUUhW0AQbopw.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "637",
          "h" : "960",
          "resize" : "fit"
        },
        "large" : {
          "w" : "637",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "451",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/n0mHL5f3eS"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "70" ],
  "favorite_count" : "0",
  "id_str" : "851468765489491968",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "851468765489491968",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 10 16:15:47 +0000 2017",
  "favorited" : false,
  "full_text" : "Really cool opportunity for women in comp sci! https://t.co/n0mHL5f3eS",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/851468765489491968/photo/1",
      "indices" : [ "47", "70" ],
      "url" : "https://t.co/n0mHL5f3eS",
      "media_url" : "http://pbs.twimg.com/media/C9EGUUhW0AQbopw.jpg",
      "id_str" : "851468750725500932",
      "id" : "851468750725500932",
      "media_url_https" : "https://pbs.twimg.com/media/C9EGUUhW0AQbopw.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "637",
          "h" : "960",
          "resize" : "fit"
        },
        "large" : {
          "w" : "637",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "451",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/n0mHL5f3eS"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "freefood",
      "indices" : [ "124", "133" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "CMSE",
      "screen_name" : "CMSEUMD",
      "indices" : [ "22", "30" ],
      "id_str" : "2201812292",
      "id" : "2201812292"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "133" ],
  "favorite_count" : "0",
  "id_str" : "850164827867762689",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "850164827867762689",
  "created_at" : "Fri Apr 07 01:54:24 +0000 2017",
  "favorited" : false,
  "full_text" : "First Friday Event by @CMSEUMD \n\nFriday, April 7, 2017 from 1:00pm – 3:00pm in 1107 &amp; 1111 Kim Bldg (Kay Board Rooms). \n#freefood",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "SHAC UMD",
      "screen_name" : "shac_umd",
      "indices" : [ "3", "12" ],
      "id_str" : "714514973322526722",
      "id" : "714514973322526722"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "144" ],
  "favorite_count" : "0",
  "id_str" : "850159220670570496",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "850159220670570496",
  "created_at" : "Fri Apr 07 01:32:08 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @shac_umd: Join us TOMORROW at the UNIVERSITY HEALTH CENTER for FREE PIZZA and a Panel Discussion on Sexual &amp; Women's Health from Profes…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/79Ukfhh6Gc",
      "expanded_url" : "https://twitter.com/xraniyaa/status/849662701810974721",
      "display_url" : "twitter.com/xraniyaa/statu…",
      "indices" : [ "72", "95" ]
    } ]
  },
  "display_text_range" : [ "0", "95" ],
  "favorite_count" : "1",
  "id_str" : "849726936603643908",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "849726936603643908",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 05 20:54:23 +0000 2017",
  "favorited" : false,
  "full_text" : "No worries! There's plenty more free food at 5pm (check me last tweets) https://t.co/79Ukfhh6Gc",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Honors Caucus",
      "screen_name" : "BHC_UMD",
      "indices" : [ "3", "11" ],
      "id_str" : "397036296",
      "id" : "397036296"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/BHC_UMD/status/849713009555582976/photo/1",
      "source_status_id" : "849713009555582976",
      "indices" : [ "49", "72" ],
      "url" : "https://t.co/SolEK4jUXp",
      "media_url" : "http://pbs.twimg.com/media/C8rJdwlXYAAAwrP.jpg",
      "id_str" : "849712992807772160",
      "source_user_id" : "397036296",
      "id" : "849712992807772160",
      "media_url_https" : "https://pbs.twimg.com/media/C8rJdwlXYAAAwrP.jpg",
      "source_user_id_str" : "397036296",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "608",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "612",
          "h" : "684",
          "resize" : "fit"
        },
        "large" : {
          "w" : "612",
          "h" : "684",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "849713009555582976",
      "display_url" : "pic.twitter.com/SolEK4jUXp"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "id_str" : "849726530481684480",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "849726530481684480",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 05 20:52:46 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @BHC_UMD: Did I forgot to mention free food \uD83E\uDD14 https://t.co/SolEK4jUXp",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/BHC_UMD/status/849713009555582976/photo/1",
      "source_status_id" : "849713009555582976",
      "indices" : [ "49", "72" ],
      "url" : "https://t.co/SolEK4jUXp",
      "media_url" : "http://pbs.twimg.com/media/C8rJdwlXYAAAwrP.jpg",
      "id_str" : "849712992807772160",
      "source_user_id" : "397036296",
      "id" : "849712992807772160",
      "media_url_https" : "https://pbs.twimg.com/media/C8rJdwlXYAAAwrP.jpg",
      "source_user_id_str" : "397036296",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "608",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "612",
          "h" : "684",
          "resize" : "fit"
        },
        "large" : {
          "w" : "612",
          "h" : "684",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "849713009555582976",
      "display_url" : "pic.twitter.com/SolEK4jUXp"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "LGBTQ",
      "indices" : [ "29", "35" ]
    }, {
      "text" : "AAPI",
      "indices" : [ "41", "46" ]
    }, {
      "text" : "Terps",
      "indices" : [ "47", "53" ]
    }, {
      "text" : "PrideMonthUMD",
      "indices" : [ "124", "138" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "3", "15" ],
      "id_str" : "59604041",
      "id" : "59604041"
    }, {
      "name" : "U of MD MICA",
      "screen_name" : "UMDMICA",
      "indices" : [ "89", "97" ],
      "id_str" : "75010872",
      "id" : "75010872"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "849655001949622273",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "849655001949622273",
  "created_at" : "Wed Apr 05 16:08:32 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @thestampumd: Calling all #LGBTQ+ and #AAPI #Terps! Grab your lunch and gather in the @UMDMICA conference room tomorrow! #PrideMonthUMD…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ {
      "text" : "bikeweek",
      "indices" : [ "110", "119" ]
    }, {
      "text" : "BikeUMD",
      "indices" : [ "120", "128" ]
    } ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "UMD DOTS \uD83D\uDE8D\uD83D\uDE98\uD83D\uDEB2",
      "screen_name" : "DOTS_UMD",
      "indices" : [ "3", "12" ],
      "id_str" : "95280326",
      "id" : "95280326"
    }, {
      "name" : "Transfer&Off-Campus",
      "screen_name" : "UMDTOCSL",
      "indices" : [ "84", "93" ],
      "id_str" : "1205397097",
      "id" : "1205397097"
    }, {
      "name" : "STAMP",
      "screen_name" : "thestampumd",
      "indices" : [ "97", "109" ],
      "id_str" : "59604041",
      "id" : "59604041"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "849619759243169792",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "849619759243169792",
  "created_at" : "Wed Apr 05 13:48:30 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @DOTS_UMD: Breakfast is waiting for our awesome bike commuters this morning with @UMDTOCSL at @thestampumd #bikeweek #BikeUMD https://t.…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/849499790140481536/photo/1",
      "indices" : [ "39", "62" ],
      "url" : "https://t.co/TZtpyGus7A",
      "media_url" : "http://pbs.twimg.com/tweet_video_thumb/C8oHjGqXgAAlHfb.jpg",
      "id_str" : "849499779377889280",
      "id" : "849499779377889280",
      "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/C8oHjGqXgAAlHfb.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "500",
          "h" : "270",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "500",
          "h" : "270",
          "resize" : "fit"
        },
        "small" : {
          "w" : "500",
          "h" : "270",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/TZtpyGus7A"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "62" ],
  "favorite_count" : "1",
  "id_str" : "849499790140481536",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "849499790140481536",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 05 05:51:47 +0000 2017",
  "favorited" : false,
  "full_text" : "When there's too many free food events https://t.co/TZtpyGus7A",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/849499790140481536/photo/1",
      "indices" : [ "39", "62" ],
      "url" : "https://t.co/TZtpyGus7A",
      "media_url" : "http://pbs.twimg.com/tweet_video_thumb/C8oHjGqXgAAlHfb.jpg",
      "id_str" : "849499779377889280",
      "video_info" : {
        "aspect_ratio" : [ "50", "27" ],
        "variants" : [ {
          "bitrate" : "0",
          "content_type" : "video/mp4",
          "url" : "https://video.twimg.com/tweet_video/C8oHjGqXgAAlHfb.mp4"
        } ]
      },
      "id" : "849499779377889280",
      "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/C8oHjGqXgAAlHfb.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "500",
          "h" : "270",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "500",
          "h" : "270",
          "resize" : "fit"
        },
        "small" : {
          "w" : "500",
          "h" : "270",
          "resize" : "fit"
        }
      },
      "type" : "animated_gif",
      "display_url" : "pic.twitter.com/TZtpyGus7A"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/849499071652003841/photo/1",
      "indices" : [ "7", "30" ],
      "url" : "https://t.co/de5MQypcsv",
      "media_url" : "http://pbs.twimg.com/media/C8oG5CsXkAEYfEd.jpg",
      "id_str" : "849499056758034433",
      "id" : "849499056758034433",
      "media_url_https" : "https://pbs.twimg.com/media/C8oG5CsXkAEYfEd.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "510",
          "resize" : "fit"
        },
        "large" : {
          "w" : "800",
          "h" : "600",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "800",
          "h" : "600",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/de5MQypcsv"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "30" ],
  "favorite_count" : "2",
  "in_reply_to_status_id_str" : "849498408079458305",
  "id_str" : "849499071652003841",
  "in_reply_to_user_id" : "800904115924717569",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "849499071652003841",
  "in_reply_to_status_id" : "849498408079458305",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 05 05:48:56 +0000 2017",
  "favorited" : false,
  "full_text" : "\uD83D\uDE4C\uD83C\uDFFF\uD83D\uDE4C\uD83C\uDFFF\uD83D\uDE4C\uD83C\uDFFF https://t.co/de5MQypcsv",
  "lang" : "und",
  "in_reply_to_screen_name" : "SeeFoodCalendar",
  "in_reply_to_user_id_str" : "800904115924717569",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/849499071652003841/photo/1",
      "indices" : [ "7", "30" ],
      "url" : "https://t.co/de5MQypcsv",
      "media_url" : "http://pbs.twimg.com/media/C8oG5CsXkAEYfEd.jpg",
      "id_str" : "849499056758034433",
      "id" : "849499056758034433",
      "media_url_https" : "https://pbs.twimg.com/media/C8oG5CsXkAEYfEd.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "510",
          "resize" : "fit"
        },
        "large" : {
          "w" : "800",
          "h" : "600",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "800",
          "h" : "600",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/de5MQypcsv"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/849498408079458305/photo/1",
      "indices" : [ "24", "47" ],
      "url" : "https://t.co/MjlgGs3IrW",
      "media_url" : "http://pbs.twimg.com/media/C8oGS_IXYAAZjmM.jpg",
      "id_str" : "849498402966691840",
      "id" : "849498402966691840",
      "media_url_https" : "https://pbs.twimg.com/media/C8oGS_IXYAAZjmM.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "640",
          "h" : "1136",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "640",
          "h" : "1136",
          "resize" : "fit"
        },
        "small" : {
          "w" : "383",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/MjlgGs3IrW"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "47" ],
  "favorite_count" : "2",
  "in_reply_to_status_id_str" : "849498157406982144",
  "id_str" : "849498408079458305",
  "in_reply_to_user_id" : "800904115924717569",
  "truncated" : false,
  "retweet_count" : "2",
  "id" : "849498408079458305",
  "in_reply_to_status_id" : "849498157406982144",
  "possibly_sensitive" : false,
  "created_at" : "Wed Apr 05 05:46:18 +0000 2017",
  "favorited" : false,
  "full_text" : "Hip hop fest cook out!! https://t.co/MjlgGs3IrW",
  "lang" : "en",
  "in_reply_to_screen_name" : "SeeFoodCalendar",
  "in_reply_to_user_id_str" : "800904115924717569",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/849498408079458305/photo/1",
      "indices" : [ "24", "47" ],
      "url" : "https://t.co/MjlgGs3IrW",
      "media_url" : "http://pbs.twimg.com/media/C8oGS_IXYAAZjmM.jpg",
      "id_str" : "849498402966691840",
      "id" : "849498402966691840",
      "media_url_https" : "https://pbs.twimg.com/media/C8oGS_IXYAAZjmM.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "640",
          "h" : "1136",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "640",
          "h" : "1136",
          "resize" : "fit"
        },
        "small" : {
          "w" : "383",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/MjlgGs3IrW"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "93" ],
  "favorite_count" : "1",
  "in_reply_to_status_id_str" : "849497562537242624",
  "id_str" : "849498157406982144",
  "in_reply_to_user_id" : "800904115924717569",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "849498157406982144",
  "in_reply_to_status_id" : "849497562537242624",
  "created_at" : "Wed Apr 05 05:45:18 +0000 2017",
  "favorited" : false,
  "full_text" : "Free pizza and discussion for NewsBreak from 11:50am to 12:50pm at Nyumburu multipurpose room",
  "lang" : "en",
  "in_reply_to_screen_name" : "SeeFoodCalendar",
  "in_reply_to_user_id_str" : "800904115924717569"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "78" ],
  "favorite_count" : "0",
  "id_str" : "849497562537242624",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "849497562537242624",
  "created_at" : "Wed Apr 05 05:42:56 +0000 2017",
  "favorited" : false,
  "full_text" : "Commuter breakfast (bagels, muffins, etc) from 7:30am-11am at the stamp atrium",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "77" ],
  "favorite_count" : "0",
  "id_str" : "849496837686005760",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "849496837686005760",
  "created_at" : "Wed Apr 05 05:40:03 +0000 2017",
  "favorited" : false,
  "full_text" : "Whoaaa we got hella events tomorrow, y'all can get all your meals for free 99",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/849365749701500930/photo/1",
      "indices" : [ "41", "64" ],
      "url" : "https://t.co/v1b4I059ZI",
      "media_url" : "http://pbs.twimg.com/media/C8mNoMAXYAQp-tG.jpg",
      "id_str" : "849365726293090308",
      "id" : "849365726293090308",
      "media_url_https" : "https://pbs.twimg.com/media/C8mNoMAXYAQp-tG.jpg",
      "sizes" : {
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "720",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "720",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/v1b4I059ZI"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "0",
  "id_str" : "849365749701500930",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "849365749701500930",
  "possibly_sensitive" : false,
  "created_at" : "Tue Apr 04 20:59:09 +0000 2017",
  "favorited" : false,
  "full_text" : "Free Pizza in Tawes at 5:30 let's gooooo https://t.co/v1b4I059ZI",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/849365749701500930/photo/1",
      "indices" : [ "41", "64" ],
      "url" : "https://t.co/v1b4I059ZI",
      "media_url" : "http://pbs.twimg.com/media/C8mNoMAXYAQp-tG.jpg",
      "id_str" : "849365726293090308",
      "id" : "849365726293090308",
      "media_url_https" : "https://pbs.twimg.com/media/C8mNoMAXYAQp-tG.jpg",
      "sizes" : {
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "720",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "720",
          "h" : "960",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/v1b4I059ZI"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/UNMBxKpO5h",
      "expanded_url" : "https://twitter.com/blackterp/status/848919949485760512",
      "display_url" : "twitter.com/blackterp/stat…",
      "indices" : [ "3", "26" ]
    } ]
  },
  "display_text_range" : [ "0", "26" ],
  "favorite_count" : "1",
  "id_str" : "849038968708640768",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "849038968708640768",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 03 23:20:39 +0000 2017",
  "favorited" : false,
  "full_text" : "\uD83D\uDC40\uD83D\uDC40 https://t.co/UNMBxKpO5h",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/848979973813796866/photo/1",
      "indices" : [ "30", "53" ],
      "url" : "https://t.co/dAKq7ppgX0",
      "media_url" : "http://pbs.twimg.com/media/C8gux4rXsAE6isK.jpg",
      "id_str" : "848979964322099201",
      "id" : "848979964322099201",
      "media_url_https" : "https://pbs.twimg.com/media/C8gux4rXsAE6isK.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "540",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "540",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "383",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/dAKq7ppgX0"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "53" ],
  "favorite_count" : "2",
  "id_str" : "848979973813796866",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "848979973813796866",
  "possibly_sensitive" : false,
  "created_at" : "Mon Apr 03 19:26:13 +0000 2017",
  "favorited" : false,
  "full_text" : "Free food in Tawes at 6:30pm! https://t.co/dAKq7ppgX0",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/848979973813796866/photo/1",
      "indices" : [ "30", "53" ],
      "url" : "https://t.co/dAKq7ppgX0",
      "media_url" : "http://pbs.twimg.com/media/C8gux4rXsAE6isK.jpg",
      "id_str" : "848979964322099201",
      "id" : "848979964322099201",
      "media_url_https" : "https://pbs.twimg.com/media/C8gux4rXsAE6isK.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "540",
          "h" : "960",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "540",
          "h" : "960",
          "resize" : "fit"
        },
        "small" : {
          "w" : "383",
          "h" : "680",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/dAKq7ppgX0"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/847891313353777152/photo/1",
      "indices" : [ "94", "117" ],
      "url" : "https://t.co/gJYLEGO3Jv",
      "media_url" : "http://pbs.twimg.com/media/C8RQpdKWsAAzcml.jpg",
      "id_str" : "847891302985412608",
      "id" : "847891302985412608",
      "media_url_https" : "https://pbs.twimg.com/media/C8RQpdKWsAAzcml.jpg",
      "sizes" : {
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1536",
          "h" : "2048",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "900",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/gJYLEGO3Jv"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "117" ],
  "favorite_count" : "0",
  "id_str" : "847891313353777152",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "847891313353777152",
  "possibly_sensitive" : false,
  "created_at" : "Fri Mar 31 19:20:16 +0000 2017",
  "favorited" : false,
  "full_text" : "Aye go make food and make puns at the Edible Book Festival on Monday at 12:30, hornbake plaza https://t.co/gJYLEGO3Jv",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/847891313353777152/photo/1",
      "indices" : [ "94", "117" ],
      "url" : "https://t.co/gJYLEGO3Jv",
      "media_url" : "http://pbs.twimg.com/media/C8RQpdKWsAAzcml.jpg",
      "id_str" : "847891302985412608",
      "id" : "847891302985412608",
      "media_url_https" : "https://pbs.twimg.com/media/C8RQpdKWsAAzcml.jpg",
      "sizes" : {
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1536",
          "h" : "2048",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "900",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/gJYLEGO3Jv"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Black Honors Caucus",
      "screen_name" : "BHC_UMD",
      "indices" : [ "0", "8" ],
      "id_str" : "397036296",
      "id" : "397036296"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "8" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "846897368154845185",
  "id_str" : "846930359782658048",
  "in_reply_to_user_id" : "800904115924717569",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "846930359782658048",
  "in_reply_to_status_id" : "846897368154845185",
  "created_at" : "Wed Mar 29 03:41:47 +0000 2017",
  "favorited" : false,
  "full_text" : "@BHC_UMD",
  "lang" : "und",
  "in_reply_to_screen_name" : "SeeFoodCalendar",
  "in_reply_to_user_id_str" : "800904115924717569"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/846930270167158784/photo/1",
      "indices" : [ "46", "69" ],
      "url" : "https://t.co/PLR9hQoH9T",
      "media_url" : "http://pbs.twimg.com/tweet_video_thumb/C8DmlYGXwAAq1fb.jpg",
      "id_str" : "846930259744374784",
      "id" : "846930259744374784",
      "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/C8DmlYGXwAAq1fb.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "500",
          "h" : "280",
          "resize" : "fit"
        },
        "small" : {
          "w" : "500",
          "h" : "280",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "500",
          "h" : "280",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/PLR9hQoH9T"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "69" ],
  "favorite_count" : "1",
  "id_str" : "846930270167158784",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "846930270167158784",
  "possibly_sensitive" : false,
  "created_at" : "Wed Mar 29 03:41:26 +0000 2017",
  "favorited" : false,
  "full_text" : "Stay tuned y'all, free food coming at ya soon https://t.co/PLR9hQoH9T",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/846930270167158784/photo/1",
      "indices" : [ "46", "69" ],
      "url" : "https://t.co/PLR9hQoH9T",
      "media_url" : "http://pbs.twimg.com/tweet_video_thumb/C8DmlYGXwAAq1fb.jpg",
      "id_str" : "846930259744374784",
      "video_info" : {
        "aspect_ratio" : [ "25", "14" ],
        "variants" : [ {
          "bitrate" : "0",
          "content_type" : "video/mp4",
          "url" : "https://video.twimg.com/tweet_video/C8DmlYGXwAAq1fb.mp4"
        } ]
      },
      "id" : "846930259744374784",
      "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/C8DmlYGXwAAq1fb.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "500",
          "h" : "280",
          "resize" : "fit"
        },
        "small" : {
          "w" : "500",
          "h" : "280",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "500",
          "h" : "280",
          "resize" : "fit"
        }
      },
      "type" : "animated_gif",
      "display_url" : "pic.twitter.com/PLR9hQoH9T"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/846897368154845185/photo/1",
      "indices" : [ "72", "95" ],
      "url" : "https://t.co/bvVmaM0c1E",
      "media_url" : "http://pbs.twimg.com/media/C8DIqYEVQAAcO8i.jpg",
      "id_str" : "846897360286334976",
      "id" : "846897360286334976",
      "media_url_https" : "https://pbs.twimg.com/media/C8DIqYEVQAAcO8i.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1536",
          "h" : "2048",
          "resize" : "fit"
        },
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "900",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/bvVmaM0c1E"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "95" ],
  "favorite_count" : "27",
  "id_str" : "846897368154845185",
  "truncated" : false,
  "retweet_count" : "8",
  "id" : "846897368154845185",
  "possibly_sensitive" : false,
  "created_at" : "Wed Mar 29 01:30:41 +0000 2017",
  "favorited" : false,
  "full_text" : "Had a great time presenting at the Black Student Entrepreneurship Panel https://t.co/bvVmaM0c1E",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/846897368154845185/photo/1",
      "indices" : [ "72", "95" ],
      "url" : "https://t.co/bvVmaM0c1E",
      "media_url" : "http://pbs.twimg.com/media/C8DIqYEVQAAcO8i.jpg",
      "id_str" : "846897360286334976",
      "id" : "846897360286334976",
      "media_url_https" : "https://pbs.twimg.com/media/C8DIqYEVQAAcO8i.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "large" : {
          "w" : "1536",
          "h" : "2048",
          "resize" : "fit"
        },
        "small" : {
          "w" : "510",
          "h" : "680",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "900",
          "h" : "1200",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/bvVmaM0c1E"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "••O••",
      "screen_name" : "ObiWanWonodi",
      "indices" : [ "3", "16" ],
      "id_str" : "243901756",
      "id" : "243901756"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/ObiWanWonodi/status/846797306901004289/photo/1",
      "source_status_id" : "846797306901004289",
      "indices" : [ "59", "82" ],
      "url" : "https://t.co/jbAU3XNhWv",
      "media_url" : "http://pbs.twimg.com/media/C8Btp0FXwAE7_V-.jpg",
      "id_str" : "846797295068889089",
      "source_user_id" : "243901756",
      "id" : "846797295068889089",
      "media_url_https" : "https://pbs.twimg.com/media/C8Btp0FXwAE7_V-.jpg",
      "source_user_id_str" : "243901756",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "453",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "960",
          "h" : "640",
          "resize" : "fit"
        },
        "large" : {
          "w" : "960",
          "h" : "640",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "846797306901004289",
      "display_url" : "pic.twitter.com/jbAU3XNhWv"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "82" ],
  "favorite_count" : "0",
  "id_str" : "846798312497975296",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "846798312497975296",
  "possibly_sensitive" : false,
  "created_at" : "Tue Mar 28 18:57:05 +0000 2017",
  "favorited" : false,
  "full_text" : "RT @ObiWanWonodi: Ya girl will be giving out free shirts!! https://t.co/jbAU3XNhWv",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/ObiWanWonodi/status/846797306901004289/photo/1",
      "source_status_id" : "846797306901004289",
      "indices" : [ "59", "82" ],
      "url" : "https://t.co/jbAU3XNhWv",
      "media_url" : "http://pbs.twimg.com/media/C8Btp0FXwAE7_V-.jpg",
      "id_str" : "846797295068889089",
      "source_user_id" : "243901756",
      "id" : "846797295068889089",
      "media_url_https" : "https://pbs.twimg.com/media/C8Btp0FXwAE7_V-.jpg",
      "source_user_id_str" : "243901756",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "680",
          "h" : "453",
          "resize" : "fit"
        },
        "medium" : {
          "w" : "960",
          "h" : "640",
          "resize" : "fit"
        },
        "large" : {
          "w" : "960",
          "h" : "640",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "source_status_id_str" : "846797306901004289",
      "display_url" : "pic.twitter.com/jbAU3XNhWv"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tami",
      "screen_name" : "tamiolaf",
      "indices" : [ "15", "24" ],
      "id_str" : "940506205",
      "id" : "940506205"
    } ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/846792050196594688/photo/1",
      "indices" : [ "81", "104" ],
      "url" : "https://t.co/eyfkQA1nJg",
      "media_url" : "http://pbs.twimg.com/media/C8Bo4MkWsAAXnA6.jpg",
      "id_str" : "846792044601323520",
      "id" : "846792044601323520",
      "media_url_https" : "https://pbs.twimg.com/media/C8Bo4MkWsAAXnA6.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "640",
          "resize" : "fit"
        },
        "large" : {
          "w" : "960",
          "h" : "640",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "453",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/eyfkQA1nJg"
    } ],
    "hashtags" : [ ]
  },
  "display_text_range" : [ "0", "104" ],
  "favorite_count" : "3",
  "id_str" : "846792050196594688",
  "truncated" : false,
  "retweet_count" : "3",
  "id" : "846792050196594688",
  "possibly_sensitive" : false,
  "created_at" : "Tue Mar 28 18:32:12 +0000 2017",
  "favorited" : false,
  "full_text" : "Go see founder @tamiolaf talk about being a student entrepreneur today in stamp! https://t.co/eyfkQA1nJg",
  "lang" : "en",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/846792050196594688/photo/1",
      "indices" : [ "81", "104" ],
      "url" : "https://t.co/eyfkQA1nJg",
      "media_url" : "http://pbs.twimg.com/media/C8Bo4MkWsAAXnA6.jpg",
      "id_str" : "846792044601323520",
      "id" : "846792044601323520",
      "media_url_https" : "https://pbs.twimg.com/media/C8Bo4MkWsAAXnA6.jpg",
      "sizes" : {
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "medium" : {
          "w" : "960",
          "h" : "640",
          "resize" : "fit"
        },
        "large" : {
          "w" : "960",
          "h" : "640",
          "resize" : "fit"
        },
        "small" : {
          "w" : "680",
          "h" : "453",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/eyfkQA1nJg"
    } ]
  }
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "urls" : [ ],
    "symbols" : [ ],
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/846784426365386755/photo/1",
      "indices" : [ "15", "38" ],
      "url" : "https://t.co/m2v3mHHsEY",
      "media_url" : "http://pbs.twimg.com/media/C8Bh75OVwAA53G1.jpg",
      "id_str" : "846784411546796032",
      "id" : "846784411546796032",
      "media_url_https" : "https://pbs.twimg.com/media/C8Bh75OVwAA53G1.jpg",
      "sizes" : {
        "medium" : {
          "w" : "400",
          "h" : "400",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "400",
          "h" : "400",
          "resize" : "fit"
        },
        "large" : {
          "w" : "400",
          "h" : "400",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/m2v3mHHsEY"
    } ],
    "hashtags" : [ {
      "text" : "NewProfilePic",
      "indices" : [ "0", "14" ]
    } ]
  },
  "display_text_range" : [ "0", "38" ],
  "favorite_count" : "2",
  "id_str" : "846784426365386755",
  "truncated" : false,
  "retweet_count" : "1",
  "id" : "846784426365386755",
  "possibly_sensitive" : false,
  "created_at" : "Tue Mar 28 18:01:54 +0000 2017",
  "favorited" : false,
  "full_text" : "#NewProfilePic https://t.co/m2v3mHHsEY",
  "lang" : "und",
  "extended_entities" : {
    "media" : [ {
      "expanded_url" : "https://twitter.com/SeeFoodCalendar/status/846784426365386755/photo/1",
      "indices" : [ "15", "38" ],
      "url" : "https://t.co/m2v3mHHsEY",
      "media_url" : "http://pbs.twimg.com/media/C8Bh75OVwAA53G1.jpg",
      "id_str" : "846784411546796032",
      "id" : "846784411546796032",
      "media_url_https" : "https://pbs.twimg.com/media/C8Bh75OVwAA53G1.jpg",
      "sizes" : {
        "medium" : {
          "w" : "400",
          "h" : "400",
          "resize" : "fit"
        },
        "thumb" : {
          "w" : "150",
          "h" : "150",
          "resize" : "crop"
        },
        "small" : {
          "w" : "400",
          "h" : "400",
          "resize" : "fit"
        },
        "large" : {
          "w" : "400",
          "h" : "400",
          "resize" : "fit"
        }
      },
      "type" : "photo",
      "display_url" : "pic.twitter.com/m2v3mHHsEY"
    } ]
  }
} ]