window.YTD.phone_number.part0 = [ {
  "device" : {
    "phoneNumber" : "+12022629943"
  }
} ]