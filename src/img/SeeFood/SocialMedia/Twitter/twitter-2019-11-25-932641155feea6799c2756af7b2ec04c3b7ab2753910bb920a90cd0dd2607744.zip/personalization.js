window.YTD.personalization.part0 = [ {
  "p13nData" : {
    "demographics" : {
      "languages" : [ {
        "language" : "English",
        "isDisabled" : false
      } ],
      "genderInfo" : {
        "gender" : "male"
      }
    },
    "interests" : {
      "interests" : [ {
        "name" : "1989",
        "isDisabled" : false
      }, {
        "name" : "Aaron Donald",
        "isDisabled" : false
      }, {
        "name" : "Action and Adventure Films",
        "isDisabled" : false
      }, {
        "name" : "Alternative Music",
        "isDisabled" : false
      }, {
        "name" : "Andrew Gillum",
        "isDisabled" : false
      }, {
        "name" : "Andrew Wiggins",
        "isDisabled" : false
      }, {
        "name" : "Animals",
        "isDisabled" : false
      }, {
        "name" : "Animated Films",
        "isDisabled" : false
      }, {
        "name" : "Anthony Davis Jr.",
        "isDisabled" : false
      }, {
        "name" : "Ariana Grande",
        "isDisabled" : false
      }, {
        "name" : "Atlanta Falcons",
        "isDisabled" : false
      }, {
        "name" : "Basketball",
        "isDisabled" : false
      }, {
        "name" : "Beno Udrih",
        "isDisabled" : false
      }, {
        "name" : "Betsy DeVos",
        "isDisabled" : false
      }, {
        "name" : "Big Sean",
        "isDisabled" : false
      }, {
        "name" : "Brian Krassenstein",
        "isDisabled" : false
      }, {
        "name" : "CNN",
        "isDisabled" : false
      }, {
        "name" : "Celebrity",
        "isDisabled" : false
      }, {
        "name" : "Chadwick Boseman",
        "isDisabled" : false
      }, {
        "name" : "Charlotte Hornets",
        "isDisabled" : false
      }, {
        "name" : "Comedy",
        "isDisabled" : false
      }, {
        "name" : "Conor McGregor",
        "isDisabled" : false
      }, {
        "name" : "Demi Lovato",
        "isDisabled" : false
      }, {
        "name" : "Digital Creators & Channels",
        "isDisabled" : false
      }, {
        "name" : "Dogs",
        "isDisabled" : false
      }, {
        "name" : "Drake",
        "isDisabled" : false
      }, {
        "name" : "EAST",
        "isDisabled" : false
      }, {
        "name" : "Education System in the United States",
        "isDisabled" : false
      }, {
        "name" : "Education around the world",
        "isDisabled" : false
      }, {
        "name" : "England - Soccer",
        "isDisabled" : false
      }, {
        "name" : "Europe - Soccer",
        "isDisabled" : false
      }, {
        "name" : "Fashion",
        "isDisabled" : false
      }, {
        "name" : "Fitness & Wellness",
        "isDisabled" : false
      }, {
        "name" : "Floyd Mayweather",
        "isDisabled" : false
      }, {
        "name" : "Food",
        "isDisabled" : false
      }, {
        "name" : "Football (US)",
        "isDisabled" : false
      }, {
        "name" : "Fruit of the Loom",
        "isDisabled" : false
      }, {
        "name" : "Google ",
        "isDisabled" : false
      }, {
        "name" : "Gov Officials & Agencies",
        "isDisabled" : false
      }, {
        "name" : "Hello",
        "isDisabled" : false
      }, {
        "name" : "Hip-Hop and Rap",
        "isDisabled" : false
      }, {
        "name" : "Hip-Hop/Rap",
        "isDisabled" : false
      }, {
        "name" : "Holidays",
        "isDisabled" : false
      }, {
        "name" : "Horror Films",
        "isDisabled" : false
      }, {
        "name" : "Hulu",
        "isDisabled" : false
      }, {
        "name" : "I-A",
        "isDisabled" : false
      }, {
        "name" : "Industry News",
        "isDisabled" : false
      }, {
        "name" : "Instagram",
        "isDisabled" : false
      }, {
        "name" : "J. Cole",
        "isDisabled" : false
      }, {
        "name" : "Jarrett Stidham",
        "isDisabled" : false
      }, {
        "name" : "Jonah Bolden",
        "isDisabled" : false
      }, {
        "name" : "Jussie Smollett",
        "isDisabled" : false
      }, {
        "name" : "Justin Bieber",
        "isDisabled" : false
      }, {
        "name" : "Kanye West",
        "isDisabled" : false
      }, {
        "name" : "Kelvin Benjamin",
        "isDisabled" : false
      }, {
        "name" : "LeBron James",
        "isDisabled" : false
      }, {
        "name" : "MMA",
        "isDisabled" : false
      }, {
        "name" : "Meek Mill",
        "isDisabled" : false
      }, {
        "name" : "Michelle Obama",
        "isDisabled" : false
      }, {
        "name" : "Migos",
        "isDisabled" : false
      }, {
        "name" : "Movies",
        "isDisabled" : false
      }, {
        "name" : "Music",
        "isDisabled" : false
      }, {
        "name" : "Music festivals and concerts",
        "isDisabled" : false
      }, {
        "name" : "Musicians",
        "isDisabled" : false
      }, {
        "name" : "NBA",
        "isDisabled" : false
      }, {
        "name" : "NBA",
        "isDisabled" : false
      }, {
        "name" : "NBA Basketball",
        "isDisabled" : false
      }, {
        "name" : "NCAA Football",
        "isDisabled" : false
      }, {
        "name" : "NCAA Women's Basketball",
        "isDisabled" : false
      }, {
        "name" : "NFL",
        "isDisabled" : false
      }, {
        "name" : "NFL",
        "isDisabled" : false
      }, {
        "name" : "Netflix",
        "isDisabled" : false
      }, {
        "name" : "Oprah",
        "isDisabled" : false
      }, {
        "name" : "Paul George",
        "isDisabled" : false
      }, {
        "name" : "PewDiePie",
        "isDisabled" : false
      }, {
        "name" : "Philadelphia Eagles",
        "isDisabled" : false
      }, {
        "name" : "Pop",
        "isDisabled" : false
      }, {
        "name" : "Pop",
        "isDisabled" : false
      }, {
        "name" : "Pop Culture",
        "isDisabled" : false
      }, {
        "name" : "Professional Wrestling",
        "isDisabled" : false
      }, {
        "name" : "Quavo",
        "isDisabled" : false
      }, {
        "name" : "R&B and Soul",
        "isDisabled" : false
      }, {
        "name" : "R&B/Soul",
        "isDisabled" : false
      }, {
        "name" : "Reggie Nelson",
        "isDisabled" : false
      }, {
        "name" : "Rihanna",
        "isDisabled" : false
      }, {
        "name" : "SAP",
        "isDisabled" : false
      }, {
        "name" : "SEC",
        "isDisabled" : false
      }, {
        "name" : "Sasha Banks",
        "isDisabled" : false
      }, {
        "name" : "Science",
        "isDisabled" : false
      }, {
        "name" : "Science news",
        "isDisabled" : false
      }, {
        "name" : "Seth Roberts",
        "isDisabled" : false
      }, {
        "name" : "Soccer",
        "isDisabled" : false
      }, {
        "name" : "Space and astronomy",
        "isDisabled" : false
      }, {
        "name" : "Taylor Swift",
        "isDisabled" : false
      }, {
        "name" : "Television",
        "isDisabled" : false
      }, {
        "name" : "Terry Crews",
        "isDisabled" : false
      }, {
        "name" : "Tinashe",
        "isDisabled" : false
      }, {
        "name" : "Travel",
        "isDisabled" : false
      }, {
        "name" : "Trending",
        "isDisabled" : false
      }, {
        "name" : "Twitter",
        "isDisabled" : false
      }, {
        "name" : "UFC",
        "isDisabled" : false
      }, {
        "name" : "US News",
        "isDisabled" : false
      }, {
        "name" : "Uber",
        "isDisabled" : false
      }, {
        "name" : "United States Cabinet",
        "isDisabled" : false
      }, {
        "name" : "WEST",
        "isDisabled" : false
      }, {
        "name" : "WWE",
        "isDisabled" : false
      }, {
        "name" : "WWE",
        "isDisabled" : false
      }, {
        "name" : "Walmart",
        "isDisabled" : false
      }, {
        "name" : "Weather",
        "isDisabled" : false
      }, {
        "name" : "Ye (Kanye West)",
        "isDisabled" : false
      } ],
      "partnerInterests" : [ {
        "name" : "Auto > Auto service buyer"
      }, {
        "name" : "Auto > Body style: entry/economy/compact"
      }, {
        "name" : "Auto > Body style: luxury sedan"
      }, {
        "name" : "Auto > Body style: midsize car"
      }, {
        "name" : "Auto > Body style: small/mid-size SUV"
      }, {
        "name" : "Auto > Body style: sports car/convertible"
      }, {
        "name" : "Auto > In market: new or used vehicle"
      }, {
        "name" : "Auto > In market: new vehicle"
      }, {
        "name" : "Auto > Make: Honda"
      }, {
        "name" : "Auto > Max in market: all body styles"
      }, {
        "name" : "Auto > Max in market: body style: crossover vehicle"
      }, {
        "name" : "Auto > Max in market: body style: entry/economy/compact"
      }, {
        "name" : "Auto > Max in market: body style: hybrid/alternative fuel"
      }, {
        "name" : "Auto > Max in market: body style: midsize car"
      }, {
        "name" : "Auto > Max in market: body style: minivan"
      }, {
        "name" : "Auto > Near market: body style: full-size SUV"
      }, {
        "name" : "Auto > Near market: body style: minivan"
      }, {
        "name" : "Auto > Owners: body style: full-size sedan"
      }, {
        "name" : "Auto > Owners: body style: midsize car"
      }, {
        "name" : "Auto > Owners: make: Honda"
      }, {
        "name" : "Auto > Used: body style: crossover vehicle"
      }, {
        "name" : "Auto > Used: body style: hybrid/alternative fuel"
      }, {
        "name" : "Auto > Used: body style: luxury SUV"
      }, {
        "name" : "Auto > Used: body style: small/mid-size SUV"
      }, {
        "name" : "Auto > Used: make: Honda"
      }, {
        "name" : "Auto > Vehicle price: $20k or under"
      }, {
        "name" : "Auto > Vehicle purchase: 13-24 months ago"
      }, {
        "name" : "CPG categories > Bakery buyers"
      }, {
        "name" : "CPG categories > Baking"
      }, {
        "name" : "CPG categories > Baking & cooking supplies buyers"
      }, {
        "name" : "CPG categories > Cereal buyers"
      }, {
        "name" : "CPG categories > Cheese"
      }, {
        "name" : "CPG categories > Children's cereals"
      }, {
        "name" : "CPG categories > Children's food"
      }, {
        "name" : "CPG categories > Children's food & product buyers"
      }, {
        "name" : "CPG categories > Chocolate candy"
      }, {
        "name" : "CPG categories > Cookies"
      }, {
        "name" : "CPG categories > Crackers"
      }, {
        "name" : "CPG categories > Dairy & egg buyers"
      }, {
        "name" : "CPG categories > Eggs"
      }, {
        "name" : "CPG categories > Fresh produce"
      }, {
        "name" : "CPG categories > Granola bars"
      }, {
        "name" : "CPG categories > Health food buyers"
      }, {
        "name" : "CPG categories > Hot cereals"
      }, {
        "name" : "CPG categories > Meat"
      }, {
        "name" : "CPG categories > Meat & seafood buyers"
      }, {
        "name" : "CPG categories > Milk"
      }, {
        "name" : "CPG categories > Non-chocolate candy"
      }, {
        "name" : "CPG categories > Peanut butter & jelly"
      }, {
        "name" : "CPG categories > Salty snacks"
      }, {
        "name" : "CPG categories > Soup buyers"
      }, {
        "name" : "CPG categories > Spices & extracts"
      }, {
        "name" : "CPG categories > Yogurt"
      }, {
        "name" : "Demographics > Affluent baby boomers"
      }, {
        "name" : "Demographics > Big city moms"
      }, {
        "name" : "Demographics > Children ages: 11-15"
      }, {
        "name" : "Demographics > Children ages: 16-17"
      }, {
        "name" : "Demographics > Family member age: 40-49"
      }, {
        "name" : "Demographics > Generation X'ers"
      }, {
        "name" : "Demographics > Male HOH"
      }, {
        "name" : "Demographics > Moms of grade school kids"
      }, {
        "name" : "Demographics > Number of children: 2"
      }, {
        "name" : "Demographics > Presence in household: yes"
      }, {
        "name" : "Demographics > Soccer moms"
      }, {
        "name" : "Finance > Banking"
      }, {
        "name" : "Finance > Credit active"
      }, {
        "name" : "Finance > Excellent"
      }, {
        "name" : "Finance > Financial services"
      }, {
        "name" : "Finance > Home value: $500,000 and higher"
      }, {
        "name" : "Finance > Household income: $200,000 - $249,999"
      }, {
        "name" : "Household > Home owner"
      }, {
        "name" : "Household > Single family"
      }, {
        "name" : "Lifestyles > Auto enthusiasts"
      }, {
        "name" : "Lifestyles > DIYers"
      }, {
        "name" : "Lifestyles > Online buyers"
      }, {
        "name" : "Lifestyles > Sports fans"
      }, {
        "name" : "Proximity > 7 Eleven"
      }, {
        "name" : "Proximity > Ahold: Giant"
      }, {
        "name" : "Proximity > Ahold: all banners"
      }, {
        "name" : "Proximity > CVS"
      }, {
        "name" : "Proximity > Circle K"
      }, {
        "name" : "Proximity > Costco"
      }, {
        "name" : "Proximity > Dollar General"
      }, {
        "name" : "Proximity > Food Lion"
      }, {
        "name" : "Proximity > Rite Aid"
      }, {
        "name" : "Proximity > Safeway"
      }, {
        "name" : "Proximity > Safeway: all banners"
      }, {
        "name" : "Proximity > Supervalu: Save-A-Lot"
      }, {
        "name" : "Proximity > Supervalu: all banners"
      }, {
        "name" : "Proximity > Walgreens"
      }, {
        "name" : "Proximity > Walmart"
      }, {
        "name" : "Retail brands > Nikon"
      }, {
        "name" : "Retail brands > Samsung"
      }, {
        "name" : "Retail categories > Automotive products buyers"
      }, {
        "name" : "Seasonal > Big bakers"
      }, {
        "name" : "Seasonal > Graduation gift buyers"
      }, {
        "name" : "Seasonal > Kids lunchbox packers"
      }, {
        "name" : "Seasonal > Mother's Day shoppers"
      }, {
        "name" : "Seasonal > Valentine's Day shoppers"
      }, {
        "name" : "Subscription services > Mortgage"
      } ],
      "audienceAndAdvertisers" : {
        "numAudiences" : "133",
        "advertisers" : [ "@5hourenergy", "@ATT", "@BananaRepublic", "@BestBuy", "@ChipotleTweets", "@DIRECTV", "@EatLiquidGold", "@FoodLion", "@Ford", "@GUESS", "@Hallmark", "@INFINITIUSA", "@KayJewelers", "@KraftSingles", "@LandRoverUSA", "@MazdaUSA", "@MrPeanut", "@NissanUSA", "@ODC_Ads_Testing", "@RealLunchables", "@Starbucks", "@belk", "@devourfoods", "@kraftcheese", "@oscarmayer", "@redbull", "@ro_tel", "@verizonfios" ]
      },
      "shows" : [ "2017 March Madness Tournament", "2018 Winter Olympics", "A Wrinkle in Time", "AFC Bournemouth vs. Chelsea FC", "Academy Awards 2018", "Barclays Premier League Football", "Barclays Premier League Soccer", "Black Panther", "College Basketball", "English Premier League Soccer", "Futebol NFL", "Fútbol Americano de la NFL", "Game of Thrones", "Get Out", "Grey's Anatomy", "I Feel Pretty", "IndyCar Racing", "Jeopardy!", "La reine des neiges", "Liga BBVA", "Live Winter Olympic Games", "Live: NBA Basketball", "Live: NFL Football", "MLB Baseball", "MLS Soccer", "Malcolm", "Malcolm in the Middle", "NBA Basketball", "NFL Football", "NFLスーパーボウル", "New Year's 2018", "Parks and Recreation", "Rick and Morty", "Scrubs", "Sesame Street", "The Bachelor", "The Four: Battle for Stardom", "The Fresh Prince of Bel-Air", "The Get Down (Netflix)", "The Incredibles 2", "The Last O.G.", "The Oscars", "The Voice : la plus belle voix", "UEFA Champions League Football", "UEFAチャンピオンズリーグ", "WNBA Basketball", "WWE Monday Night RAW", "WWE SmackDown!", "Westworld", "Women's College Basketball", "Young & Hungry", "ピョンチャンオリンピック2018" ]
    },
    "locationHistory" : [ "Washington, DC, USA" ],
    "inferredAgeInfo" : {
      "age" : [ "13-54" ],
      "birthDate" : ""
    }
  }
} ]