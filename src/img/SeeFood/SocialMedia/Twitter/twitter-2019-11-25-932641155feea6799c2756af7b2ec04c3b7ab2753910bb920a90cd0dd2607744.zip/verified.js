window.YTD.verified.part0 = [ {
  "verified" : {
    "accountId" : "800904115924717569",
    "verified" : false
  }
} ]