window.YTD.ni_devices.part0 = [ {
  "niDeviceResponse" : {
    "pushDevice" : {
      "deviceVersion" : "8.0.6",
      "deviceType" : "Twitter for iOS",
      "token" : "1h3eyAyVChM9Qt1v6Bkz7Mx7XSEKwto1MvdyXKZSefY=",
      "updatedDate" : "2019.11.23",
      "createdDate" : "2018.04.23"
    }
  }
}, {
  "niDeviceResponse" : {
    "messagingDevice" : {
      "phoneNumber" : "+12022629943",
      "carrier" : "att",
      "deviceType" : "Auth",
      "updatedDate" : "2017.06.20",
      "createdDate" : "2016.11.22"
    }
  }
} ]