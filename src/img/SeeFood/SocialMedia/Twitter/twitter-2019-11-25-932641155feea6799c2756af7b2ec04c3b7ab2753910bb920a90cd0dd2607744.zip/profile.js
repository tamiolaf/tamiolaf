window.YTD.profile.part0 = [ {
  "profile" : {
    "description" : {
      "bio" : "The Campus Free Food Event Calendar. Here to give #UMD students more options than the diner lmao",
      "website" : "https://t.co/Yd9rbl2mkC",
      "location" : "College Park, MD"
    },
    "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/846784343641083907/8QbD74xB.jpg",
    "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/800904115924717569/1490723908"
  }
} ]