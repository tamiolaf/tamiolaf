window.YTD.direct_message.part0 = [ {
  "dmConversation" : {
    "conversationId" : "121624602-800904115924717569",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "jamesamarrow uses TrueTwit validation. To validate click here: https://t.co/GcnyRqDP2a",
        "mediaUrls" : [ ],
        "senderId" : "121624602",
        "id" : "913332795371597828",
        "createdAt" : "2017-09-28T09:21:22.052Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "293767239-800904115924717569",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "293767239",
        "text" : "We're happy that it's helping your club!",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "991397008878514187",
        "createdAt" : "2018-05-01T19:20:40.885Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "293767239",
        "text" : "THANKSSS",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "991396958723076100",
        "createdAt" : "2018-05-01T19:20:28.923Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "thought*",
        "mediaUrls" : [ ],
        "senderId" : "293767239",
        "id" : "991371720576598023",
        "createdAt" : "2018-05-01T17:40:11.719Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "though you guys might like seeing this feedback",
        "mediaUrls" : [ ],
        "senderId" : "293767239",
        "id" : "991371705108123652",
        "createdAt" : "2018-05-01T17:40:08.015Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : " https://t.co/25gJ4CV1y9",
        "mediaUrls" : [ "https://ton.twitter.com/dm/991371663014006789/991371655329996800/9lBWLSRX.jpg" ],
        "senderId" : "293767239",
        "id" : "991371663014006789",
        "createdAt" : "2018-05-01T17:39:58.507Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "800904115924717569-800904115924717569",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "Thanks for sending this!",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "853738810592636932",
        "createdAt" : "2017-04-16T22:36:08.837Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/8gQrQDXY4i",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "852988293977395204",
        "createdAt" : "2017-04-14T20:53:51.753Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "340045272-800904115924717569",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "340045272",
        "text" : "Hey man, If you like the events you see on my account it would be great if you gave me a shoutout or retweeted some stuff",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "902936286562058243",
        "createdAt" : "2017-08-30T16:49:21.183Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "560626672-800904115924717569",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "This is such a good idea! I go to Providence College and we would definatly benefit from this. If you’re ever looking to expand let me know!",
        "mediaUrls" : [ ],
        "senderId" : "560626672",
        "id" : "973621215293263876",
        "createdAt" : "2018-03-13T18:06:01.497Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "800663185-800904115924717569",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "Please Follow my Facebook page FOR MORE: https://t.co/sHKwHQ5SPV \n\n#DefendDACA RESIST! ✊\uD83C\uDFFD -via @crowdfire",
        "mediaUrls" : [ ],
        "senderId" : "800663185",
        "id" : "909936888106160133",
        "createdAt" : "2017-09-19T00:27:14.680Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "940506205-800904115924717569",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/gS6uXunCr5",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "1042180180029173764",
        "createdAt" : "2018-09-18T22:34:52.423Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/o9v1GXNPWQ",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "1040836818479001605",
        "createdAt" : "2018-09-15T05:36:50.068Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "940506205",
        "text" : "https://t.co/QYaJrVyFbG",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "995673224577998852",
        "createdAt" : "2018-05-13T14:32:50.177Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/k9BBn41wvI",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "987322997001412612",
        "createdAt" : "2018-04-20T13:32:00.799Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/0vWDxEApf3",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "987313666117775364",
        "createdAt" : "2018-04-20T12:54:56.142Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/LKA3ypvR21",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "985886563547729928",
        "createdAt" : "2018-04-16T14:24:08.381Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/28mVPjH82m",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "975076725423042565",
        "createdAt" : "2018-03-17T18:29:42.149Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "940506205",
        "text" : "https://t.co/pVzE8s4Rja",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "968958327320469508",
        "createdAt" : "2018-02-28T21:17:22.420Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/JjUFHD4EFh",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "968551031637528581",
        "createdAt" : "2018-02-27T18:18:55.496Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "940506205",
        "text" : "https://t.co/8UYRmHS3dX",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "935050035942871044",
        "createdAt" : "2017-11-27T07:37:55.719Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/NxOSxlTogU",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "929080380103196676",
        "createdAt" : "2017-11-10T20:16:38.920Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/4H3TDfZ2LS",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "924008025140195333",
        "createdAt" : "2017-10-27T20:20:55.180Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "940506205",
        "text" : "https://t.co/j4QkzgGKhA",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "923961640835604486",
        "createdAt" : "2017-10-27T17:16:36.320Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/kpedFPzi8U",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "923181813220167685",
        "createdAt" : "2017-10-25T13:37:50.899Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/IxU4TvpgVq",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "921410659618820101",
        "createdAt" : "2017-10-20T16:19:55.182Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/lZz0HnzYQF",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "921231633964941316",
        "createdAt" : "2017-10-20T04:28:31.940Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/eH2c88okbr",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "921030258320605189",
        "createdAt" : "2017-10-19T15:08:20.243Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "940506205",
        "text" : "https://t.co/k306u4kNfV",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "916641201838796804",
        "createdAt" : "2017-10-07T12:27:47.636Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/YSKoZD7pWY",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "915952433486073860",
        "createdAt" : "2017-10-05T14:50:52.465Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/PgnC1MWDxp",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "915575290771976202",
        "createdAt" : "2017-10-04T13:52:14.633Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/ymyR6DdXKm",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "913149772852285444",
        "createdAt" : "2017-09-27T21:14:06.102Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/gQGXUtMJP0",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "912378008064978948",
        "createdAt" : "2017-09-25T18:07:23.054Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "940506205",
        "text" : "https://t.co/8xCqfQ6nIF",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "909577890370637828",
        "createdAt" : "2017-09-18T00:40:42.986Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "940506205",
        "text" : "https://t.co/N0OuuFqr1d",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "908349892136972292",
        "createdAt" : "2017-09-14T15:21:05.362Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/RvR9YWm62e",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "908050937679417348",
        "createdAt" : "2017-09-13T19:33:09.086Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/6Q43Rhl2Sh",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "908012501023031300",
        "createdAt" : "2017-09-13T17:00:25.082Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/dQYvkivmQE",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "907662954539180037",
        "createdAt" : "2017-09-12T17:51:26.672Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "940506205",
        "text" : "https://t.co/CPtghM12hm",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "905771206112141315",
        "createdAt" : "2017-09-07T12:34:18.729Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "940506205",
        "text" : "https://t.co/cKFzJP7GsE",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "902915817859424260",
        "createdAt" : "2017-08-30T15:28:01.443Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "940506205",
        "text" : "https://t.co/mu4HwkjvU5",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "860306328723607555",
        "createdAt" : "2017-05-05T01:33:07.216Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/WeP50lZwls",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "854726268742488067",
        "createdAt" : "2017-04-19T15:59:57.255Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/PMX0vKFDHe",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "853738616169824259",
        "createdAt" : "2017-04-16T22:35:22.631Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/MTtoIUBrrY",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "850142298079997955",
        "createdAt" : "2017-04-07T00:24:53.454Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/4d8PKTEkxl",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "849459393733308420",
        "createdAt" : "2017-04-05T03:11:16.562Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "https://t.co/yCC8tyd2vO",
        "mediaUrls" : [ ],
        "senderId" : "940506205",
        "id" : "846795949292867587",
        "createdAt" : "2017-03-28T18:47:41.755Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "3138495371-800904115924717569",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "3138495371",
        "text" : "We'll tag you in the post",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "923217285732536324",
        "createdAt" : "2017-10-25T15:58:48.281Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "3138495371",
        "text" : "Got it!",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "923216725398769668",
        "createdAt" : "2017-10-25T15:56:34.589Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "3138495371",
        "text" : "Hey! Thanks so much for sending this we'll definitely post it! Does your club have any social media?",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "923205497456660485",
        "createdAt" : "2017-10-25T15:11:57.648Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "3153738004-800904115924717569",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "I'm in!  thanks",
        "mediaUrls" : [ ],
        "senderId" : "3153738004",
        "id" : "930836150218121221",
        "createdAt" : "2017-11-15T16:33:27.018Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "3153738004",
        "text" : "Hey we tried with your email but it didn't work. Wanna give us your number instead?",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "930833267540086789",
        "createdAt" : "2017-11-15T16:21:59.746Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "tbo_1497@yahoo.com",
        "mediaUrls" : [ ],
        "senderId" : "3153738004",
        "id" : "930623468411944964",
        "createdAt" : "2017-11-15T02:28:19.724Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "3153738004",
        "text" : "What’s your group me info?",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "930622823294521348",
        "createdAt" : "2017-11-15T02:25:45.906Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "3153738004",
        "text" : "Yes absolutely.",
        "mediaUrls" : [ ],
        "senderId" : "800904115924717569",
        "id" : "930622781288538117",
        "createdAt" : "2017-11-15T02:25:35.906Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "800904115924717569",
        "text" : "can I get added to the groupme!",
        "mediaUrls" : [ ],
        "senderId" : "3153738004",
        "id" : "930620504251228166",
        "createdAt" : "2017-11-15T02:16:33.022Z"
      }
    } ]
  }
} ]