window.YTD.account_timezone.part0 = [ {
  "accountTimezone" : {
    "accountId" : "800904115924717569"
  }
} ]