window.YTD.account.part0 = [ {
  "account" : {
    "phoneNumber" : "+12022629943",
    "email" : "hello@seefoodcalendar.com",
    "createdVia" : "oauth:268278",
    "username" : "SeeFoodCalendar",
    "accountId" : "800904115924717569",
    "createdAt" : "2016-11-22T03:29:56.125Z",
    "accountDisplayName" : "See Food"
  }
} ]