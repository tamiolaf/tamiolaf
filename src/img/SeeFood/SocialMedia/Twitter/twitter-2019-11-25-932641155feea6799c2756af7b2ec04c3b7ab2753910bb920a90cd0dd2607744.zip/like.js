window.YTD.like.part0 = [ {
  "like" : {
    "tweetId" : "1090966312090783745",
    "fullText" : "i’m a firm believer in its never too cold for iced cold but today? today is way too cold for iced coffee",
    "expandedUrl" : "https://twitter.com/i/web/status/1090966312090783745"
  }
}, {
  "like" : {
    "tweetId" : "968649928124878853",
    "fullText" : "We are here at @MarylandMANE’s My Black is Beautiful event! \uD83D\uDE04\uD83D\uDE04 https://t.co/HXEZQwsjGX",
    "expandedUrl" : "https://twitter.com/i/web/status/968649928124878853"
  }
}, {
  "like" : {
    "tweetId" : "918206358750670848",
    "fullText" : "i’ve been craving platters for like the past month \uD83D\uDE43\uD83D\uDE43",
    "expandedUrl" : "https://twitter.com/i/web/status/918206358750670848"
  }
}, {
  "like" : {
    "tweetId" : "996051548064149505",
    "fullText" : "Come grab some #UMDfinals fuel (a.k.a. FREE PIZZA) today at 1PM!: https://t.co/FwzUR8pXLu #STAMPStudyZone https://t.co/sT3dU6EzYW",
    "expandedUrl" : "https://twitter.com/i/web/status/996051548064149505"
  }
}, {
  "like" : {
    "tweetId" : "968544191524540416",
    "fullText" : "Today's the day! You know where to be at 6pm ✨ \n\nCome out as we learn about black representation in entertainment. Enjoy food, hair product samples, performances, and presentations from our cosponsors. https://t.co/9BR71AJdcu",
    "expandedUrl" : "https://twitter.com/i/web/status/968544191524540416"
  }
}, {
  "like" : {
    "tweetId" : "981332400067276800",
    "fullText" : "PREPARE YOURSELVES—for FREE BREAKFAST with @UMDTOCSL. All transfer &amp; off-campus #Terps are invited to stop by the Atrium between 7:30 and 10:30 AM tomorrow for muffins, coffee, and great company. https://t.co/T9VdABpJtt",
    "expandedUrl" : "https://twitter.com/i/web/status/981332400067276800"
  }
}, {
  "like" : {
    "tweetId" : "1090327124504989696",
    "fullText" : "Our Spring Transfer Student Welcome is coming up TOMORROW!! Join TOCSL and @UMDOMSE for activities, chats with current students, a resource fair, food, giveaways, and MORE‼️\uD83E\uDD17\uD83E\uDD17\n\nWednesday, January 30, 4:30-6:30pm \nAtrium, STAMP @thestampumd https://t.co/MNk60au9K9",
    "expandedUrl" : "https://twitter.com/i/web/status/1090327124504989696"
  }
}, {
  "like" : {
    "tweetId" : "1102633544596246530",
    "fullText" : "It is happening TOMORROW!! From 12-1pm on the 3rd floor of Hornbake Library! RSVP at https://t.co/dwHUKufiac @UMDCareerCenter https://t.co/p4iaYKoozB",
    "expandedUrl" : "https://twitter.com/i/web/status/1102633544596246530"
  }
}, {
  "like" : {
    "tweetId" : "919889322731540481",
    "fullText" : "Colin Kaepernick has filed a lawsuit against the NFL claiming some teams are not hiring him over his racial injustice protests. https://t.co/RtTlSeX05v",
    "expandedUrl" : "https://twitter.com/i/web/status/919889322731540481"
  }
}, {
  "like" : {
    "tweetId" : "1090717091488022543",
    "fullText" : "FREE ice cream and cake is going on RIGHT NOW by @UMDDAIRY! \n\uD83C\uDF70\uD83C\uDF66\uD83C\uDFC0\uD83D\uDC22 https://t.co/ZTluS9Ctmy",
    "expandedUrl" : "https://twitter.com/i/web/status/1090717091488022543"
  }
}, {
  "like" : {
    "tweetId" : "1090805390634295298",
    "fullText" : "Why diversity in tech (and marketing, and product, etc) matters https://t.co/JNrqTYWbTL",
    "expandedUrl" : "https://twitter.com/i/web/status/1090805390634295298"
  }
}, {
  "like" : {
    "tweetId" : "1090854488787877888",
    "fullText" : "I’m confused is it really 7 degrees Fahrenheit outside or did I somehow switch to Celsius without knowing",
    "expandedUrl" : "https://twitter.com/i/web/status/1090854488787877888"
  }
}, {
  "like" : {
    "tweetId" : "1090663595942309890",
    "fullText" : "Come celebrate Coach Brenda Frese's 500 wins\uD83C\uDFC0, TODAY with cake\uD83C\uDF70 and Brenda's Peanut Butter Frese Ice Cream\uD83C\uDF66!! Stop by Maryland Dairy in The Stamp Student Union at 4pm!! You don't want to miss out!!\uD83D\uDE0B #umd #basketball #coach #icecream #cake #mddairy #celebrations #500wins https://t.co/Rit6DzFSTu",
    "expandedUrl" : "https://twitter.com/i/web/status/1090663595942309890"
  }
}, {
  "like" : {
    "tweetId" : "987010479989100546",
    "fullText" : "Deadline is April 22nd!! https://t.co/hXuqF41MOM https://t.co/039OFJccdi",
    "expandedUrl" : "https://twitter.com/i/web/status/987010479989100546"
  }
}, {
  "like" : {
    "tweetId" : "995993672075399168",
    "fullText" : "Head to the Prince George's Room for FREE breakfast this morning!: https://t.co/XkDD1nY9EB \uD83C\uDF7D #UMDfinals #STAMPStudyZone https://t.co/ZHcIsZGbfV",
    "expandedUrl" : "https://twitter.com/i/web/status/995993672075399168"
  }
}, {
  "like" : {
    "tweetId" : "1090694384536961025",
    "fullText" : "Can't wait to celebrate with @BrendaFrese, @umdwbb, and @UMDDAIRY today~! All are welcome to join! \uD83C\uDF70\uD83C\uDF66\uD83C\uDFC0\uD83D\uDC22 https://t.co/mC0fGnaR6b",
    "expandedUrl" : "https://twitter.com/i/web/status/1090694384536961025"
  }
}, {
  "like" : {
    "tweetId" : "1090996123089555457",
    "fullText" : "Knowing how to code is really just knowing how to expertly google lol",
    "expandedUrl" : "https://twitter.com/i/web/status/1090996123089555457"
  }
}, {
  "like" : {
    "tweetId" : "915995335373332481",
    "fullText" : "There's free food in the grand ballroom lounge from  5-7 @THESTAMPUMD",
    "expandedUrl" : "https://twitter.com/i/web/status/915995335373332481"
  }
}, {
  "like" : {
    "tweetId" : "968498101077016576",
    "fullText" : "Happy Birthday to our secretary! \n\uD83C\uDDF9\uD83C\uDDF9\uD83C\uDDE7\uD83C\uDDE7 https://t.co/o3egT8pMj9",
    "expandedUrl" : "https://twitter.com/i/web/status/968498101077016576"
  }
}, {
  "like" : {
    "tweetId" : "967096063407640577",
    "fullText" : "I’m putting my daughters in figure skating",
    "expandedUrl" : "https://twitter.com/i/web/status/967096063407640577"
  }
}, {
  "like" : {
    "tweetId" : "920816647753097216",
    "fullText" : "i need a child by tomorrow https://t.co/P76pWprP2k",
    "expandedUrl" : "https://twitter.com/i/web/status/920816647753097216"
  }
}, {
  "like" : {
    "tweetId" : "916412095167688710",
    "fullText" : "\uD83D\uDDE3️\uD83D\uDDE3️THE REASON UMD WILL ALWAYS HAVE PROBLEMS IS BC THERE ARE 4(!!) SUBWAYS LESS THAN A MILE FROM THE HEART OF CAMPUS AND STILL NO POPEYES!",
    "expandedUrl" : "https://twitter.com/i/web/status/916412095167688710"
  }
}, {
  "like" : {
    "tweetId" : "1093117766117265409",
    "fullText" : "The early #Terp gets the coffee! ☕️ @UMDTOCSL’s Good Morning, Commuters starts in just half an hour! \uD83C\uDF4E\uD83C\uDF4C\uD83E\uDD6F\uD83D\uDE0B https://t.co/T9e5A6JO4f",
    "expandedUrl" : "https://twitter.com/i/web/status/1093117766117265409"
  }
}, {
  "like" : {
    "tweetId" : "996441329931517952",
    "fullText" : "It's a scientific fact that it's IMPOSSIBLE to be stressed about #UMDfinals while enjoying s'mores! \uD83D\uDD25\uD83C\uDF6B\uD83D\uDE0B https://t.co/4T5C5NCmpf #STAMPStudyZone https://t.co/egcBYvHoON",
    "expandedUrl" : "https://twitter.com/i/web/status/996441329931517952"
  }
}, {
  "like" : {
    "tweetId" : "983812434526900224",
    "fullText" : "The final performance of It/That Happened is TOMORROW at 6PM in he Atrium. Come out to see this provocative, emotional, funny collection of performances, created by a diverse team of #Terps. (And there will be FOOD!) RSVP at https://t.co/JtqEtvzD3y https://t.co/FF9Rmrf1e4",
    "expandedUrl" : "https://twitter.com/i/web/status/983812434526900224"
  }
}, {
  "like" : {
    "tweetId" : "901524027776389121",
    "fullText" : "Make sure to check out our table at #FreshCon2017 going on now!!!\uD83D\uDC9C\uD83D\uDC9C https://t.co/uGw0otWBa9",
    "expandedUrl" : "https://twitter.com/i/web/status/901524027776389121"
  }
}, {
  "like" : {
    "tweetId" : "905175886848303104",
    "fullText" : "GOOD https://t.co/zt41jp8zqB",
    "expandedUrl" : "https://twitter.com/i/web/status/905175886848303104"
  }
}, {
  "like" : {
    "tweetId" : "905188537359888384",
    "fullText" : "@SeeFoodCalendar Moved indoors cause of weather\uD83D\uDC40",
    "expandedUrl" : "https://twitter.com/i/web/status/905188537359888384"
  }
}, {
  "like" : {
    "tweetId" : "901515324885004288",
    "fullText" : "Come throughhhh #UMD21 #FreshCon2017 https://t.co/OQNeimO3dd",
    "expandedUrl" : "https://twitter.com/i/web/status/901515324885004288"
  }
}, {
  "like" : {
    "tweetId" : "901546013944680448",
    "fullText" : "I feel like every black person here is super successful #goals #FreshCon2017",
    "expandedUrl" : "https://twitter.com/i/web/status/901546013944680448"
  }
}, {
  "like" : {
    "tweetId" : "902562481410887680",
    "fullText" : "Africans should get reparations from European nations while African Americans should get reparations from America",
    "expandedUrl" : "https://twitter.com/i/web/status/902562481410887680"
  }
}, {
  "like" : {
    "tweetId" : "901566340745625600",
    "fullText" : "#FreshCon2017 THE DELTAS ARE GOING AWF!",
    "expandedUrl" : "https://twitter.com/i/web/status/901566340745625600"
  }
}, {
  "like" : {
    "tweetId" : "860297375973244929",
    "fullText" : "Rainy nights and Netflix go together like peanut butter and jelly",
    "expandedUrl" : "https://twitter.com/i/web/status/860297375973244929"
  }
}, {
  "like" : {
    "tweetId" : "854587613511950336",
    "fullText" : "I spent 5min making it so it's fine tbh https://t.co/wKnCW1tH4Q",
    "expandedUrl" : "https://twitter.com/i/web/status/854587613511950336"
  }
}, {
  "like" : {
    "tweetId" : "902577724312694785",
    "fullText" : "Respect my privacy https://t.co/StaqgxSgaj",
    "expandedUrl" : "https://twitter.com/i/web/status/902577724312694785"
  }
}, {
  "like" : {
    "tweetId" : "902147807586504704",
    "fullText" : "Got up at 8:30 am and my first class doesn't start until 4 pm \uD83D\uDE42",
    "expandedUrl" : "https://twitter.com/i/web/status/902147807586504704"
  }
}, {
  "like" : {
    "tweetId" : "902930408509247489",
    "fullText" : "Grab a friend and get some pizza \uD83D\uDE0B https://t.co/fkzAa9I8ob",
    "expandedUrl" : "https://twitter.com/i/web/status/902930408509247489"
  }
}, {
  "like" : {
    "tweetId" : "901549440783265792",
    "fullText" : "Thanks magic https://t.co/vxf9GGtnG4",
    "expandedUrl" : "https://twitter.com/i/web/status/901549440783265792"
  }
}, {
  "like" : {
    "tweetId" : "901538956554240000",
    "fullText" : "We're here \uD83D\uDC22‼️ #Freshcon2017 #BlackUMD #BlackTerpRoyalty https://t.co/9ltEIOabAL",
    "expandedUrl" : "https://twitter.com/i/web/status/901538956554240000"
  }
}, {
  "like" : {
    "tweetId" : "902142610810208257",
    "fullText" : "I'm really a senior now wow",
    "expandedUrl" : "https://twitter.com/i/web/status/902142610810208257"
  }
}, {
  "like" : {
    "tweetId" : "902379727314411520",
    "fullText" : "@SeeFoodCalendar This is what I like to hear \uD83D\uDE0E",
    "expandedUrl" : "https://twitter.com/i/web/status/902379727314411520"
  }
}, {
  "like" : {
    "tweetId" : "902708921739116545",
    "fullText" : "@SeeFoodCalendar @AldiUSA Agreed, I \uD83C\uDF0A",
    "expandedUrl" : "https://twitter.com/i/web/status/902708921739116545"
  }
}, {
  "like" : {
    "tweetId" : "911935874711085057",
    "fullText" : "I'm an Asian-American doctor and today I #TakeTheKnee to fight white supremacy. https://t.co/69QLjrTShY",
    "expandedUrl" : "https://twitter.com/i/web/status/911935874711085057"
  }
}, {
  "like" : {
    "tweetId" : "857961787198668800",
    "fullText" : "Why is this event business formal but the catered dinner is from Chipotle? \uD83E\uDD14\uD83E\uDD14",
    "expandedUrl" : "https://twitter.com/i/web/status/857961787198668800"
  }
}, {
  "like" : {
    "tweetId" : "913793443918417920",
    "fullText" : "Bubble Ball tournament and free PIZZA on swag on Frat row fields this Saturday from 10pm - 1am! Come solo or with a team already!!",
    "expandedUrl" : "https://twitter.com/i/web/status/913793443918417920"
  }
}, {
  "like" : {
    "tweetId" : "913518910477160448",
    "fullText" : "that 8 am lighting is \uD83D\uDD25\uD83D\uDD25\uD83D\uDD25 https://t.co/dzQnrJaoCo",
    "expandedUrl" : "https://twitter.com/i/web/status/913518910477160448"
  }
}, {
  "like" : {
    "tweetId" : "908344335686565889",
    "fullText" : "H21BD to simoncito/chocolate goddess/my amazing big&amp;friend/ @simonienicole ❤️\uD83D\uDC78\uD83C\uDFFE hope u have an amazing day, i'll see u @ home l8r\uD83D\uDE42 https://t.co/baempsNw1U",
    "expandedUrl" : "https://twitter.com/i/web/status/908344335686565889"
  }
}, {
  "like" : {
    "tweetId" : "902159437640728576",
    "fullText" : "Omw to class except I don't know what class I have &amp; don't have any access to wifi to check #lastfirstday",
    "expandedUrl" : "https://twitter.com/i/web/status/902159437640728576"
  }
}, {
  "like" : {
    "tweetId" : "910920036893814784",
    "fullText" : "Go and support Mekia, our Fundraiser Chair, and her team, Riddim Ryderz, tomorrow at the All Nighter!! They perform at 10:10 pm! https://t.co/xqtWxjDSul",
    "expandedUrl" : "https://twitter.com/i/web/status/910920036893814784"
  }
}, {
  "like" : {
    "tweetId" : "901589226030026752",
    "fullText" : "this was yall at #FreshCon2017 \uD83D\uDE1B https://t.co/aKsZhrOD5t",
    "expandedUrl" : "https://twitter.com/i/web/status/901589226030026752"
  }
}, {
  "like" : {
    "tweetId" : "849465953507258369",
    "fullText" : "Follow @SeeFoodCalendar to stay hip on all the spots to get free food. #blackentreprenur https://t.co/NcakraPMLj",
    "expandedUrl" : "https://twitter.com/i/web/status/849465953507258369"
  }
}, {
  "like" : {
    "tweetId" : "851879116559319040",
    "fullText" : "hi sunset eyes, how are you doing? nice to see you again. \uD83C\uDF05 https://t.co/kvhGiBgRGR",
    "expandedUrl" : "https://twitter.com/i/web/status/851879116559319040"
  }
}, {
  "like" : {
    "tweetId" : "849436637583077376",
    "fullText" : "Came all the way to Mckeldin just to realize that I didn't want to be in Mckedlin.",
    "expandedUrl" : "https://twitter.com/i/web/status/849436637583077376"
  }
}, {
  "like" : {
    "tweetId" : "848908755286753280",
    "fullText" : "https://t.co/EW2rKe9dLO\n\nStill say Noname had one of the best rap concerts I've ever been to",
    "expandedUrl" : "https://twitter.com/i/web/status/848908755286753280"
  }
}, {
  "like" : {
    "tweetId" : "852959320115380225",
    "fullText" : "Merry J'ouvert &amp; Happy New tings to you all",
    "expandedUrl" : "https://twitter.com/i/web/status/852959320115380225"
  }
}, {
  "like" : {
    "tweetId" : "848918716960079872",
    "fullText" : "When you missed the 50% off from Papa John's yesterday but they brought it back again today https://t.co/YNwwHHf7O0",
    "expandedUrl" : "https://twitter.com/i/web/status/848918716960079872"
  }
}, {
  "like" : {
    "tweetId" : "852995207603912706",
    "fullText" : "You gotta hype your friends up on insta it's like rule number 1",
    "expandedUrl" : "https://twitter.com/i/web/status/852995207603912706"
  }
}, {
  "like" : {
    "tweetId" : "854587542464741376",
    "fullText" : "My professor really fell asleep during my presentation WOW",
    "expandedUrl" : "https://twitter.com/i/web/status/854587542464741376"
  }
}, {
  "like" : {
    "tweetId" : "849462576010407936",
    "fullText" : "has Pepsi even ever said anything about blacklivesmatter? Or they only matter when they need to be exploited for marketing? https://t.co/YszliCh8gU",
    "expandedUrl" : "https://twitter.com/i/web/status/849462576010407936"
  }
} ]