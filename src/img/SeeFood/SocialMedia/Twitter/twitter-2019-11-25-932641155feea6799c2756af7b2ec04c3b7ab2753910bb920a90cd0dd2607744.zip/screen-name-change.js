window.YTD.screen_name_change.part0 = [ {
  "screenNameChange" : {
    "accountId" : "800904115924717569",
    "screenNameChange" : {
      "changedAt" : "2016-11-22T03:30:51.000Z",
      "changedFrom" : "SeeFood6",
      "changedTo" : "SeeFoodUMD"
    }
  }
}, {
  "screenNameChange" : {
    "accountId" : "800904115924717569",
    "screenNameChange" : {
      "changedAt" : "2017-03-22T02:38:22.000Z",
      "changedFrom" : "SeeFoodUMD",
      "changedTo" : "SeeFoodCalendar"
    }
  }
} ]