window.YTD.device_token.part0 = [ {
  "deviceToken" : {
    "clientApplicationId" : "268278",
    "token" : "YMW0cgXuBxF8YQ0BPQ8swGr7tbZoT0AwY4iKgUqh",
    "createdAt" : "2018-10-14T21:50:19.926Z",
    "lastSeenAt" : "2018-10-14T21:50:19.926Z",
    "clientApplicationName" : "Twitter Web Client (Twitter, Inc.)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "268278",
    "token" : "J5DMHch3y2yqYgc2lnqjl4Ru52ejtER3ueyVBmUC",
    "createdAt" : "2018-10-25T03:53:24.404Z",
    "lastSeenAt" : "2018-10-25T03:53:24.404Z",
    "clientApplicationName" : "Twitter Web Client (Twitter, Inc.)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "268278",
    "token" : "CM0IDPTUDvN9jV8A4IV3rqUKvD6gFF2txL3ZdnUo",
    "createdAt" : "2018-11-07T17:03:52.657Z",
    "lastSeenAt" : "2018-11-07T17:03:52.657Z",
    "clientApplicationName" : "Twitter Web Client (Twitter, Inc.)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "268278",
    "token" : "uLOrNZN2DfODJIwpsUTIHn6wQVUTAe7xtp5Ms4rp",
    "createdAt" : "2018-10-04T02:10:47.664Z",
    "lastSeenAt" : "2018-12-28T05:51:26.763Z",
    "clientApplicationName" : "Twitter Web Client (Twitter, Inc.)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "129032",
    "token" : "MmWLAbg1m3LmsLu1Vr5aZIg3MeT2UyOnSAyyhlwp",
    "createdAt" : "2019-01-22T21:29:01.493Z",
    "lastSeenAt" : "2019-01-22T21:34:00.587Z",
    "clientApplicationName" : "Twitter for iPhone (Twitter)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "268278",
    "token" : "kI5bbPkfuQq2TPyca2zlOQSfRTMOxtMls3ZYTGaI",
    "createdAt" : "2019-09-30T23:31:29.608Z",
    "lastSeenAt" : "2019-11-25T22:27:04.257Z",
    "clientApplicationName" : "Twitter Web Client (Twitter, Inc.)"
  }
} ]