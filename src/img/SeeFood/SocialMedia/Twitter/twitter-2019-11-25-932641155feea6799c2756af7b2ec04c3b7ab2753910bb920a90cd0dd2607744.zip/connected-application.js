window.YTD.connected_application.part0 = [ {
  "connectedApplication" : {
    "organization" : {
      "name" : "Buffer",
      "url" : "https://buffer.com",
      "privacyPolicyUrl" : "https://buffer.com/privacy",
      "termsAndConditionsUrl" : "https://buffer.com/terms"
    },
    "name" : "Buffer",
    "description" : "A​ ​premier social media management platform​ ​that provides​ ​brands and publishers​ ​with the tools​ ​to post interesting and valuable content to their Twitter followers on a consistent basis.",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2017-10-31T05:51:30.000Z",
    "id" : "417273"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Apple®",
      "url" : ""
    },
    "name" : "iOS",
    "description" : "iOS Twitter integration",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2016-11-30T08:54:30.000Z",
    "id" : "312240"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : ""
    },
    "name" : "SeeFoodBot",
    "description" : "Tweeting about free food events only",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2016-11-22T03:38:10.000Z",
    "id" : "13123794"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Twitter, Inc.",
      "url" : "http://twitter.com"
    },
    "name" : "Twitter Web Client",
    "description" : "The official client for Twitter.com",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2016-11-22T03:29:56.000Z",
    "id" : "268278"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Twitter",
      "url" : ""
    },
    "name" : "Twitter for iPhone",
    "description" : "Twitter for iPhone",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2016-11-30T08:54:29.000Z",
    "id" : "129032"
  }
} ]